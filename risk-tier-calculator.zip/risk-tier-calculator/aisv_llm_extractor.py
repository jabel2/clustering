"""
AISV LLM Extractor

This file contains the AISV v0.2 extraction layer. It uses LangChain's
AzureChatOpenAI integration and a Pydantic schema to decompose audit issue text
into structured AISV scoring inputs.

The deterministic scoring layer remains separate in aisv_scoring.py.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


AISV_SCHEMA_VERSION = "AISV_EXTRACT_0.2"

WORKSPACE_DIRECTORY = Path(__file__).resolve().parent
V0_2_SCHEMA_PATH = WORKSPACE_DIRECTORY / "risk-tiering-vault" / "schemas" / "aisv-extraction-schema-v0.2.json"


FactStatus = Literal["stated", "inferred", "missing", "unknown", "not_applicable", "conflicting"]
ConfidenceLabel = Literal["none", "low", "moderate", "high", "confirmed"]
ImpactDomainTag = Literal[
    "FIN",
    "REG",
    "OPS",
    "CUS",
    "REP",
    "STR",
    "DATA",
    "TECH",
    "FRAUD",
    "RES",
    "THIRD",
    "SAFETY",
]
FactorCode = Literal["IM", "LE", "PV", "CW", "BC", "CD", "RU", "EC"]


class AISVBaseModel(BaseModel):
    """Base model that forbids unexpected properties for a tighter contract."""

    model_config = ConfigDict(extra="forbid")


class Provenance(AISVBaseModel):
    """Source reference for an extracted fact."""

    section: str = Field(description="Source section where the fact was found.")
    quote: str = Field(description="Short supporting quote or excerpt.")
    location: str | None = Field(default=None, description="Optional paragraph, line, or bullet location.")
    notes: str | None = Field(default=None, description="Optional provenance note.")


class TextFact(AISVBaseModel):
    """Text value with status, confidence, and provenance."""

    value: str | None = Field(default=None)
    status: FactStatus
    confidence: ConfidenceLabel
    provenance: list[Provenance] = Field(default_factory=list)
    notes: str | None = Field(default=None)


class NumberFact(AISVBaseModel):
    """Numeric value with status, confidence, and provenance."""

    value: float | None = Field(default=None)
    unit: str | None = Field(default=None)
    status: FactStatus
    confidence: ConfidenceLabel
    provenance: list[Provenance] = Field(default_factory=list)
    notes: str | None = Field(default=None)


class IntegerFact(AISVBaseModel):
    """Integer value with status, confidence, and provenance."""

    value: int | None = Field(default=None, ge=0)
    status: FactStatus
    confidence: ConfidenceLabel
    provenance: list[Provenance] = Field(default_factory=list)
    notes: str | None = Field(default=None)


class DateFact(AISVBaseModel):
    """ISO date value with status, confidence, and provenance."""

    value: str | None = Field(default=None, description="ISO date string when known.")
    status: FactStatus
    confidence: ConfidenceLabel
    provenance: list[Provenance] = Field(default_factory=list)
    notes: str | None = Field(default=None)


class BooleanFact(AISVBaseModel):
    """Boolean value with status, confidence, and provenance."""

    value: bool | None = Field(default=None)
    status: FactStatus
    confidence: ConfidenceLabel
    provenance: list[Provenance] = Field(default_factory=list)
    notes: str | None = Field(default=None)


class AffectedPopulation(AISVBaseModel):
    """Population, sample, and exception information."""

    population_definition: TextFact
    total_population: IntegerFact
    sampled_population: IntegerFact
    exception_count: IntegerFact
    exception_rate: NumberFact
    affected_population_estimate: TextFact | None = None


class TestingPerformed(AISVBaseModel):
    """Testing work used to support the issue."""

    description: TextFact
    test_period: TextFact
    sample_method: TextFact
    coverage: TextFact
    data_sources: list[TextFact] = Field(default_factory=list)


class ActionPlan(AISVBaseModel):
    """Management remediation plan."""

    remediation_summary: TextFact | None = None
    owner: TextFact | None = None
    target_date: DateFact | None = None
    target_date_basis: TextFact | None = None
    dependencies: list[TextFact] = Field(default_factory=list)
    remediation_status: Literal["not_started", "planned", "in_progress", "complete", "unknown"] | None = None


class SourceDocumentSection(AISVBaseModel):
    """Raw or normalized source document section."""

    section_name: str
    text: str


class ExtractionMetadata(AISVBaseModel):
    """Extraction governance metadata."""

    extraction_id: str
    source_document_id: str | None = None
    extracted_at: str = Field(description="ISO datetime string.")
    extractor: Literal["llm", "manual", "hybrid", "heuristic"]
    extraction_status: Literal["draft", "needs_context", "scoring_ready", "rejected"]
    human_review_required: bool
    assumptions: list[TextFact] = Field(default_factory=list)


class SourceDocument(AISVBaseModel):
    """Source document information."""

    document_title: TextFact
    source_type: Literal[
        "draft_issue",
        "final_issue",
        "historical_issue",
        "working_paper",
        "management_response",
        "other",
    ]
    sections: list[SourceDocumentSection]
    redaction_notes: TextFact | None = None


class IssueSummary(AISVBaseModel):
    """Normalized issue summary."""

    issue_title: TextFact
    concise_summary: TextFact
    audit_area: TextFact
    business_unit: TextFact
    process: TextFact
    system_or_application: TextFact | None = None
    issue_type_tags: list[str] = Field(default_factory=list)
    impact_domain_tags: list[ImpactDomainTag] = Field(default_factory=list)


class IssueAnatomy(AISVBaseModel):
    """Classic audit issue anatomy."""

    condition: TextFact
    criteria: TextFact
    cause: TextFact
    consequence: TextFact
    control_objective: TextFact
    root_cause_category: TextFact
    affected_population: AffectedPopulation
    testing_performed: TestingPerformed
    management_response: TextFact | None = None
    action_plan: ActionPlan | None = None


class EvidenceItem(AISVBaseModel):
    """Individual evidence item."""

    id: str
    evidence_type: Literal[
        "sample_testing",
        "population_analysis",
        "inquiry",
        "observation",
        "documentation_review",
        "system_data",
        "external_report",
        "incident_data",
        "financial_data",
        "regulatory_reference",
        "prior_issue",
        "other",
    ]
    description: TextFact
    coverage: TextFact
    strength: ConfidenceLabel
    supports_factors: list[FactorCode] = Field(default_factory=list)


class MissingInformationQuestion(AISVBaseModel):
    """Question needed to improve extraction or scoring confidence."""

    id: str
    question: str
    reason_needed: str
    affected_factors: list[FactorCode] = Field(default_factory=list)
    priority: Literal["critical", "high", "medium", "low"]
    answer_type: Literal["text", "number", "date", "yes_no", "choice", "number_or_text"]


class EvidenceInventory(AISVBaseModel):
    """Evidence depth, gaps, and contradictions."""

    evidence_items: list[EvidenceItem] = Field(default_factory=list)
    evidence_gaps: list[MissingInformationQuestion] = Field(default_factory=list)
    contradictory_evidence: list[TextFact] = Field(default_factory=list)
    evidence_confidence_overall: ConfidenceLabel


class RiskMechanics(AISVBaseModel):
    """How the issue becomes harm."""

    risk_event: TextFact
    impact_pathway: TextFact
    triggering_conditions: list[TextFact] = Field(default_factory=list)
    exposure_frequency: TextFact
    exposure_window: TextFact
    realized_impact: BooleanFact
    realized_impact_description: TextFact | None = None
    scenario_description: TextFact
    likelihood_drivers: list[TextFact] = Field(default_factory=list)
    magnitude_drivers: list[TextFact] = Field(default_factory=list)


class ControlEnvironment(AISVBaseModel):
    """Control design, operation, monitoring, and mitigation context."""

    control_type_tags: list[Literal["preventive", "detective", "corrective", "directive", "manual", "automated", "unknown"]] = Field(
        default_factory=list
    )
    design_effectiveness: TextFact
    operating_effectiveness: TextFact
    compensating_controls: list[TextFact] = Field(default_factory=list)
    monitoring_or_detection: TextFact
    detectability: TextFact
    recoverability: TextFact
    remediation_complexity: TextFact
    remediation_dependency: TextFact | None = None


class Context(AISVBaseModel):
    """Organizational context that affects severity."""

    business_criticality: TextFact
    enterprise_relevance: TextFact
    regulatory_or_legal_sensitivity: TextFact
    customer_or_client_impact: TextFact
    financial_exposure: TextFact
    operational_resilience_impact: TextFact
    data_or_technology_impact: TextFact | None = None
    fraud_or_misuse_exposure: TextFact | None = None
    strategic_or_reputational_relevance: TextFact | None = None
    risk_appetite_or_tolerance: TextFact
    known_management_priorities: TextFact | None = None
    affected_stakeholders: list[TextFact] = Field(default_factory=list)


class ComparableIssue(AISVBaseModel):
    """Comparable historical or current issue."""

    id: str
    title: str
    prior_tier: Literal["Tier 1", "Tier 2", "Tier 3", "Tier 4", "unknown"] | None = None
    similarity_basis: list[str] = Field(default_factory=list)
    key_similarities: list[str] = Field(default_factory=list)
    key_differences: list[str] = Field(default_factory=list)
    confidence: ConfidenceLabel


class FrameworkReference(AISVBaseModel):
    """External or internal framework mapping."""

    name: str
    relevance: str
    mapped_factors: list[FactorCode] = Field(default_factory=list)


class PriorTierDistribution(AISVBaseModel):
    """Prior tier counts for comparable issues."""

    tier_1_count: int | None = Field(default=None, ge=0)
    tier_2_count: int | None = Field(default=None, ge=0)
    tier_3_count: int | None = Field(default=None, ge=0)
    tier_4_count: int | None = Field(default=None, ge=0)


class Comparability(AISVBaseModel):
    """Historical, current, and framework comparison data."""

    similar_historical_issues: list[ComparableIssue] = Field(default_factory=list)
    similar_current_issues: list[ComparableIssue] = Field(default_factory=list)
    relevant_frameworks: list[FrameworkReference] = Field(default_factory=list)
    prior_tier_distribution: PriorTierDistribution | None = None
    calibration_notes: TextFact


class FactorAssessment(AISVBaseModel):
    """Proposed AISV factor score from extraction."""

    factor: FactorCode
    proposed_value: int | None = Field(default=None, ge=0, le=4)
    confidence: ConfidenceLabel
    directness: Literal["directly_supported", "inferred", "insufficient"]
    rationale: str
    supporting_facts: list[str] = Field(default_factory=list)
    reducing_facts: list[str] = Field(default_factory=list)
    disputed_facts: list[str] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)


class ScoringInputs(AISVBaseModel):
    """Inputs handed to the deterministic scoring layer."""

    factor_assessments: list[FactorAssessment] = Field(default_factory=list)
    impact_domain_tags: list[ImpactDomainTag] = Field(default_factory=list)
    missing_information_questions: list[MissingInformationQuestion] = Field(default_factory=list)
    scoring_readiness: Literal["insufficient", "provisional", "scoring_ready", "management_review_ready"]
    readiness_blockers: list[str] = Field(default_factory=list)


class QualityChecks(AISVBaseModel):
    """Extraction quality checks and warnings."""

    completeness_flags: list[str] = Field(default_factory=list)
    conflicts: list[TextFact] = Field(default_factory=list)
    extraction_warnings: list[str] = Field(default_factory=list)
    validation_errors: list[str] = Field(default_factory=list)


class AISVExtraction(AISVBaseModel):
    """AISV v0.2 extraction object returned by the LLM."""

    schema_version: Literal["AISV_EXTRACT_0.2"]
    extraction_metadata: ExtractionMetadata
    source_document: SourceDocument
    issue_summary: IssueSummary
    issue_anatomy: IssueAnatomy
    evidence_inventory: EvidenceInventory
    risk_mechanics: RiskMechanics
    control_environment: ControlEnvironment
    context: Context
    comparability: Comparability
    scoring_inputs: ScoringInputs
    quality_checks: QualityChecks


AISV_LLM_SYSTEM_PROMPT = """
You are an internal audit issue decomposition assistant.

Your job is to convert messy internal audit issue text into the AISV v0.2
Pydantic schema. You are not the final tiering authority.

Rules:
- Extract facts from the issue text.
- Separate directly stated facts from reasonable inferences.
- Do not invent missing population sizes, loss amounts, exception rates,
  regulatory conclusions, or control details.
- Do not invent operational metadata. extraction_id and extracted_at will be
  overwritten programmatically.
- Use "missing" or "unknown" when information is not provided.
- Provide provenance quotes for important facts whenever possible.
- Identify missing information questions needed for better scoring.
- Fill factor_assessments for IM, LE, PV, CW, BC, CD, and RU using the 0-4 AISV scale.
- Every factor rationale must explain that exact factor, not general severity.
- Map missing-information questions only to the factors they directly affect.
- Map evidence items only to the factors they directly support.
- Do not score every factor the same unless the rationale for each factor is
  independently strong and factor-specific.
- Factor definitions:
  - IM: impact magnitude if the risk is realized or already realized.
  - LE: likelihood/exposure based on frequency, exposure path, or realized condition.
  - PV: pervasiveness/scope across populations, systems, business areas, or enterprise use.
  - CW: severity of control design or operating weakness.
  - BC: business criticality and risk appetite relevance.
  - CD: strength or weakness of compensating controls, monitoring, detection, and recoverability.
  - RU: timing urgency, containment need, regulatory deadline, or exposure growth from delay.
- Keep evidence confidence separate from severity.
- Prefer transparent uncertainty over false precision.
- Do not include markdown or preamble or postamble text. Only return the JSON object.
""".strip()


def build_llm_extraction_result(audit_issue_description: str) -> dict[str, Any]:
    """Use AzureChatOpenAI to build a v0.2 AISV extraction result."""
    logging.info("Starting AISV v0.2 LLM extraction.")
    azure_chat_openai_model = create_langchain_chat_model()
    # LangChain uses the Pydantic model as the structured-output contract.
    # The JSON Schema sidecar is for documentation/tooling, not the active LLM schema.
    structured_azure_chat_model = azure_chat_openai_model.with_structured_output(AISVExtraction, include_raw=True)

    model_response = structured_azure_chat_model.invoke(
        [
            ("system", AISV_LLM_SYSTEM_PROMPT),
            (
                "human",
                "Decompose the following internal audit issue into the AISV v0.2 schema.\n\n"
                f"{audit_issue_description}",
            ),
        ]
    )
    parsed_extraction_result = extract_parsed_structured_response(model_response)
    parsed_extraction_result = apply_programmatic_metadata(parsed_extraction_result)
    logging.info("Completed AISV v0.2 LLM extraction.")
    return parsed_extraction_result


def apply_programmatic_metadata(parsed_extraction_result: dict[str, Any]) -> dict[str, Any]:
    """Set operational metadata in code instead of trusting the LLM to generate it."""
    parsed_extraction_result["schema_version"] = AISV_SCHEMA_VERSION
    parsed_extraction_result.setdefault("extraction_metadata", {})
    parsed_extraction_result["extraction_metadata"]["extraction_id"] = str(uuid.uuid4())
    parsed_extraction_result["extraction_metadata"]["extracted_at"] = datetime.now(timezone.utc).isoformat()
    parsed_extraction_result["extraction_metadata"]["extractor"] = "llm"
    parsed_extraction_result["extraction_metadata"]["human_review_required"] = True
    return parsed_extraction_result


def create_langchain_chat_model() -> Any:
    """Create a LangChain chat model from environment-driven provider settings."""
    provider_name = os.getenv("AISV_LLM_PROVIDER", "").strip().lower()
    if not provider_name:
        provider_name = "openrouter" if os.getenv("OPENROUTER_API_KEY") else "azure"

    if provider_name == "openrouter":
        return create_openrouter_chat_model()
    if provider_name == "azure":
        return create_azure_chat_openai_model()

    raise RuntimeError(
        f"Unsupported AISV_LLM_PROVIDER '{provider_name}'. Expected 'azure' or 'openrouter'."
    )


def create_openrouter_chat_model() -> Any:
    """Create a LangChain ChatOpenAI object configured for OpenRouter."""
    try:
        from langchain_openai import ChatOpenAI
    except ImportError as import_error:
        raise RuntimeError(
            "Missing dependency: langchain-openai. Install it with: pip install -r requirements.txt"
        ) from import_error

    openrouter_api_key = os.getenv("OPENROUTER_API_KEY")
    if not openrouter_api_key:
        raise RuntimeError(
            "Missing OpenRouter configuration: OPENROUTER_API_KEY. "
            "Set it or use AISV_LLM_PROVIDER=azure with Azure OpenAI settings."
        )

    return ChatOpenAI(
        base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
        api_key=openrouter_api_key,
        model=os.getenv("OPENROUTER_MODEL", "openai/gpt-4o"),
        temperature=0,
        max_tokens=None,
        timeout=120,
        max_retries=2,
    )


def create_azure_chat_openai_model() -> Any:
    """Create a LangChain AzureChatOpenAI object from environment variables."""
    try:
        from langchain_openai import AzureChatOpenAI
    except ImportError as import_error:
        raise RuntimeError(
            "Missing dependency: langchain-openai. Install it with: pip install -r requirements.txt"
        ) from import_error

    azure_deployment_name = (
        os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT")
    )
    azure_openai_api_version = os.getenv("AZURE_OPENAI_API_VERSION") or os.getenv("OPENAI_API_VERSION")

    missing_environment_variables: list[str] = []
    if not azure_deployment_name:
        missing_environment_variables.append("AZURE_OPENAI_DEPLOYMENT_NAME")
    if not azure_openai_api_version:
        missing_environment_variables.append("AZURE_OPENAI_API_VERSION")
    if not os.getenv("AZURE_OPENAI_ENDPOINT"):
        missing_environment_variables.append("AZURE_OPENAI_ENDPOINT")
    if not os.getenv("AZURE_OPENAI_API_KEY") and not os.getenv("AZURE_OPENAI_AD_TOKEN"):
        missing_environment_variables.append("AZURE_OPENAI_API_KEY")

    if missing_environment_variables:
        raise RuntimeError(
            "Missing Azure OpenAI configuration: "
            + ", ".join(missing_environment_variables)
            + ". Set these environment variables or run with --extractor heuristic."
        )

    return AzureChatOpenAI(
        azure_deployment=azure_deployment_name,
        api_version=azure_openai_api_version,
        temperature=0,
        max_tokens=None,
        timeout=120,
        max_retries=2,
    )


def load_v0_2_json_schema() -> dict[str, Any]:
    """Load the AISV v0.2 JSON Schema sidecar file."""
    if not V0_2_SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Could not find AISV v0.2 schema at {V0_2_SCHEMA_PATH}")

    with V0_2_SCHEMA_PATH.open("r", encoding="utf-8") as schema_file:
        return json.load(schema_file)


def extract_parsed_structured_response(model_response: Any) -> dict[str, Any]:
    """Extract the parsed structured response from LangChain's include_raw output."""
    if not isinstance(model_response, dict):
        raise RuntimeError("Unexpected LangChain response type. Expected a dictionary from include_raw=True.")

    parsing_error = model_response.get("parsing_error")
    if parsing_error:
        raise RuntimeError(f"AzureChatOpenAI structured output parsing failed: {parsing_error}")

    parsed_extraction_result = model_response.get("parsed")
    if isinstance(parsed_extraction_result, BaseModel):
        return parsed_extraction_result.model_dump(mode="json")
    if isinstance(parsed_extraction_result, dict):
        return parsed_extraction_result

    raise RuntimeError("AzureChatOpenAI did not return a parsed AISV extraction object.")
