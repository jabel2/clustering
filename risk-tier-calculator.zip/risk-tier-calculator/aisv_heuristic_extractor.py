"""
AISV Heuristic Extractor

This file contains the current non-LLM extraction layer. It turns pasted audit
issue text into the structured AISV v0.2 extraction shape using simple,
transparent heuristics.

This file is intentionally the replacement point for a future LLM call.
"""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Any


AISV_SCHEMA_VERSION = "AISV_EXTRACT_0.2"


SECTION_HEADING_PATTERNS = {
    "background": ["background", "context"],
    "issue_text": ["issue", "finding", "condition"],
    "evidence": ["evidence", "support", "testing", "test results"],
    "criteria": ["criteria", "standard", "requirement", "policy"],
    "root_cause": ["root cause", "cause"],
    "impact": ["impact", "risk", "consequence"],
    "management_response": ["management response", "response"],
    "action_plan": ["action plan", "remediation", "corrective action"],
}


IMPACT_DOMAIN_KEYWORDS = {
    "FIN": ["financial", "loss", "expense", "revenue", "payment", "invoice", "capital", "material"],
    "REG": ["regulatory", "regulator", "compliance", "law", "legal", "policy", "requirement"],
    "OPS": ["operational", "operation", "process", "workflow", "service", "production"],
    "CUS": ["customer", "client", "consumer", "member", "complaint"],
    "REP": ["reputation", "reputational", "media", "public"],
    "STR": ["strategic", "strategy", "initiative", "objective"],
    "DATA": ["data", "privacy", "confidential", "integrity", "availability", "record"],
    "TECH": ["system", "application", "technology", "access", "privileged", "cyber", "configuration"],
    "FRAUD": ["fraud", "misuse", "theft", "abuse"],
    "RES": ["resilience", "continuity", "outage", "recovery"],
    "THIRD": ["vendor", "third party", "supplier", "outsourced"],
    "SAFETY": ["safety", "harm", "injury", "health"],
}


def build_heuristic_extraction_result(audit_issue_description: str) -> dict[str, Any]:
    """Build the structured AISV extraction payload before deterministic scoring."""
    parsed_sections = parse_input_into_named_sections(audit_issue_description)
    full_issue_text = normalize_whitespace(audit_issue_description)
    impact_domain_tags = infer_impact_domain_tags(full_issue_text)
    issue_anatomy = extract_issue_anatomy(parsed_sections, full_issue_text)
    missing_information_questions = build_missing_information_questions(issue_anatomy, full_issue_text)

    extraction_result = {
        "schema_version": AISV_SCHEMA_VERSION,
        "extraction_metadata": {
            "extraction_id": str(uuid.uuid4()),
            "source_document_id": None,
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "extractor": "heuristic",
            "extraction_status": "needs_context",
            "human_review_required": True,
            "assumptions": [
                create_text_fact(
                    "This CLI uses transparent keyword heuristics instead of an LLM. Review all extracted fields manually.",
                    "stated",
                    "high",
                    "system",
                    "CLI heuristic extraction",
                )
            ],
        },
        "source_document": {
            "document_title": infer_issue_title(full_issue_text),
            "source_type": "draft_issue",
            "sections": [
                {"section_name": section_name, "text": section_text}
                for section_name, section_text in parsed_sections.items()
            ],
            "redaction_notes": create_text_fact(None, "unknown", "none"),
        },
        "issue_summary": {
            "issue_title": infer_issue_title(full_issue_text),
            "concise_summary": create_text_fact(
                get_first_sentence(full_issue_text),
                "inferred" if get_first_sentence(full_issue_text) else "missing",
                "moderate" if get_first_sentence(full_issue_text) else "none",
                "raw_issue",
                get_first_sentence(full_issue_text),
            ),
            "audit_area": create_text_fact(None, "missing", "none"),
            "business_unit": create_text_fact(None, "missing", "none"),
            "process": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["process", "workflow", "operation"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["process", "workflow", "operation"]),
            ),
            "system_or_application": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["system", "application", "platform", "tool"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["system", "application", "platform", "tool"]),
            ),
            "issue_type_tags": infer_issue_type_tags(full_issue_text),
            "impact_domain_tags": impact_domain_tags,
        },
        "issue_anatomy": issue_anatomy,
        "evidence_inventory": {
            "evidence_items": build_evidence_items(parsed_sections, full_issue_text),
            "evidence_gaps": missing_information_questions,
            "contradictory_evidence": build_contradictory_evidence(full_issue_text),
            "evidence_confidence_overall": "low",
        },
        "risk_mechanics": build_risk_mechanics(full_issue_text),
        "control_environment": build_control_environment(full_issue_text),
        "context": build_context(full_issue_text),
        "comparability": {
            "similar_historical_issues": [],
            "similar_current_issues": [],
            "relevant_frameworks": [],
            "prior_tier_distribution": {},
            "calibration_notes": create_text_fact(
                "No historical comparator lookup is implemented in this CLI tester.",
                "stated",
                "high",
                "system",
                "No historical comparator lookup is implemented in this CLI tester.",
            ),
        },
        "scoring_inputs": {
            "factor_assessments": [],
            "impact_domain_tags": impact_domain_tags,
            "missing_information_questions": missing_information_questions,
            "scoring_readiness": "provisional",
            "readiness_blockers": [],
        },
        "quality_checks": {
            "completeness_flags": build_completeness_flags(missing_information_questions),
            "conflicts": [],
            "extraction_warnings": [
                "This is a heuristic CLI tester. It does not call an LLM or validate against internal audit policy.",
                "All scores are provisional and should be reviewed by a human.",
            ],
            "validation_errors": [],
        },
    }

    logging.info("Built heuristic extraction payload.")
    return extraction_result


def normalize_whitespace(input_text: str | None) -> str:
    """Collapse repeated whitespace for cleaner display."""
    if not input_text:
        return ""
    return re.sub(r"\s+", " ", input_text).strip()


def split_text_into_sentences(input_text: str) -> list[str]:
    """Split text into simple sentence-like chunks."""
    normalized_input_text = normalize_whitespace(input_text)
    if not normalized_input_text:
        return []
    sentence_candidates = re.split(r"(?<=[.!?])\s+|\n+|;\s+", normalized_input_text)
    return [sentence.strip() for sentence in sentence_candidates if sentence.strip()]


def get_first_sentence(input_text: str) -> str | None:
    """Return the first sentence-like chunk from text."""
    sentences = split_text_into_sentences(input_text)
    return sentences[0] if sentences else None


def parse_input_into_named_sections(audit_issue_description: str) -> dict[str, str]:
    """Parse a pasted issue into rough named sections."""
    parsed_sections: dict[str, list[str]] = {"raw_issue": []}
    current_section_name = "raw_issue"

    for raw_line in audit_issue_description.splitlines():
        stripped_line = raw_line.strip()
        normalized_heading_candidate = stripped_line.lower().rstrip(":")

        matched_section_name = None
        for canonical_section_name, heading_aliases in SECTION_HEADING_PATTERNS.items():
            if normalized_heading_candidate in heading_aliases:
                matched_section_name = canonical_section_name
                break

        if matched_section_name:
            current_section_name = matched_section_name
            parsed_sections.setdefault(current_section_name, [])
            continue

        parsed_sections.setdefault(current_section_name, []).append(raw_line)

    flattened_sections = {
        section_name: normalize_whitespace("\n".join(section_lines))
        for section_name, section_lines in parsed_sections.items()
        if normalize_whitespace("\n".join(section_lines))
    }

    if "raw_issue" not in flattened_sections:
        flattened_sections["raw_issue"] = normalize_whitespace(audit_issue_description)

    logging.info("Parsed input into sections: %s", ", ".join(flattened_sections.keys()))
    return flattened_sections


def find_best_matching_sentence(input_text: str, keyword_list: list[str]) -> str | None:
    """Return the first sentence containing one of the provided keywords."""
    lower_case_keywords = [keyword.lower() for keyword in keyword_list]

    for sentence in split_text_into_sentences(input_text):
        lower_case_sentence = sentence.lower()
        if any(keyword in lower_case_sentence for keyword in lower_case_keywords):
            return sentence

    return None


def find_sentences_with_keywords(input_text: str, keyword_list: list[str], maximum_sentences: int = 5) -> list[str]:
    """Find sentence-like chunks containing any keyword."""
    matching_sentences: list[str] = []
    lower_case_keywords = [keyword.lower() for keyword in keyword_list]

    for sentence in split_text_into_sentences(input_text):
        lower_case_sentence = sentence.lower()
        if any(keyword in lower_case_sentence for keyword in lower_case_keywords):
            matching_sentences.append(sentence)
        if len(matching_sentences) >= maximum_sentences:
            break

    return matching_sentences


def count_keyword_matches(input_text: str, keyword_list: list[str]) -> int:
    """Count how many keyword phrases appear in the input text."""
    lower_case_input_text = input_text.lower()
    return sum(1 for keyword in keyword_list if keyword.lower() in lower_case_input_text)


def create_provenance_list(section_name: str, supporting_quote: str | None) -> list[dict[str, Any]]:
    """Create a provenance list for an extracted fact."""
    if not supporting_quote:
        return []
    return [
        {
            "section": section_name,
            "quote": normalize_whitespace(supporting_quote)[:500],
            "location": None,
            "notes": None,
        }
    ]


def create_text_fact(
    extracted_value: str | None,
    fact_status: str,
    confidence_label: str,
    section_name: str = "unknown",
    supporting_quote: str | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    """Create a schema-compatible text fact."""
    return {
        "value": normalize_whitespace(extracted_value) if extracted_value else None,
        "status": fact_status,
        "confidence": confidence_label,
        "provenance": create_provenance_list(section_name, supporting_quote),
        "notes": notes,
    }


def create_integer_fact(extracted_value: int | None, fact_status: str, confidence_label: str) -> dict[str, Any]:
    """Create a schema-compatible integer fact."""
    return {
        "value": extracted_value,
        "status": fact_status,
        "confidence": confidence_label,
        "provenance": [],
        "notes": None,
    }


def create_number_fact(
    extracted_value: float | None,
    fact_status: str,
    confidence_label: str,
    unit_label: str | None = None,
) -> dict[str, Any]:
    """Create a schema-compatible number fact."""
    return {
        "value": extracted_value,
        "unit": unit_label,
        "status": fact_status,
        "confidence": confidence_label,
        "provenance": [],
        "notes": None,
    }


def create_boolean_fact(
    extracted_value: bool | None,
    fact_status: str,
    confidence_label: str,
    section_name: str = "unknown",
    supporting_quote: str | None = None,
) -> dict[str, Any]:
    """Create a schema-compatible boolean fact."""
    return {
        "value": extracted_value,
        "status": fact_status,
        "confidence": confidence_label,
        "provenance": create_provenance_list(section_name, supporting_quote),
        "notes": None,
    }


def create_missing_information_question(
    question_identifier: str,
    question_text: str,
    reason_needed: str,
    affected_factor_codes: list[str],
    priority_label: str,
    answer_type: str,
) -> dict[str, Any]:
    """Create a structured missing-information question."""
    return {
        "id": question_identifier,
        "question": question_text,
        "reason_needed": reason_needed,
        "affected_factors": affected_factor_codes,
        "priority": priority_label,
        "answer_type": answer_type,
    }


def extract_first_number_near_keywords(input_text: str, keyword_list: list[str]) -> int | None:
    """Extract the first nearby integer from a sentence containing relevant keywords."""
    matching_sentence = find_best_matching_sentence(input_text, keyword_list)
    if not matching_sentence:
        return None

    number_match = re.search(r"\b\d{1,9}\b", matching_sentence.replace(",", ""))
    if not number_match:
        return None

    return int(number_match.group(0))


def infer_issue_title(full_issue_text: str) -> dict[str, Any]:
    """Infer a concise title from the first useful line or sentence."""
    first_sentence = get_first_sentence(full_issue_text)
    inferred_title = first_sentence[:120] if first_sentence else None

    return create_text_fact(
        inferred_title,
        "inferred" if inferred_title else "missing",
        "moderate" if inferred_title else "none",
        "raw_issue",
        first_sentence,
        "First sentence used as a provisional issue title.",
    )


def extract_issue_anatomy(parsed_sections: dict[str, str], full_issue_text: str) -> dict[str, Any]:
    """Extract classic audit issue anatomy from the pasted text."""
    condition_text = parsed_sections.get("issue_text") or find_best_matching_sentence(
        full_issue_text,
        ["found", "identified", "not", "failed", "incomplete", "missing", "issue"],
    )
    criteria_text = parsed_sections.get("criteria") or find_best_matching_sentence(
        full_issue_text,
        ["policy", "procedure", "standard", "requirement", "must", "should", "expected"],
    )
    cause_text = parsed_sections.get("root_cause") or find_best_matching_sentence(
        full_issue_text,
        ["root cause", "because", "due to", "caused by", "lack of", "insufficient"],
    )
    consequence_text = parsed_sections.get("impact") or find_best_matching_sentence(
        full_issue_text,
        ["risk", "impact", "could", "may", "result", "lead to", "exposure", "consequence"],
    )
    evidence_text = parsed_sections.get("evidence") or find_best_matching_sentence(
        full_issue_text,
        ["tested", "sample", "population", "evidence", "reviewed", "identified", "exceptions"],
    )

    total_population_count = extract_first_number_near_keywords(full_issue_text, ["population", "total"])
    sampled_population_count = extract_first_number_near_keywords(full_issue_text, ["sample", "tested", "reviewed"])
    exception_count = extract_first_number_near_keywords(full_issue_text, ["exception", "exceptions", "failed", "failures"])
    exception_rate_value = None
    if sampled_population_count and exception_count is not None and sampled_population_count > 0:
        exception_rate_value = round(exception_count / sampled_population_count, 4)

    return {
        "condition": create_text_fact(
            condition_text,
            "stated" if parsed_sections.get("issue_text") else ("inferred" if condition_text else "missing"),
            "high" if parsed_sections.get("issue_text") else ("moderate" if condition_text else "none"),
            "issue_text" if parsed_sections.get("issue_text") else "raw_issue",
            condition_text,
        ),
        "criteria": create_text_fact(
            criteria_text,
            "stated" if parsed_sections.get("criteria") else ("inferred" if criteria_text else "missing"),
            "high" if parsed_sections.get("criteria") else ("moderate" if criteria_text else "none"),
            "criteria" if parsed_sections.get("criteria") else "raw_issue",
            criteria_text,
        ),
        "cause": create_text_fact(
            cause_text,
            "stated" if parsed_sections.get("root_cause") else ("inferred" if cause_text else "missing"),
            "high" if parsed_sections.get("root_cause") else ("moderate" if cause_text else "none"),
            "root_cause" if parsed_sections.get("root_cause") else "raw_issue",
            cause_text,
        ),
        "consequence": create_text_fact(
            consequence_text,
            "stated" if parsed_sections.get("impact") else ("inferred" if consequence_text else "missing"),
            "high" if parsed_sections.get("impact") else ("moderate" if consequence_text else "none"),
            "impact" if parsed_sections.get("impact") else "raw_issue",
            consequence_text,
        ),
        "control_objective": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["control objective", "ensure", "prevent", "detect"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["control objective", "ensure", "prevent", "detect"]),
            "Heuristic extraction. Review manually.",
        ),
        "root_cause_category": {
            "value": infer_root_cause_category(full_issue_text),
            "status": "inferred",
            "confidence": "low",
            "provenance": create_provenance_list("raw_issue", cause_text),
            "notes": "Heuristic root cause category. Review manually.",
        },
        "affected_population": {
            "population_definition": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["population", "transactions", "records", "users", "applications"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["population", "transactions", "records", "users", "applications"]),
            ),
            "total_population": create_integer_fact(total_population_count, "inferred" if total_population_count is not None else "missing", "low"),
            "sampled_population": create_integer_fact(sampled_population_count, "inferred" if sampled_population_count is not None else "missing", "low"),
            "exception_count": create_integer_fact(exception_count, "inferred" if exception_count is not None else "missing", "low"),
            "exception_rate": create_number_fact(exception_rate_value, "inferred" if exception_rate_value is not None else "missing", "low", "ratio"),
            "affected_population_estimate": create_text_fact(None, "unknown", "none"),
        },
        "testing_performed": {
            "description": create_text_fact(
                evidence_text,
                "stated" if parsed_sections.get("evidence") else ("inferred" if evidence_text else "missing"),
                "high" if parsed_sections.get("evidence") else ("moderate" if evidence_text else "none"),
                "evidence" if parsed_sections.get("evidence") else "raw_issue",
                evidence_text,
            ),
            "test_period": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["period", "from", "through", "during", "as of"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["period", "from", "through", "during", "as of"]),
            ),
            "sample_method": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["sample", "judgmental", "random", "selected"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["sample", "judgmental", "random", "selected"]),
            ),
            "coverage": create_text_fact(
                find_best_matching_sentence(full_issue_text, ["population", "coverage", "all", "sample"]),
                "inferred",
                "low",
                "raw_issue",
                find_best_matching_sentence(full_issue_text, ["population", "coverage", "all", "sample"]),
            ),
            "data_sources": [],
        },
        "management_response": create_text_fact(
            parsed_sections.get("management_response"),
            "stated" if parsed_sections.get("management_response") else "missing",
            "high" if parsed_sections.get("management_response") else "none",
            "management_response",
            parsed_sections.get("management_response"),
        ),
        "action_plan": build_action_plan(parsed_sections.get("action_plan")),
    }


def build_action_plan(action_plan_text: str | None) -> dict[str, Any]:
    """Build an action plan object from optional text."""
    return {
        "remediation_summary": create_text_fact(
            action_plan_text,
            "stated" if action_plan_text else "missing",
            "high" if action_plan_text else "none",
            "action_plan",
            action_plan_text,
        ),
        "owner": create_text_fact(None, "missing", "none"),
        "target_date": {
            "value": None,
            "status": "missing",
            "confidence": "none",
            "provenance": [],
            "notes": None,
        },
        "target_date_basis": create_text_fact(None, "missing", "none"),
        "dependencies": [],
        "remediation_status": "unknown",
    }


def infer_root_cause_category(full_issue_text: str) -> str:
    """Infer a rough root cause category from simple keywords."""
    lower_case_issue_text = full_issue_text.lower()
    root_cause_keyword_map = {
        "technology": ["system", "application", "configuration", "automated", "technology"],
        "process": ["process", "procedure", "workflow", "manual"],
        "people": ["training", "awareness", "staff", "employee", "user"],
        "governance": ["oversight", "governance", "accountability", "ownership"],
        "data": ["data", "record", "report", "field"],
        "third_party": ["vendor", "third party", "supplier"],
        "resourcing": ["resource", "capacity", "staffing"],
    }

    for category_name, category_keywords in root_cause_keyword_map.items():
        if any(keyword in lower_case_issue_text for keyword in category_keywords):
            return category_name

    return "unclear"


def infer_impact_domain_tags(full_issue_text: str) -> list[str]:
    """Infer impact domain tags from keyword matches."""
    inferred_impact_domain_tags: list[str] = []

    for impact_domain_tag, keyword_list in IMPACT_DOMAIN_KEYWORDS.items():
        if count_keyword_matches(full_issue_text, keyword_list) > 0:
            inferred_impact_domain_tags.append(impact_domain_tag)

    return inferred_impact_domain_tags or ["OPS"]


def infer_issue_type_tags(full_issue_text: str) -> list[str]:
    """Infer simple issue type tags."""
    issue_type_tags: list[str] = []
    lower_case_issue_text = full_issue_text.lower()

    if any(keyword in lower_case_issue_text for keyword in ["access", "privileged", "user"]):
        issue_type_tags.append("access_management")
    if any(keyword in lower_case_issue_text for keyword in ["reconciliation", "review", "approval"]):
        issue_type_tags.append("control_execution")
    if any(keyword in lower_case_issue_text for keyword in ["policy", "procedure", "standard"]):
        issue_type_tags.append("policy_noncompliance")
    if any(keyword in lower_case_issue_text for keyword in ["data", "report", "record"]):
        issue_type_tags.append("data_quality")
    if any(keyword in lower_case_issue_text for keyword in ["vendor", "third party", "supplier"]):
        issue_type_tags.append("third_party")

    return issue_type_tags or ["general_audit_issue"]


def build_missing_information_questions(
    issue_anatomy: dict[str, Any],
    full_issue_text: str,
) -> list[dict[str, Any]]:
    """Build targeted questions for missing or weak fields."""
    missing_information_questions: list[dict[str, Any]] = []

    if issue_anatomy["affected_population"]["total_population"]["status"] == "missing":
        missing_information_questions.append(
            create_missing_information_question(
                "gap_population_size",
                "What is the total population affected or tested?",
                "Population size is needed to assess pervasiveness and exposure.",
                ["PV", "LE", "EC"],
                "high",
                "number_or_text",
            )
        )

    if issue_anatomy["affected_population"]["exception_count"]["status"] == "missing":
        missing_information_questions.append(
            create_missing_information_question(
                "gap_exception_count",
                "How many exceptions were identified, and what was the exception rate?",
                "Exception count and rate help assess exposure, evidence confidence, and control weakness severity.",
                ["LE", "CW", "EC"],
                "high",
                "number_or_text",
            )
        )

    if issue_anatomy["criteria"]["status"] == "missing":
        missing_information_questions.append(
            create_missing_information_question(
                "gap_criteria",
                "What policy, standard, control objective, or requirement was not met?",
                "Criteria are needed to understand the control expectation and severity of deviation.",
                ["CW", "BC"],
                "high",
                "text",
            )
        )

    if issue_anatomy["consequence"]["status"] == "missing":
        missing_information_questions.append(
            create_missing_information_question(
                "gap_consequence",
                "What happened or could happen because of this issue?",
                "Consequence is needed to assess impact magnitude and business criticality.",
                ["IM", "BC", "RU"],
                "critical",
                "text",
            )
        )

    if not find_best_matching_sentence(full_issue_text, ["compensating", "monitoring", "reconciliation", "review", "detect"]):
        missing_information_questions.append(
            create_missing_information_question(
                "gap_compensating_controls",
                "Are there compensating controls, monitoring, reconciliations, or detective reviews that reduce this risk?",
                "Compensating controls are needed to assess detectability and residual severity.",
                ["CD", "IM", "LE"],
                "medium",
                "text",
            )
        )

    if not find_best_matching_sentence(full_issue_text, ["remediate", "remediation", "action plan", "due date", "target date"]):
        missing_information_questions.append(
            create_missing_information_question(
                "gap_remediation_timing",
                "What remediation timing is expected or required?",
                "Remediation timing helps assess urgency and management-review readiness.",
                ["RU"],
                "medium",
                "date",
            )
        )

    return missing_information_questions


def build_evidence_items(parsed_sections: dict[str, str], full_issue_text: str) -> list[dict[str, Any]]:
    """Build a simple evidence inventory."""
    evidence_items: list[dict[str, Any]] = []
    evidence_section_text = parsed_sections.get("evidence")

    if evidence_section_text:
        evidence_items.append(
            {
                "id": "evidence_001",
                "evidence_type": infer_evidence_type(evidence_section_text),
                "description": create_text_fact(evidence_section_text, "stated", "high", "evidence", evidence_section_text),
                "coverage": create_text_fact(
                    find_best_matching_sentence(evidence_section_text, ["sample", "population", "all", "reviewed"]),
                    "inferred",
                    "low",
                    "evidence",
                    find_best_matching_sentence(evidence_section_text, ["sample", "population", "all", "reviewed"]),
                ),
                "strength": "moderate",
                "supports_factors": ["LE", "CW", "EC"],
            }
        )
        return evidence_items

    evidence_like_sentence = find_best_matching_sentence(
        full_issue_text,
        ["tested", "sample", "population", "reviewed", "exceptions", "evidence"],
    )
    if evidence_like_sentence:
        evidence_items.append(
            {
                "id": "evidence_001",
                "evidence_type": infer_evidence_type(evidence_like_sentence),
                "description": create_text_fact(evidence_like_sentence, "inferred", "moderate", "raw_issue", evidence_like_sentence),
                "coverage": create_text_fact(None, "unknown", "none"),
                "strength": "low",
                "supports_factors": ["LE", "CW", "EC"],
            }
        )

    return evidence_items


def infer_evidence_type(evidence_text: str) -> str:
    """Infer an evidence type from text."""
    lower_case_evidence_text = evidence_text.lower()
    if "population" in lower_case_evidence_text or "all" in lower_case_evidence_text:
        return "population_analysis"
    if "sample" in lower_case_evidence_text or "tested" in lower_case_evidence_text:
        return "sample_testing"
    if "system" in lower_case_evidence_text or "data" in lower_case_evidence_text:
        return "system_data"
    if "inquiry" in lower_case_evidence_text or "interview" in lower_case_evidence_text:
        return "inquiry"
    if "policy" in lower_case_evidence_text or "procedure" in lower_case_evidence_text:
        return "documentation_review"
    return "other"


def build_contradictory_evidence(full_issue_text: str) -> list[dict[str, Any]]:
    """Extract simple mitigating or contradictory evidence."""
    mitigating_sentences = find_sentences_with_keywords(
        full_issue_text,
        ["however", "mitigated", "compensating", "no impact", "not material", "isolated", "management disagreed"],
    )
    return [create_text_fact(sentence, "inferred", "low", "raw_issue", sentence) for sentence in mitigating_sentences]


def build_risk_mechanics(full_issue_text: str) -> dict[str, Any]:
    """Build the risk mechanics section."""
    return {
        "risk_event": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["risk", "could", "may", "lead to", "result"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["risk", "could", "may", "lead to", "result"]),
        ),
        "impact_pathway": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["because", "due to", "therefore", "lead to", "result"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["because", "due to", "therefore", "lead to", "result"]),
        ),
        "triggering_conditions": [],
        "exposure_frequency": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["daily", "weekly", "monthly", "recurring", "frequent", "ongoing"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["daily", "weekly", "monthly", "recurring", "frequent", "ongoing"]),
        ),
        "exposure_window": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["since", "for", "during", "period", "as of"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["since", "for", "during", "period", "as of"]),
        ),
        "realized_impact": create_boolean_fact(
            infer_realized_impact(full_issue_text),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["occurred", "resulted", "caused", "loss", "incident"]),
        ),
        "realized_impact_description": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["occurred", "resulted", "caused", "loss", "incident"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["occurred", "resulted", "caused", "loss", "incident"]),
        ),
        "scenario_description": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["could", "may", "potential", "risk"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["could", "may", "potential", "risk"]),
        ),
        "likelihood_drivers": [
            create_text_fact(sentence, "inferred", "low", "raw_issue", sentence)
            for sentence in find_sentences_with_keywords(full_issue_text, ["recurring", "multiple", "ongoing", "sample", "population"])
        ],
        "magnitude_drivers": [
            create_text_fact(sentence, "inferred", "low", "raw_issue", sentence)
            for sentence in find_sentences_with_keywords(full_issue_text, ["material", "regulatory", "customer", "financial", "critical", "significant"])
        ],
    }


def build_control_environment(full_issue_text: str) -> dict[str, Any]:
    """Build the control environment section."""
    return {
        "control_type_tags": infer_control_type_tags(full_issue_text),
        "design_effectiveness": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["design", "designed", "missing control", "no control"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["design", "designed", "missing control", "no control"]),
        ),
        "operating_effectiveness": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["operating", "performed", "not performed", "failed", "ineffective"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["operating", "performed", "not performed", "failed", "ineffective"]),
        ),
        "compensating_controls": [
            create_text_fact(sentence, "inferred", "low", "raw_issue", sentence)
            for sentence in find_sentences_with_keywords(full_issue_text, ["compensating", "monitoring", "reconciliation", "review", "detect"])
        ],
        "monitoring_or_detection": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["monitoring", "detected", "detection", "review", "reconciliation"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["monitoring", "detected", "detection", "review", "reconciliation"]),
        ),
        "detectability": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["detect", "identified by audit", "monitoring"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["detect", "identified by audit", "monitoring"]),
        ),
        "recoverability": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["recover", "correct", "reverse", "remediate"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["recover", "correct", "reverse", "remediate"]),
        ),
        "remediation_complexity": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["complex", "dependency", "manual", "system change", "automation"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["complex", "dependency", "manual", "system change", "automation"]),
        ),
        "remediation_dependency": create_text_fact(
            find_best_matching_sentence(full_issue_text, ["dependency", "dependent", "vendor", "technology"]),
            "inferred",
            "low",
            "raw_issue",
            find_best_matching_sentence(full_issue_text, ["dependency", "dependent", "vendor", "technology"]),
        ),
    }


def infer_control_type_tags(full_issue_text: str) -> list[str]:
    """Infer control type tags from keywords."""
    control_type_tags: list[str] = []
    lower_case_issue_text = full_issue_text.lower()

    if "prevent" in lower_case_issue_text:
        control_type_tags.append("preventive")
    if any(keyword in lower_case_issue_text for keyword in ["detect", "monitor", "review", "reconciliation"]):
        control_type_tags.append("detective")
    if any(keyword in lower_case_issue_text for keyword in ["correct", "remediate"]):
        control_type_tags.append("corrective")
    if "manual" in lower_case_issue_text:
        control_type_tags.append("manual")
    if any(keyword in lower_case_issue_text for keyword in ["automated", "system"]):
        control_type_tags.append("automated")

    return control_type_tags or ["unknown"]


def infer_realized_impact(full_issue_text: str) -> bool | None:
    """Infer whether impact has already occurred."""
    lower_case_issue_text = full_issue_text.lower()
    if any(keyword in lower_case_issue_text for keyword in ["occurred", "resulted in", "caused", "loss of", "incident"]):
        return True
    if any(keyword in lower_case_issue_text for keyword in ["could", "may", "potential"]):
        return False
    return None


def build_context(full_issue_text: str) -> dict[str, Any]:
    """Build the context section."""
    return {
        "business_criticality": create_context_sentence(full_issue_text, ["critical", "key", "core", "important", "enterprise"]),
        "enterprise_relevance": create_context_sentence(full_issue_text, ["enterprise", "firmwide", "global", "all business", "multiple"]),
        "regulatory_or_legal_sensitivity": create_context_sentence(full_issue_text, ["regulatory", "legal", "compliance", "law", "requirement"]),
        "customer_or_client_impact": create_context_sentence(full_issue_text, ["customer", "client", "consumer", "member"]),
        "financial_exposure": create_context_sentence(full_issue_text, ["financial", "loss", "revenue", "expense", "payment"]),
        "operational_resilience_impact": create_context_sentence(full_issue_text, ["operational", "resilience", "continuity", "outage"]),
        "data_or_technology_impact": create_context_sentence(full_issue_text, ["data", "system", "application", "technology", "privacy"]),
        "fraud_or_misuse_exposure": create_context_sentence(full_issue_text, ["fraud", "misuse", "theft", "abuse"]),
        "strategic_or_reputational_relevance": create_context_sentence(full_issue_text, ["strategic", "reputation", "reputational", "media"]),
        "risk_appetite_or_tolerance": create_context_sentence(full_issue_text, ["risk appetite", "tolerance", "zero tolerance"]),
        "known_management_priorities": create_text_fact(None, "missing", "none"),
        "affected_stakeholders": [
            create_text_fact(sentence, "inferred", "low", "raw_issue", sentence)
            for sentence in find_sentences_with_keywords(full_issue_text, ["stakeholder", "management", "business owner", "customer", "client"])
        ],
    }


def create_context_sentence(full_issue_text: str, keyword_list: list[str]) -> dict[str, Any]:
    """Create a context fact from the first matching sentence."""
    matching_sentence = find_best_matching_sentence(full_issue_text, keyword_list)
    return create_text_fact(matching_sentence, "inferred", "low", "raw_issue", matching_sentence)


def build_completeness_flags(missing_information_questions: list[dict[str, Any]]) -> list[str]:
    """Summarize completeness concerns."""
    if not missing_information_questions:
        return ["No missing information questions generated by heuristic checks."]

    return [
        f"{missing_question['priority'].upper()}: {missing_question['question']}"
        for missing_question in missing_information_questions
    ]
