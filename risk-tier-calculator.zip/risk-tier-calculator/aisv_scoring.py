"""
AISV Scoring

This file contains the deterministic scoring layer. It consumes structured
extraction output and adds AISV factor assessments, score, suggested tier,
evidence confidence, readiness, and vector string.
"""

from __future__ import annotations

import logging
from typing import Any


AISV_VECTOR_VERSION = "0.2"


FACTOR_SCORE_WEIGHTS = {
    "IM": 25,
    "LE": 15,
    "PV": 15,
    "CW": 15,
    "BC": 10,
    "CD": 10,
    "RU": 10,
}


def apply_aisv_scoring(extraction_result: dict[str, Any]) -> dict[str, Any]:
    """Apply AISV scoring to a structured extraction result."""
    full_issue_text = build_full_issue_text_from_extraction_result(extraction_result)
    issue_anatomy = extraction_result["issue_anatomy"]
    missing_information_questions = extraction_result["scoring_inputs"]["missing_information_questions"]
    impact_domain_tags = extraction_result["scoring_inputs"]["impact_domain_tags"]

    extracted_factor_assessments = extraction_result["scoring_inputs"].get("factor_assessments", [])
    if has_complete_factor_assessments(extracted_factor_assessments):
        factor_assessments = extracted_factor_assessments
        logging.info("Using extracted AISV factor assessments from the extraction layer.")
    else:
        factor_assessments = build_factor_assessments(full_issue_text, missing_information_questions)
        logging.info("Using heuristic AISV factor assessments from the scoring layer.")
    evidence_confidence_overall = determine_evidence_confidence(extraction_result, issue_anatomy, missing_information_questions)
    scoring_readiness, readiness_blockers = determine_scoring_readiness(full_issue_text, missing_information_questions)
    aisv_score = calculate_aisv_score(factor_assessments)
    score_based_tier = map_score_to_suggested_tier(aisv_score)
    tier_review_flags = build_tier_review_flags(factor_assessments, impact_domain_tags, aisv_score)
    suggested_tier = apply_tier_floors(score_based_tier, tier_review_flags)
    evidence_confidence_score = convert_confidence_label_to_score(evidence_confidence_overall)
    aisv_vector_string = build_aisv_vector_string(factor_assessments, evidence_confidence_score, impact_domain_tags)
    factor_alignment_warnings = build_factor_alignment_warnings(factor_assessments)

    extraction_result["evidence_inventory"]["evidence_confidence_overall"] = evidence_confidence_overall
    extraction_result["scoring_inputs"]["factor_assessments"] = factor_assessments
    extraction_result["scoring_inputs"]["scoring_readiness"] = scoring_readiness
    extraction_result["scoring_inputs"]["readiness_blockers"] = readiness_blockers
    extraction_result["quality_checks"].setdefault("extraction_warnings", [])
    extraction_result["quality_checks"]["extraction_warnings"].extend(factor_alignment_warnings)
    extraction_result["extraction_metadata"]["extraction_status"] = (
        "scoring_ready" if scoring_readiness != "insufficient" else "needs_context"
    )
    extraction_result["aisv_result"] = {
        "suggested_tier": suggested_tier,
        "score_based_tier": score_based_tier,
        "aisv_score": aisv_score,
        "evidence_confidence": evidence_confidence_overall,
        "aisv_vector": aisv_vector_string,
        "tier_review_flags": tier_review_flags,
    }

    logging.info(
        "Applied AISV scoring: score=%s, tier=%s, readiness=%s",
        aisv_score,
        suggested_tier,
        scoring_readiness,
    )
    return extraction_result


def determine_evidence_confidence(
    extraction_result: dict[str, Any],
    issue_anatomy: dict[str, Any],
    missing_information_questions: list[dict[str, Any]],
) -> str:
    """Preserve LLM evidence confidence and keep context completeness separate."""
    extractor_name = extraction_result.get("extraction_metadata", {}).get("extractor")
    extracted_evidence_confidence = extraction_result.get("evidence_inventory", {}).get("evidence_confidence_overall")
    valid_confidence_labels = {"none", "low", "moderate", "high", "confirmed"}

    if extractor_name == "llm" and extracted_evidence_confidence in valid_confidence_labels:
        return extracted_evidence_confidence

    return determine_overall_evidence_confidence(issue_anatomy, missing_information_questions)


def has_complete_factor_assessments(factor_assessments: list[dict[str, Any]]) -> bool:
    """Return True when the extraction layer already supplied all scored AISV factors."""
    required_factor_codes = set(FACTOR_SCORE_WEIGHTS.keys())
    supplied_factor_codes = {
        factor_assessment.get("factor")
        for factor_assessment in factor_assessments
        if factor_assessment.get("proposed_value") is not None
    }
    return required_factor_codes.issubset(supplied_factor_codes)


def build_factor_value_lookup(factor_assessments: list[dict[str, Any]]) -> dict[str, int]:
    """Build a factor-code-to-score lookup."""
    return {
        factor_assessment["factor"]: int(factor_assessment["proposed_value"])
        for factor_assessment in factor_assessments
        if factor_assessment.get("proposed_value") is not None
    }


def build_tier_review_flags(
    factor_assessments: list[dict[str, Any]],
    impact_domain_tags: list[str],
    aisv_score: float,
) -> list[dict[str, Any]]:
    """Build generic tier floor and review flags from AISV factor patterns."""
    factor_values = build_factor_value_lookup(factor_assessments)
    impact_domains = set(impact_domain_tags)
    tier_review_flags: list[dict[str, Any]] = []

    impact_magnitude = factor_values.get("IM", 0)
    likelihood_exposure = factor_values.get("LE", 0)
    pervasiveness_scope = factor_values.get("PV", 0)
    control_weakness = factor_values.get("CW", 0)
    business_criticality = factor_values.get("BC", 0)
    compensating_controls = factor_values.get("CD", 0)
    remediation_urgency = factor_values.get("RU", 0)

    if impact_magnitude >= 4 and (pervasiveness_scope >= 3 or business_criticality >= 4):
        tier_review_flags.append(
            create_tier_review_flag(
                "tier_1_floor_severe_impact_scope",
                "Tier 1",
                "Severe impact combined with broad scope or very high business criticality.",
            )
        )

    if (
        {"DATA", "REG"}.issubset(impact_domains)
        and impact_magnitude >= 3
        and control_weakness >= 3
        and compensating_controls >= 3
        and remediation_urgency >= 3
    ):
        tier_review_flags.append(
            create_tier_review_flag(
                "tier_1_floor_data_regulatory_control_failure",
                "Tier 1",
                "Data/regulatory impact combined with significant control weakness, weak detection/compensation, and high remediation urgency.",
            )
        )

    if (
        aisv_score >= 75
        and impact_magnitude >= 3
        and business_criticality >= 3
        and control_weakness >= 3
        and remediation_urgency >= 3
    ):
        tier_review_flags.append(
            create_tier_review_flag(
                "tier_1_candidate_high_score_cluster",
                "Tier 1",
                "High AISV score with clustered high impact, business criticality, control weakness, and urgency.",
            )
        )

    if impact_magnitude >= 3 and likelihood_exposure >= 3 and compensating_controls >= 3:
        tier_review_flags.append(
            create_tier_review_flag(
                "senior_review_high_exposure_weak_detection",
                "review",
                "High impact and exposure with weak compensating controls or detectability.",
            )
        )

    return tier_review_flags


def create_tier_review_flag(flag_code: str, tier_floor: str, rationale: str) -> dict[str, str]:
    """Create a tier review flag object."""
    return {
        "flag": flag_code,
        "tier_floor": tier_floor,
        "rationale": rationale,
    }


def apply_tier_floors(score_based_tier: str, tier_review_flags: list[dict[str, Any]]) -> str:
    """Apply tier floor flags to the score-based tier."""
    tier_rank = {"Tier 1": 1, "Tier 2": 2, "Tier 3": 3, "Tier 4": 4}
    suggested_tier = score_based_tier

    for tier_review_flag in tier_review_flags:
        tier_floor = tier_review_flag.get("tier_floor")
        if tier_floor in tier_rank and tier_rank[tier_floor] < tier_rank[suggested_tier]:
            suggested_tier = tier_floor

    return suggested_tier


def build_factor_alignment_warnings(factor_assessments: list[dict[str, Any]]) -> list[str]:
    """Flag likely factor-rationale mismatches for human review."""
    warnings: list[str] = []
    mismatch_keywords_by_factor = {
        "PV": ["policy violation", "compliance", "approval"],
        "CW": ["regulatory risk", "fines", "business criticality"],
        "CD": ["control design", "policy violation"],
        "RU": ["regulatory risk", "business criticality"],
    }

    for factor_assessment in factor_assessments:
        factor_code = factor_assessment.get("factor")
        rationale_text = str(factor_assessment.get("rationale", "")).lower()
        mismatch_keywords = mismatch_keywords_by_factor.get(factor_code, [])
        if any(keyword in rationale_text for keyword in mismatch_keywords):
            warnings.append(
                f"Review {factor_code} rationale for possible factor mismatch: {factor_assessment.get('rationale')}"
            )

    return warnings


def build_full_issue_text_from_extraction_result(extraction_result: dict[str, Any]) -> str:
    """Rebuild the full issue text from source document sections."""
    section_text_values = [
        source_section["text"]
        for source_section in extraction_result["source_document"]["sections"]
        if source_section.get("text")
    ]
    return " ".join(section_text_values)


def count_keyword_matches(input_text: str, keyword_list: list[str]) -> int:
    """Count how many keyword phrases appear in the input text."""
    lower_case_input_text = input_text.lower()
    return sum(1 for keyword in keyword_list if keyword.lower() in lower_case_input_text)


def score_factor_from_keyword_groups(
    full_issue_text: str,
    severe_keywords: list[str],
    high_keywords: list[str],
    moderate_keywords: list[str],
    low_keywords: list[str],
    default_score: int,
) -> tuple[int, str, str]:
    """Score a factor using transparent keyword groups."""
    if count_keyword_matches(full_issue_text, severe_keywords) > 0:
        return 4, "moderate", "Matched severe keyword indicators."
    if count_keyword_matches(full_issue_text, high_keywords) > 0:
        return 3, "moderate", "Matched high keyword indicators."
    if count_keyword_matches(full_issue_text, moderate_keywords) > 0:
        return 2, "moderate", "Matched moderate keyword indicators."
    if count_keyword_matches(full_issue_text, low_keywords) > 0:
        return 1, "low", "Matched low keyword indicators."
    return default_score, "low", "No clear keyword signal; using provisional default."


def create_factor_assessment(
    factor_code: str,
    proposed_value: int,
    confidence_label: str,
    directness_label: str,
    rationale_text: str,
    supporting_fact_references: list[str],
    reducing_fact_references: list[str] | None = None,
    disputed_fact_references: list[str] | None = None,
    missing_information_references: list[str] | None = None,
) -> dict[str, Any]:
    """Create a schema-compatible AISV factor assessment."""
    return {
        "factor": factor_code,
        "proposed_value": proposed_value,
        "confidence": confidence_label,
        "directness": directness_label,
        "rationale": rationale_text,
        "supporting_facts": supporting_fact_references,
        "reducing_facts": reducing_fact_references or [],
        "disputed_facts": disputed_fact_references or [],
        "missing_information": missing_information_references or [],
    }


def build_factor_assessments(
    full_issue_text: str,
    missing_information_questions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Create heuristic AISV factor assessments."""
    factor_missing_information_lookup = build_factor_missing_information_lookup(missing_information_questions)

    impact_score, impact_confidence, impact_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["material", "severe", "board", "regulatory breach", "safety", "customer harm", "data breach", "major"],
        ["regulatory", "legal", "financial loss", "critical", "fraud", "significant"],
        ["impact", "risk", "compliance", "delay", "error", "exposure"],
        ["minor", "limited", "localized"],
        2,
    )

    likelihood_score, likelihood_confidence, likelihood_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["ongoing", "already occurred", "realized", "high-frequency", "all transactions"],
        ["recurring", "repeated", "multiple", "frequent", "systemic"],
        ["could", "may", "plausible", "potential"],
        ["isolated", "one-off", "single instance"],
        2,
    )

    pervasiveness_score, pervasiveness_confidence, pervasiveness_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["enterprise-wide", "firmwide", "global", "all business", "all users"],
        ["multiple business", "multiple teams", "multiple systems", "several"],
        ["business area", "process", "population", "application"],
        ["single", "localized", "one team"],
        2,
    )

    control_weakness_score, control_weakness_confidence, control_weakness_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["no control", "missing control", "absent", "not performed", "systemically ineffective"],
        ["ineffective", "failed", "design gap", "key control", "not operating"],
        ["incomplete", "inconsistent", "manual", "not documented"],
        ["documentation", "clarity", "ownership"],
        2,
    )

    business_criticality_score, business_criticality_confidence, business_criticality_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["board", "regulator", "regulatory", "customer", "safety", "material", "enterprise"],
        ["critical", "core", "key", "significant", "financial"],
        ["important", "compliance", "operational", "process"],
        ["support", "administrative", "minor"],
        2,
    )

    compensating_control_score, compensating_control_confidence, compensating_control_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["no compensating", "no monitoring", "not detected", "only identified by audit"],
        ["weak monitoring", "manual review", "late detection", "informal"],
        ["partial", "reconciliation", "monitoring", "review"],
        ["strong compensating", "effective monitoring", "automated detection"],
        2,
    )

    if count_keyword_matches(full_issue_text, ["strong compensating", "effective monitoring", "automated detection"]) > 0:
        compensating_control_score = 0
        compensating_control_confidence = "moderate"
        compensating_control_reason = "Text indicates strong compensating controls or detection."

    remediation_urgency_score, remediation_urgency_confidence, remediation_urgency_reason = score_factor_from_keyword_groups(
        full_issue_text,
        ["immediate", "urgent", "ongoing harm", "regulatory deadline", "containment"],
        ["high urgency", "near-term", "delay increases", "must remediate"],
        ["remediate", "action plan", "target date", "due date"],
        ["next cycle", "low urgency"],
        2,
    )

    return [
        create_factor_assessment("IM", impact_score, impact_confidence, "inferred", impact_reason, ["issue_anatomy.consequence"], missing_information_references=factor_missing_information_lookup["IM"]),
        create_factor_assessment("LE", likelihood_score, likelihood_confidence, "inferred", likelihood_reason, ["risk_mechanics.likelihood_drivers"], missing_information_references=factor_missing_information_lookup["LE"]),
        create_factor_assessment("PV", pervasiveness_score, pervasiveness_confidence, "inferred", pervasiveness_reason, ["issue_anatomy.affected_population"], missing_information_references=factor_missing_information_lookup["PV"]),
        create_factor_assessment("CW", control_weakness_score, control_weakness_confidence, "inferred", control_weakness_reason, ["control_environment.design_effectiveness", "control_environment.operating_effectiveness"], missing_information_references=factor_missing_information_lookup["CW"]),
        create_factor_assessment("BC", business_criticality_score, business_criticality_confidence, "inferred", business_criticality_reason, ["context.business_criticality"], missing_information_references=factor_missing_information_lookup["BC"]),
        create_factor_assessment("CD", compensating_control_score, compensating_control_confidence, "inferred", compensating_control_reason, ["control_environment.compensating_controls"], missing_information_references=factor_missing_information_lookup["CD"]),
        create_factor_assessment("RU", remediation_urgency_score, remediation_urgency_confidence, "inferred", remediation_urgency_reason, ["issue_anatomy.action_plan"], missing_information_references=factor_missing_information_lookup["RU"]),
    ]


def build_factor_missing_information_lookup(
    missing_information_questions: list[dict[str, Any]],
) -> dict[str, list[str]]:
    """Map factor codes to missing-information question IDs."""
    return {
        factor_code: [
            missing_question["id"]
            for missing_question in missing_information_questions
            if factor_code in missing_question["affected_factors"]
        ]
        for factor_code in FACTOR_SCORE_WEIGHTS.keys()
    }


def calculate_aisv_score(factor_assessments: list[dict[str, Any]]) -> float:
    """Calculate AISV score from weighted factor assessments."""
    weighted_score_total = 0.0

    for factor_assessment in factor_assessments:
        factor_code = factor_assessment["factor"]
        if factor_code not in FACTOR_SCORE_WEIGHTS:
            continue

        proposed_value = factor_assessment["proposed_value"]
        if proposed_value is None:
            proposed_value = 2

        factor_weight = FACTOR_SCORE_WEIGHTS[factor_code]
        weighted_score_total += (proposed_value / 4) * factor_weight

    return round(weighted_score_total, 2)


def map_score_to_suggested_tier(aisv_score: float) -> str:
    """Map an AISV score to a draft tier."""
    if aisv_score >= 80:
        return "Tier 1"
    if aisv_score >= 60:
        return "Tier 2"
    if aisv_score >= 35:
        return "Tier 3"
    return "Tier 4"


def determine_overall_evidence_confidence(
    issue_anatomy: dict[str, Any],
    missing_information_questions: list[dict[str, Any]],
) -> str:
    """Determine rough overall evidence confidence."""
    high_priority_gap_count = sum(
        1 for missing_question in missing_information_questions if missing_question["priority"] in ["critical", "high"]
    )

    if high_priority_gap_count >= 3:
        return "low"
    if high_priority_gap_count >= 1:
        return "moderate"

    testing_status = issue_anatomy["testing_performed"]["description"]["status"]
    if testing_status == "stated":
        return "high"

    return "moderate"


def determine_scoring_readiness(
    audit_issue_description: str,
    missing_information_questions: list[dict[str, Any]],
) -> tuple[str, list[str]]:
    """Determine whether the extracted issue is ready for scoring/review."""
    readiness_blockers: list[str] = []

    if len(audit_issue_description) < 100:
        readiness_blockers.append("Issue description is very short.")

    for missing_question in missing_information_questions:
        if missing_question["priority"] == "critical":
            readiness_blockers.append(missing_question["question"])

    high_priority_missing_question_count = sum(
        1 for missing_question in missing_information_questions if missing_question["priority"] == "high"
    )

    if readiness_blockers:
        return "provisional", readiness_blockers
    if high_priority_missing_question_count > 0:
        return "provisional", ["High-priority context is missing."]
    if len(missing_information_questions) > 0:
        return "scoring_ready", []
    return "management_review_ready", []


def build_aisv_vector_string(
    factor_assessments: list[dict[str, Any]],
    evidence_confidence_score: int,
    impact_domain_tags: list[str],
) -> str:
    """Build a compact AISV vector string."""
    factor_value_lookup = {
        factor_assessment["factor"]: factor_assessment["proposed_value"]
        for factor_assessment in factor_assessments
    }

    return (
        f"AISV:{AISV_VECTOR_VERSION}"
        f"/IM:{factor_value_lookup.get('IM')}"
        f"/LE:{factor_value_lookup.get('LE')}"
        f"/PV:{factor_value_lookup.get('PV')}"
        f"/CW:{factor_value_lookup.get('CW')}"
        f"/BC:{factor_value_lookup.get('BC')}"
        f"/CD:{factor_value_lookup.get('CD')}"
        f"/RU:{factor_value_lookup.get('RU')}"
        f"/EC:{evidence_confidence_score}"
        f"/D:{','.join(impact_domain_tags)}"
    )


def convert_confidence_label_to_score(confidence_label: str) -> int:
    """Convert a confidence label to a 0-4 value for the vector string."""
    return {
        "none": 0,
        "low": 1,
        "moderate": 2,
        "high": 3,
        "confirmed": 4,
    }.get(confidence_label, 0)
