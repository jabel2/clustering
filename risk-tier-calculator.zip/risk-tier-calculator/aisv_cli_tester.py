"""
AISV CLI Tester

This is the command-line entry point for the AISV prototype. It handles:

- Prompting the user for an audit issue
- Calling the current heuristic extraction layer
- Calling the AISV scoring layer
- Printing a readable result
- Saving the full JSON result
- Configuring logging
"""

from __future__ import annotations

import json
import logging
import argparse
import textwrap
from datetime import datetime
from pathlib import Path
from typing import Any

from aisv_heuristic_extractor import build_heuristic_extraction_result
from aisv_scoring import apply_aisv_scoring


WORKSPACE_DIRECTORY = Path(__file__).resolve().parent
VAULT_DIRECTORY = WORKSPACE_DIRECTORY / "risk-tiering-vault"
TEST_RUN_OUTPUT_DIRECTORY = VAULT_DIRECTORY / "test-runs"
LOG_DIRECTORY = WORKSPACE_DIRECTORY / "logs"
LOG_FILE_PATH = LOG_DIRECTORY / "aisv_cli_tester.log"


def configure_logging() -> None:
    """Configure detailed file logging and warning-only console logging."""
    LOG_DIRECTORY.mkdir(parents=True, exist_ok=True)

    log_message_format = "%(asctime)s | %(levelname)s | %(message)s"

    detailed_file_log_handler = logging.FileHandler(LOG_FILE_PATH, encoding="utf-8")
    detailed_file_log_handler.setLevel(logging.INFO)
    detailed_file_log_handler.setFormatter(logging.Formatter(log_message_format))

    warning_console_log_handler = logging.StreamHandler()
    warning_console_log_handler.setLevel(logging.WARNING)
    warning_console_log_handler.setFormatter(logging.Formatter(log_message_format))

    logging.basicConfig(
        level=logging.INFO,
        handlers=[detailed_file_log_handler, warning_console_log_handler],
    )


def collect_multiline_audit_issue_description() -> str:
    """Prompt the user to paste an audit issue description."""
    print()
    print("Paste the internal audit issue description below.")
    print("Include background, issue text, evidence, root cause, impact, and action plan if you have them.")
    print("Type END on its own line when finished.")
    print()

    audit_issue_input_lines: list[str] = []

    while True:
        current_input_line = input("> ")
        if current_input_line.strip().upper() == "END":
            break
        audit_issue_input_lines.append(current_input_line)

    audit_issue_description = "\n".join(audit_issue_input_lines).strip()
    logging.info("Collected audit issue description with %s characters.", len(audit_issue_description))
    return audit_issue_description


def save_extraction_result_to_json(extraction_result: dict[str, Any]) -> Path:
    """Save the AISV result to a timestamped JSON file."""
    TEST_RUN_OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    timestamp_for_filename = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file_path = TEST_RUN_OUTPUT_DIRECTORY / f"aisv_result_{timestamp_for_filename}.json"

    with output_file_path.open("w", encoding="utf-8") as output_file:
        json.dump(extraction_result, output_file, indent=2)

    logging.info("Saved AISV result to %s", output_file_path)
    return output_file_path


def parse_command_line_arguments() -> argparse.Namespace:
    """Parse command-line arguments for the CLI tester."""
    argument_parser = argparse.ArgumentParser(
        description="Prompt for an audit issue and produce a provisional AISV v0.2 result."
    )
    argument_parser.add_argument(
        "--extractor",
        choices=["llm", "heuristic"],
        default="llm",
        help="Extraction mode. Default is llm. Use heuristic for offline testing.",
    )
    argument_parser.add_argument(
        "--allow-heuristic-fallback",
        action="store_true",
        help="If LLM extraction fails, fall back to the heuristic extractor.",
    )
    return argument_parser.parse_args()


def build_extraction_result_with_selected_extractor(
    audit_issue_description: str,
    extractor_name: str,
    allow_heuristic_fallback: bool,
) -> dict[str, Any]:
    """Build an extraction result using the selected extraction layer."""
    if extractor_name == "heuristic":
        logging.info("Using heuristic extractor by user request.")
        return build_heuristic_extraction_result(audit_issue_description)

    try:
        logging.info("Using AISV v0.2 LLM extractor.")
        from aisv_llm_extractor import build_llm_extraction_result

        return build_llm_extraction_result(audit_issue_description)
    except Exception as extraction_error:
        logging.exception("AISV LLM extraction failed.")
        if allow_heuristic_fallback:
            logging.warning("Falling back to heuristic extraction after LLM extraction failure.")
            return build_heuristic_extraction_result(audit_issue_description)
        raise RuntimeError(
            f"LLM extraction failed: {extraction_error}\n"
            "Set Azure OpenAI/LangChain configuration or rerun with --extractor heuristic."
        ) from extraction_error


def print_readable_result(extraction_result: dict[str, Any]) -> None:
    """Print a human-readable result for the CLI."""
    aisv_result = extraction_result["aisv_result"]
    scoring_inputs = extraction_result["scoring_inputs"]
    issue_anatomy = extraction_result["issue_anatomy"]
    quality_checks = extraction_result["quality_checks"]
    extractor_name = extraction_result["extraction_metadata"]["extractor"]

    print()
    print("=" * 80)
    print("AISV PROVISIONAL RESULT")
    print("=" * 80)
    print(f"Suggested Tier:      {aisv_result['suggested_tier']}")
    if aisv_result.get("score_based_tier") and aisv_result["score_based_tier"] != aisv_result["suggested_tier"]:
        print(f"Score-Based Tier:    {aisv_result['score_based_tier']}")
    print(f"AISV Score:          {aisv_result['aisv_score']}")
    print(f"Evidence Confidence: {aisv_result['evidence_confidence']}")
    print(f"Scoring Readiness:   {scoring_inputs['scoring_readiness']}")
    print(f"Extractor:           {extractor_name}")
    print(f"Vector:              {aisv_result['aisv_vector']}")
    print()

    print("Extracted Issue Anatomy")
    print("-" * 80)
    print_wrapped_label_and_value("Condition", issue_anatomy["condition"]["value"])
    print_wrapped_label_and_value("Criteria", issue_anatomy["criteria"]["value"])
    print_wrapped_label_and_value("Cause", issue_anatomy["cause"]["value"])
    print_wrapped_label_and_value("Consequence", issue_anatomy["consequence"]["value"])
    print()

    print("Factor Assessments")
    print("-" * 80)
    for factor_assessment in scoring_inputs["factor_assessments"]:
        factor_line = (
            f"{factor_assessment['factor']}: "
            f"{factor_assessment['proposed_value']} "
            f"({factor_assessment['confidence']}) - "
            f"{factor_assessment['rationale']}"
        )
        print(textwrap.fill(factor_line, width=100, subsequent_indent="    "))
    print()

    if scoring_inputs["missing_information_questions"]:
        print("Missing Information Questions")
        print("-" * 80)
        for missing_question in scoring_inputs["missing_information_questions"]:
            print(f"[{missing_question['priority'].upper()}] {missing_question['question']}")
            print(textwrap.fill(f"Reason: {missing_question['reason_needed']}", width=100, subsequent_indent="    "))
        print()

    if scoring_inputs["readiness_blockers"]:
        print("Readiness Blockers")
        print("-" * 80)
        for readiness_blocker in scoring_inputs["readiness_blockers"]:
            print(f"- {readiness_blocker}")
        print()

    if aisv_result.get("tier_review_flags"):
        print("Tier Review Flags")
        print("-" * 80)
        for tier_review_flag in aisv_result["tier_review_flags"]:
            flag_line = (
                f"{tier_review_flag['flag']} "
                f"({tier_review_flag['tier_floor']}): "
                f"{tier_review_flag['rationale']}"
            )
            print(textwrap.fill(flag_line, width=100, subsequent_indent="    "))
        print()

    if quality_checks.get("extraction_warnings"):
        print("Quality Warnings")
        print("-" * 80)
        for extraction_warning in quality_checks["extraction_warnings"]:
            print(textwrap.fill(f"- {extraction_warning}", width=100, subsequent_indent="  "))
        print()

    print("Important Caveat")
    print("-" * 80)
    if extractor_name == "llm":
        caveat_text = (
            "This CLI uses an LLM to decompose the audit issue, then applies deterministic AISV scoring. "
            "The result is still provisional and should be reviewed by a human."
        )
    else:
        caveat_text = (
            "This CLI used simple keyword heuristics so you can test the AISV structure offline. "
            "It should not be treated as a final audit tiering decision."
        )
    print(textwrap.fill(caveat_text, width=100))
    print("=" * 80)
    print()


def print_wrapped_label_and_value(label: str, value: str | None) -> None:
    """Print a label/value pair with readable wrapping."""
    display_value = value if value else "[missing]"
    wrapped_value = textwrap.fill(display_value, width=96, subsequent_indent=" " * (len(label) + 2))
    print(f"{label}: {wrapped_value}")


def main() -> None:
    """Run the AISV CLI tester."""
    command_line_arguments = parse_command_line_arguments()
    configure_logging()
    logging.info("Starting AISV CLI tester.")

    audit_issue_description = collect_multiline_audit_issue_description()

    if not audit_issue_description:
        logging.warning("No audit issue description was entered.")
        print("No audit issue description was entered. Exiting.")
        return

    extraction_result = build_extraction_result_with_selected_extractor(
        audit_issue_description,
        command_line_arguments.extractor,
        command_line_arguments.allow_heuristic_fallback,
    )
    scored_extraction_result = apply_aisv_scoring(extraction_result)
    output_file_path = save_extraction_result_to_json(scored_extraction_result)
    print_readable_result(scored_extraction_result)
    print(f"Full JSON result saved to: {output_file_path}")
    logging.info("AISV CLI tester completed successfully.")


if __name__ == "__main__":
    main()
