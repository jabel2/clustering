# AISV - LLM Test Analysis 2026-06-22

**Created:** 2026-06-22 22:17 -04:00  
**Related:** [[AISV - CLI Tester]], [[AISV - Structured Extraction Schema]], [[Audit Issue Severity Vector - Draft Methodology]]

## Test Summary

The user ran the v0.2 LLM extractor against a sample issue involving an unauthorized Marketing Department migration of customer PII to an unsanctioned external cloud provider.

The LLM extraction succeeded and produced a parsed Pydantic object. The deterministic scoring layer used the LLM-provided factor assessments and produced:

- Suggested tier: Tier 2
- AISV score: 75.0
- Evidence confidence displayed: moderate
- Scoring readiness: provisional
- Vector: `AISV:0.2/IM:3/LE:3/PV:3/CW:3/BC:3/CD:3/RU:3/EC:2/D:DATA,TECH,REG,FIN`

## What Worked

- The LLM handled messy pasted text with limited formatting and decomposed it into meaningful sections.
- It extracted condition, criteria, cause, consequence, control objective, action plan, data sources, and impact domains well.
- It recognized major evidence: 450 GB customer PII transfer, no ITSM approvals, $14,250 unapproved spend, vulnerability scan findings, no encryption at rest.
- The Pydantic structured output path is working.
- The scoring layer correctly used LLM-provided factor assessments rather than falling back to keyword scoring.

## Issues Observed

### Debug Output

The CLI printed the full raw model response before the readable AISV output. This creates a noisy and potentially sensitive terminal experience.

Recommended fix:

- Remove `print("Model response:", model_response)` from `aisv_llm_extractor.py`.
- If raw output is needed, write it to debug logs only behind an explicit debug flag.

### Metadata Hallucination

The LLM populated `extraction_id` as `example_extraction_id` and `extracted_at` as `2023-10-01T12:00:00Z`.

Recommended fix:

- Do not let the LLM generate operational metadata.
- Set `extraction_id`, `extracted_at`, `extractor`, and `human_review_required` programmatically after model parsing.

### Evidence Confidence vs Scoring Readiness

The LLM reported `evidence_confidence_overall` as high, but the displayed result showed evidence confidence as moderate because the scoring layer recalculated and overwrote evidence confidence based on missing high-priority context.

Recommended fix:

- Preserve evidence confidence as a measure of evidence support.
- Separately report scoring readiness/context completeness.
- Missing context should make the result provisional, but should not necessarily reduce evidence confidence.

### Factor Rationales Need Better Discipline

The factor values were all scored as 3, which may be plausible directionally but feels too flat.

Observed examples:

- PV rationale described policy violation rather than scope/pervasiveness.
- CW rationale described compliance breach rather than control weakness severity.
- CD rationale described control design rather than compensating controls/detectability.
- RU rationale described regulatory risk rather than timing/urgency.

Recommended fix:

- Strengthen factor definitions in the LLM prompt.
- Require each factor rationale to explain that factor specifically.
- Add validation that flags rationales containing signs of factor mismatch.

### Missing Information Questions Too Broad

The missing questions were useful, but both were mapped to all factors.

Recommended fix:

- Require targeted `affected_factors`.
- Population size should usually affect PV, LE, IM, and possibly BC.
- Specific regulation should usually affect IM, BC, RU, and REG context.

### Evidence Support Too Broad

Each evidence item supported all factors, which weakens traceability.

Recommended fix:

- Require evidence items to map only to the factors they directly support.
- Example: firewall logs support LE/PV/IM/DATA; billing records support FIN/process bypass; vulnerability scan supports CW/CD/IM.

### Tier Gates Missing

The score produced Tier 2 at 75.0. That may be reasonable, but the scenario includes customer PII, 450 GB transfer, unapproved external cloud, no encryption at rest, no approval, and immediate containment.

Recommended fix:

- Add v0.2 tier gates/review flags.
- This issue may not automatically be Tier 1, but should likely trigger a Tier 1 candidate review or executive escalation flag.

### Python 3.14 Warning

The run emitted a LangChain/Pydantic warning about Pydantic V1 compatibility with Python 3.14.

Recommended fix:

- Use Python 3.12 or 3.13 for the prototype until the dependency stack fully supports Python 3.14.
- Do not hide the warning until confirming runtime compatibility.

## Discussion Question

The core design choice is whether AISV should:

1. Treat this as a high Tier 2 by score, with a Tier 1 review flag; or
2. Use hard gates to elevate certain data/privacy scenarios to Tier 1 candidate status automatically.

This is a good calibration example because it is severe, but not necessarily proven as a realized breach.

## Implemented Tightening

Completed on 2026-06-22 22:26 -04:00:

- Removed raw model-response printing from the CLI path.
- Removed hardcoded LLM credential material from code and moved provider setup to environment variables.
- Added environment-driven provider support for Azure OpenAI and OpenRouter.
- Set operational metadata programmatically: extraction ID, extraction timestamp, extractor, and human review flag.
- Strengthened the LLM prompt with factor-specific definitions for IM, LE, PV, CW, BC, CD, and RU.
- Instructed the LLM to map missing information and evidence only to directly affected factors.
- Preserved LLM-provided evidence confidence separately from scoring readiness.
- Added generic tier review/floor gates:
  - Severe impact plus broad scope or very high business criticality.
  - Data/regulatory impact plus significant control weakness, weak detectability/compensation, and high remediation urgency.
  - High AISV score with clustered high impact, business criticality, control weakness, and urgency.
  - Senior review for high impact/exposure with weak detection.
- Updated CLI output to show score-based tier when a gate changes the final suggested tier.
- Added quality warnings for likely factor-rationale mismatches.

## Replay Result After Tightening

Replaying the saved LLM result through the updated scoring layer, without calling the LLM again, changed the final AISV result to:

- Suggested tier: Tier 1
- Score-based tier: Tier 2
- AISV score: 75.0
- Triggered flags:
  - `tier_1_floor_data_regulatory_control_failure`
  - `tier_1_candidate_high_score_cluster`
  - `senior_review_high_exposure_weak_detection`

This matches the discussion: the score alone placed the issue in Tier 2, but the severity pattern justifies Tier 1 treatment or at minimum Tier 1-level review.
