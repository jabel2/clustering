# Research - Tiering Framework Landscape

**Created:** 2026-06-14 23:20 -04:00  
**Status:** First-pass landscape scan  
**Related:** [[Problem Framing - Audit Issue Tiering]], [[Audit Issue Severity Vector - Draft Methodology]]

## Research Question

What existing standards, frameworks, and scoring approaches could inform a more transparent, consistent, defensible, evidence-based audit issue tiering process?

## Early Finding

There does not appear to be one obvious off-the-shelf framework that directly solves internal audit issue tiering across business-process, operational, financial, technology, and enterprise risks. The useful path is likely to combine design principles from several framework families:

- Internal audit standards and topical baselines for audit legitimacy.
- General risk management frameworks for context, criteria, and communication.
- Cybersecurity scoring systems for structured factors, vector strings, environmental adjustment, and explainability.
- Quantitative risk frameworks for separating event frequency from loss magnitude.
- Decision analysis methods for transparent multi-factor judgment.

## Source Families

### IIA / Internal Audit

#### IIA Global Internal Audit Standards

Source: [The IIA - Global Internal Audit Standards](https://www.theiia.org/en/standards/2024-standards/global-internal-audit-standards/)

Relevant points:

- The 2024 Global Internal Audit Standards are mandatory within the IPPF and are expected for internal audit functions.
- The standards are principle-based rather than a deterministic issue-tiering algorithm.
- They emphasize effective planning, engagement work, communication, monitoring action plans, objectivity, competency, due professional care, and quality.

Transferable design principle:

- Any tiering model should preserve professional judgment and due professional care, but make the reasoning trail more explicit and reviewable.

#### IIA Topical Requirements

Source: [The IIA - Topical Requirements](https://www.theiia.org/en/standards/2024-standards/topical-requirements/)

Relevant points:

- Topical Requirements are mandatory when applicable and are meant to improve consistency and quality for specific risk areas.
- They provide minimum baseline and relevant criteria for assessing governance, risk management, and control processes in particular topics.
- The IIA explicitly allows use of other frameworks if internal audit can demonstrate that the framework covers applicable requirements.

Transferable design principle:

- For audit tiering, this suggests a "minimum baseline + explain deviations" model rather than a rigid one-size-fits-all score.

#### IIA Topical Requirements Application Guidance

Source: [The IIA - Topical Requirements Application Guidance](https://www.theiia.org/en/content/topical-requirements/topical-requirements-application-guidance/)

Relevant points:

- The guidance emphasizes professional judgment and a risk-based approach.
- It introduces a "conform or explain" principle for documenting and communicating deviations from requirements.
- It recognizes organizational context, limitations, and overlapping frameworks.

Transferable design principle:

- A tiering framework could use "score or explain" / "model recommendation or documented override" as a governance pattern.

### General Risk Management

#### ISO 31000

Source: [ISO 31000:2018](https://www.iso.org/standard/65694.html)

Relevant points:

- ISO 31000 gives principles and guidelines for risk management.
- It emphasizes identifying, analyzing, evaluating, treating, monitoring, and communicating risks across an organization.
- It supports contextualizing risk management to any organization and embedding it into governance, strategy, reporting, policies, values, and culture.

Transferable design principle:

- Tiering should explicitly include context, criteria, communication, and monitoring rather than just impact scoring.

#### IEC 31010

Source: [IEC 31010:2019](https://www.iso.org/standard/72140.html)

Relevant points:

- IEC 31010 is a risk assessment techniques standard.
- It is likely useful for selecting assessment techniques such as risk matrices, scenario analysis, decision trees, bow-tie analysis, FMEA, and multi-criteria methods.

Transferable design principle:

- The final model may need several techniques: one for extracting facts, one for scoring factors, and one for explaining/calibrating the result.

#### COSO ERM

Source: [COSO Enterprise Risk Management](https://www.coso.org/guidance-erm)

Relevant points:

- COSO ERM focuses on integrating risk management with strategy and performance.
- COSO notes that increasing risk complexity and demands for improved risk reporting drove the 2017 update.
- COSO has related guidance on risk appetite, compliance risk management, cyber risk, board oversight, and risk assessment in practice.

Transferable design principle:

- Tiering should connect the issue to objectives, risk appetite/tolerance, business performance, and board/senior-management reporting needs.

### Cybersecurity / Technology Scoring and Knowledge Frameworks

#### NIST SP 800-30

Source: [NIST SP 800-30 Rev. 1](https://csrc.nist.gov/pubs/sp/800/30/r1/final)

Relevant points:

- NIST SP 800-30 provides guidance for conducting risk assessments.
- It supports senior leaders by providing information needed to determine appropriate responses to identified risks.
- It recognizes risk assessments across multiple tiers in a risk management hierarchy.

Transferable design principle:

- This supports a tiering model that separates local issue facts from senior-management decision context.

#### NIST Cybersecurity Framework

Source: [NIST Cybersecurity Framework 2.0](https://www.nist.gov/cyberframework)

Relevant points:

- CSF 2.0 is designed to help organizations better understand and improve management of cybersecurity risk.
- It includes resources such as profiles and informative mappings.
- The framework is outcome-oriented and maps across related standards and practices.

Transferable design principle:

- A tiering framework could map audit issues to expected control/risk outcomes and maintain mappings to multiple source frameworks.

#### CVSS v4.0

Source: [FIRST CVSS v4.0 Specification](https://www.first.org/cvss/v4-0/specification-document)

Relevant points:

- CVSS separates Base, Threat, Environmental, and Supplemental metric groups.
- It produces a score and a vector string that documents the specific metric values used.
- Environmental metrics allow the consumer organization to adjust severity to its environment.
- The specification cautions that the usefulness of the number depends on which metrics are used and communicated.

Transferable design principle:

- For audit tiering, a "tier vector" may be more valuable than a raw tier. The vector can show the factors: impact, pervasiveness, control weakness, evidence confidence, stakeholder/customer impact, financial/regulatory exposure, remediation urgency, compensating controls, and management override rationale.

#### EPSS

Source: [FIRST EPSS](https://www.first.org/epss/)

Relevant points:

- EPSS is a data-driven model estimating the probability a CVE will be exploited in the wild in the next 30 days.
- It complements severity scoring by adding likelihood evidence from empirical signals.

Transferable design principle:

- Historical audit issue data could serve a similar role: not as the sole determinant, but as empirical calibration for how similar issues were previously rated and remediated.

#### MITRE ATT&CK

Source: [MITRE ATT&CK](https://attack.mitre.org/)

Relevant points:

- ATT&CK is a globally accessible knowledge base of adversary tactics and techniques based on real-world observations.
- It is used as a foundation for threat models and methodologies across private sector, government, and cybersecurity products/services.

Transferable design principle:

- The value is not a score; it is a shared language and taxonomy. Audit tiering likely needs a similar taxonomy for business-process risk patterns.

#### MITRE CWE / CWSS

Source: [MITRE CWSS](https://cwe.mitre.org/cwss/cwss_v1.0.1.html)

Relevant points:

- CWSS provides a quantitative measurement and common framework for prioritizing software weaknesses.
- It divides scoring into Base Finding, Attack Surface, and Environmental metric groups.
- It includes factors such as technical impact, control effectiveness, finding confidence, deployment scope, business impact, likelihood of discovery, likelihood of exploit, and prevalence.

Transferable design principle:

- CWSS is especially relevant because it scores a finding, not just an abstract risk. The structure maps well to audit issue tiering: inherent issue characteristics, exposure/scope, environment/business context, controls, and confidence.

### Quantitative Risk

#### Open FAIR / The Open Group Risk Taxonomy

Source: [The Open Group Risk Taxonomy (O-RT), Version 3.1](https://publications.opengroup.org/c251)

Relevant points:

- The Open Group Risk Taxonomy provides a standard definition and taxonomy for information security risk.
- The current page identifies version 3.1 as updated in May 2025 and as a companion to the Open Group Risk Analysis standard.
- FAIR-style thinking decomposes risk into frequency and magnitude rather than collapsing everything into one vague severity label.

Transferable design principle:

- Business-process audit findings may become more defensible if the model separates "how bad if it occurs" from "how likely / how exposed / how often this condition can produce loss."

## Candidate Design Principles for Our Tiering Model

1. Preserve professional judgment, but force it to be expressed as explicit factors.
2. Separate issue facts from environmental/contextual modifiers.
3. Separate impact magnitude from likelihood/exposure.
4. Include evidence confidence as a first-class factor.
5. Include pervasiveness/scope, not just local issue depth.
6. Include compensating controls and control effectiveness.
7. Use a vector-style rationale so reviewers can see what drove the recommendation.
8. Allow override, but require a documented rationale.
9. Use historical issues for calibration, not blind automation.
10. Map issue dimensions to source frameworks so the model is auditable.

## Open Research Questions

- Does IIA publish or endorse any issue-rating-specific guidance beyond general Standards and Topical Requirements?
- Are there public internal audit departments with mature issue rating matrices we can compare?
- Which factor set best covers business-process risks without overfitting to cybersecurity?
- Can we construct a CVSS/CWSS-inspired "Audit Issue Severity Vector"?
- What minimum explanation would satisfy both staff auditors and senior audit management?
- How should historical issues be used when context is missing from the database?
- What should trigger an override, and who must approve it?

## First-Pass Conclusion

The most promising starting point is not one external framework, but a hybrid:

- IIA for audit legitimacy and professional judgment.
- ISO/COSO/NIST for risk management process, context, and communication.
- CVSS/CWSS for factorized scoring and vector explanations.
- FAIR for likelihood/magnitude decomposition.
- MITRE ATT&CK-style taxonomy for shared language and repeatable classification.

The strongest single structural inspiration appears to be CWSS/CVSS: metric groups plus environmental context plus an explicit vector. The strongest governance inspiration appears to be the IIA Topical Requirements "conform or explain" logic.

## Follow-On Draft

- [[Audit Issue Severity Vector - Draft Methodology]]
