Audit Issue Severity Vector - Draft Methodology

**Created:** 2026-06-14 23:25 -04:00  
**Status:** Draft v0.1 critiqued as too simplistic; needs deeper methodology  
**Related:** [[Problem Framing - Audit Issue Tiering]], [[Research - Tiering Framework Landscape]], [[AISV - Input Decomposition Pipeline]], [[AISV - Structured Extraction Schema]]

## Purpose

The Audit Issue Severity Vector (AISV) is a proposed methodology for making audit issue tiering more transparent, consistent, defensible, and evidence-based while preserving professional judgment.

It is not intended to replace auditor judgment. It is intended to make judgment explicit, comparable, reviewable, and easier to calibrate across audit teams.

## Design Principles

1. Preserve professional judgment, but require it to be expressed through visible factors.
2. Score the issue, not the auditor.
3. Separate risk severity from evidence confidence.
4. Separate impact magnitude from likelihood/exposure.
5. Make scope/pervasiveness explicit.
6. Include control weakness severity and compensating controls.
7. Use a vector string so reviewers can see what drove the recommendation.
8. Compare against historical issues for calibration, not blind automation.
9. Allow overrides, but require a documented factor-level rationale.
10. Support staff auditor defensibility and senior management cross-team comparison.

## Model Overview

AISV produces four outputs:

1. **Severity score:** 0-100 score based on structured factors.
2. **Suggested tier:** Initial mapping from score to Tier 1, Tier 2, Tier 3, or Tier 4.
3. **Confidence label:** How well the issue is substantiated.
4. **Vector string:** A compact representation of the selected factors.

The key move is separating:

- **How severe the issue appears to be**, based on impact, exposure, scope, controls, and urgency.
- **How confident audit is in that assessment**, based on evidence quality and completeness.

This avoids treating low evidence as low risk. Low evidence should produce a substantiation flag, not automatically a lower tier.

## Core Scoring Factors

Each factor is scored from 0 to 4.

### IM - Impact Magnitude

How severe would the consequence be if the issue is realized, or how severe is the realized consequence already observed?

| Score | Meaning |
|---|---|
| 0 | No meaningful business, compliance, operational, financial, customer, or strategic impact. |
| 1 | Limited impact; localized inconvenience, minor rework, or low-value process friction. |
| 2 | Moderate impact; meaningful inefficiency, control gap, customer/process friction, or manageable financial/compliance exposure. |
| 3 | Significant impact; material business-process disruption, regulatory concern, meaningful financial exposure, customer harm, or management attention. |
| 4 | Severe impact; enterprise-critical objective, major regulatory/legal exposure, material financial loss, significant customer harm, safety concern, or board-level risk. |

### LE - Likelihood / Exposure

How readily can the issue produce harm, considering frequency, triggering conditions, transaction volume, and whether harm has already occurred?

| Score | Meaning |
|---|---|
| 0 | Theoretical only; no clear path to harm. |
| 1 | Unlikely; requires several unusual conditions. |
| 2 | Plausible; credible scenario exists, but not routine or frequent. |
| 3 | Likely or recurring; issue appears in normal operations or meaningful transaction volume. |
| 4 | Active, ongoing, high-frequency, or already realized. |

### PV - Pervasiveness / Scope

How broadly does the issue apply across the organization, business domains, systems, products, customers, or processes?

| Score | Meaning |
|---|---|
| 0 | Single instance with no broader pattern. |
| 1 | Localized to one team, process step, record type, or small population. |
| 2 | Applies across one business area, product, platform, or meaningful process population. |
| 3 | Applies across multiple business areas, systems, teams, or risk domains. |
| 4 | Enterprise-wide, foundational, systemic, or affecting a shared service/control relied on broadly. |

### CW - Control Weakness Severity

How severe is the control design or operating weakness?

| Score | Meaning |
|---|---|
| 0 | No meaningful control weakness; issue is informational or improvement-oriented. |
| 1 | Documentation, ownership, or process clarity gap with limited control effect. |
| 2 | Operating deficiency; control exists but failed in some instances. |
| 3 | Key control ineffective, inconsistently executed, or missing important design elements. |
| 4 | Control absent, fundamentally misdesigned, systemically ineffective, or unable to prevent/detect the risk. |

### BC - Business Criticality / Risk Appetite

How important is the affected objective, process, system, obligation, or population to the organization?

| Score | Meaning |
|---|---|
| 0 | Non-core objective with little organizational consequence. |
| 1 | Support process with limited risk appetite relevance. |
| 2 | Important business objective or process, but not critical. |
| 3 | Critical business, financial, customer, compliance, technology, or operational objective. |
| 4 | Board, regulator, enterprise, safety, customer trust, or strategic objective with low tolerance for failure. |

### CD - Compensating Controls / Detectability

How much do other controls, monitoring, reconciliation, review, or detection mechanisms reduce concern?

Higher score means weaker compensation and higher concern.

| Score | Meaning |
|---|---|
| 0 | Strong compensating controls are tested, effective, timely, and independent. |
| 1 | Good compensating controls exist, with minor limitations. |
| 2 | Partial, indirect, manual, or untested compensating controls. |
| 3 | Weak, late, informal, or unreliable compensating controls. |
| 4 | No meaningful compensating controls or issue was only identified by audit. |

### RU - Remediation Urgency

How quickly does the issue need to be addressed to avoid unacceptable exposure?

| Score | Meaning |
|---|---|
| 0 | No time sensitivity; can be handled in normal continuous improvement cycle. |
| 1 | Low urgency; next planning or process cycle is reasonable. |
| 2 | Moderate urgency; should be addressed in a defined near-term action plan. |
| 3 | High urgency; delay materially increases exposure, reporting concern, or stakeholder impact. |
| 4 | Immediate urgency; ongoing harm, regulatory deadline, severe exposure, or urgent containment needed. |

## Evidence Confidence

Evidence Confidence is scored separately from risk severity.

### EC - Evidence Confidence

How well substantiated is the factor assessment?

| Score | Meaning | Output Label |
|---|---|---|
| 0 | Assertion only; insufficient evidence. | Insufficient |
| 1 | Limited evidence; anecdotal, incomplete, or not yet tied to population. | Low |
| 2 | Moderate evidence; sample results or credible support, but some uncertainty remains. | Moderate |
| 3 | Strong evidence; testing, data, stakeholder corroboration, or repeat observations support the assessment. | Strong |
| 4 | Confirmed evidence; population-level analysis, realized event, external validation, or highly conclusive support. | Confirmed |

Evidence rule:

- EC should not mechanically lower severity.
- If AISV score is high and EC is low, output should be "provisional high-severity candidate" with named evidence gaps.
- If EC is low, the right question is not "should the tier be lower?" but "what specific evidence would confirm or disconfirm the factor values?"

## Impact Domain Tags

AISV should tag the primary and secondary impact domains. These tags help compare unlike issues and explain why a business-process issue can be severe even when it is not enterprise-wide technology risk.

Suggested tags:

- FIN - Financial
- REG - Regulatory / Legal
- OPS - Operational
- CUS - Customer / Client / Conduct
- REP - Reputation
- STR - Strategic
- DATA - Data confidentiality, integrity, or availability
- TECH - Technology / Infrastructure
- FRAUD - Fraud / Misuse
- RES - Resilience / Continuity
- THIRD - Third-party / Vendor
- SAFETY - Safety / Human impact

## Score Calculation

Draft v0.1 weighted score:

| Factor | Weight |
|---|---:|
| IM - Impact Magnitude | 25 |
| LE - Likelihood / Exposure | 15 |
| PV - Pervasiveness / Scope | 15 |
| CW - Control Weakness Severity | 15 |
| BC - Business Criticality / Risk Appetite | 10 |
| CD - Compensating Controls / Detectability | 10 |
| RU - Remediation Urgency | 10 |
| **Total** | **100** |

Formula:

```text
AISV Score =
  (IM / 4 * 25) +
  (LE / 4 * 15) +
  (PV / 4 * 15) +
  (CW / 4 * 15) +
  (BC / 4 * 10) +
  (CD / 4 * 10) +
  (RU / 4 * 10)
```

Evidence Confidence is not included in the severity score. It is reported beside the score.

## Draft Tier Mapping

This is intentionally provisional until calibrated against the organization's current tier definitions and historical issue database.

| AISV Score | Suggested Tier |
|---:|---|
| 80-100 | Tier 1 |
| 60-79 | Tier 2 |
| 35-59 | Tier 3 |
| 0-34 | Tier 4 |

Assumption: Tier 1 is highest severity and Tier 4 is lowest severity.

## Tier Floors and Gates

Simple weighted averages can hide severe issues. AISV should include tier floors/gates that force review when certain combinations appear.

Draft gates:

- **Tier 1 candidate floor:** IM = 4 and PV >= 3 and CW >= 3.
- **Tier 1 candidate floor:** IM = 4 and BC = 4 and RU >= 3.
- **Tier 2 candidate floor:** IM = 4 even if scope is local, unless strong compensating controls reduce exposure.
- **Tier 2 candidate floor:** PV = 4 and CW >= 3, even if immediate impact is not yet realized.
- **Provisional severity flag:** Score >= 60 and EC <= 1. Do not finalize downward solely due to low evidence; identify substantiation gaps.
- **Override review flag:** Final tier differs from AISV suggested tier by one or more levels.

These gates should be tested against historical issues before adoption.

## AISV Vector String

The vector string is the compact audit trail of the scoring decision.

Format:

```text
AISV:0.1/IM:3/LE:2/PV:2/CW:3/BC:3/CD:2/RU:2/EC:3/D:REG,OPS
```

Example interpretation:

- AISV version 0.1
- Impact Magnitude = 3
- Likelihood / Exposure = 2
- Pervasiveness / Scope = 2
- Control Weakness Severity = 3
- Business Criticality = 3
- Compensating Controls / Detectability = 2
- Remediation Urgency = 2
- Evidence Confidence = 3
- Impact domains = Regulatory and Operational

## Output Template

```markdown
## AISV Recommendation

**Suggested Tier:** Tier [1-4]  
**AISV Score:** [0-100]  
**Confidence:** [Insufficient / Low / Moderate / Strong / Confirmed]  
**Vector:** `AISV:0.1/IM:x/LE:x/PV:x/CW:x/BC:x/CD:x/RU:x/EC:x/D:tags`

### Primary Drivers

- [Driver 1]
- [Driver 2]
- [Driver 3]

### Substantiation Gaps

- [Gap 1]
- [Gap 2]

### Historical Calibration

- Similar prior issues: [count]
- Prior tier distribution: [Tier 1 x%, Tier 2 y%, Tier 3 z%, Tier 4 n%]
- Key differences from prior issues: [differences]

### Override / Reviewer Decision

**Final Tier:** [Tier]  
**Difference from AISV:** [none / +1 / -1 / etc.]  
**Override rationale:** [factor-level rationale required]
```

## Governance Pattern: Score or Explain

Borrowing from the IIA Topical Requirements "conform or explain" idea:

- The AISV recommendation does not have to be accepted.
- If a reviewer changes the tier, the reviewer should identify which factor value changed or which contextual fact the model missed.
- A tier change should not be documented only as "management judgment" or "not material."
- Over time, overrides should be analyzed to improve the model and detect calibration drift.

Examples:

- Acceptable: "PV reduced from 3 to 2 because evidence shows the issue applies only to one business process, not multiple domains."
- Acceptable: "CD reduced from 3 to 1 because an independent daily reconciliation was tested and shown to catch the condition within one business day."
- Weak: "Senior management viewed the issue as lower risk."
- Weak: "Stakeholders disagreed with severity."

## Review Workflow

1. Audit team drafts issue.
2. AISV factors are scored from the issue writeup, testing evidence, and known context.
3. Tool produces suggested tier, score, confidence label, vector string, primary drivers, and substantiation gaps.
4. Similar historical issues are retrieved and vectorized for calibration.
5. Audit team reviews and adjusts factor values, documenting judgment.
6. Senior management reviews factor values instead of debating only the final tier.
7. Final tier is accepted or overridden with factor-level rationale.
8. Final issue, vector, tier, and override rationale are stored for future calibration.

## Historical Calibration

Historical issues should not blindly determine the current tier because prior records may lack important context. However, they are still valuable for calibration.

Potential uses:

- Identify similar issues by vector similarity and impact domain tags.
- Show how similar issues were previously tiered.
- Identify whether current scoring is materially above or below historical patterns.
- Identify recurring reviewer overrides.
- Compare enterprise-wide technology issues against business-process issues using common factors.
- Build confidence that the model is learning from the department's own decisions.

Historical comparison should be framed as:

> "Here is how similar issues were handled before, and here is why this issue is similar or different."

not:

> "Past issues automatically determine this tier."

## What This Solves

AISV shifts the conversation from:

> "I think this is Tier 2."  
> "I think it is Tier 3."

to:

> "We disagree on pervasiveness, compensating controls, and business criticality. Let's resolve those factor values."

That is the core behavioral improvement.

## Known Weaknesses in v0.1

- User feedback: v0.1 is directionally useful but too simplistic for the intended product. Many high-level factors already exist in current frameworks. The product needs a much more detailed, depth-oriented methodology to be successful.
- Factor weights are uncalibrated.
- Tier thresholds may not align with the organization's current tier definitions.
- Some factors may overlap, especially Impact Magnitude and Business Criticality.
- Business-process risks may need additional factors not yet represented.
- Evidence Confidence needs careful handling so it does not become an excuse to lower valid but hard-to-prove risks.
- Historical issue data may lack context needed for accurate comparison.

## Required Depth for v0.2

The next version should move beyond simple factor scoring into a layered methodology:

1. **Issue anatomy layer:** Break an audit issue into condition, criteria, cause, consequence, control objective, population, exception pattern, and management response.
2. **Risk mechanics layer:** Describe how the issue creates harm, including event pathway, triggering conditions, exposure window, frequency, and magnitude.
3. **Evidence layer:** Define evidence types, evidence strength, population coverage, testing depth, corroboration, and remaining uncertainty.
4. **Context layer:** Capture enterprise importance, business criticality, risk appetite, affected stakeholders, regulatory obligations, customer impact, and strategic relevance.
5. **Control environment layer:** Assess design effectiveness, operating effectiveness, compensating controls, monitoring, detectability, and remediation feasibility.
6. **Comparability layer:** Compare current issue to historical issues, peer issues, known patterns, and domain-specific frameworks.
7. **Decision layer:** Produce suggested tier, rationale, confidence, disagreement points, override path, and required documentation.

The model should be deep enough that disagreements become specific:

- Which fact is disputed?
- Which criterion is disputed?
- Which evidence standard is unmet?
- Which contextual modifier changes severity?
- Which historical comparator is most relevant?
- Which professional judgment override is being applied?

The goal is not just to calculate a tier. The goal is to structure the audit conversation so that tier changes are traceable to clear factor, evidence, or context changes.

## Input Decomposition

See [[AISV - Input Decomposition Pipeline]] for the proposed product flow where an LLM decomposes issue descriptions into structured facts, identifies missing information, and hands structured inputs to the AISV scoring layer.

See [[AISV - Structured Extraction Schema]] and [[schemas/aisv-extraction-schema-v0.1.json]] for the draft data contract between audit issue text and the scoring engine.

## Next Questions

- Are these the right factors?
- Which factors are missing for internal audit issue tiering?
- Which factors overlap too much?
- Are the draft tier thresholds directionally reasonable?
- Should any factor be a hard gate rather than weighted?
- What would auditors and senior management trust or reject in this model?
