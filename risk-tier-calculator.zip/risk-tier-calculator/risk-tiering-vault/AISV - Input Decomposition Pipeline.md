# AISV - Input Decomposition Pipeline

**Created:** 2026-06-20 11:16 -04:00  
**Status:** Draft v0.1  
**Related:** [[Audit Issue Severity Vector - Draft Methodology]], [[Problem Framing - Audit Issue Tiering]], [[AISV - Structured Extraction Schema]]

## Product Assumption

The primary user input will be an internal audit issue description. It may include:

- Background
- Issue text
- Evidence supporting the conclusion
- Root cause
- Criteria or standard violated
- Impact or risk statement
- Management response or action plan
- Testing performed
- Exception details
- Bulletized notes or narrative paragraphs

The input may be incomplete, inconsistent, or written in different styles across audit teams.

## Core Product Pattern

The LLM should not be the final tiering authority by itself.

Instead, the product should separate the work into three layers:

1. **LLM decomposition layer:** Extract structured facts from the audit issue text.
2. **Completeness and context layer:** Identify missing information and optionally enrich with additional context.
3. **AISV scoring layer:** Apply deterministic or semi-deterministic scoring rules to the structured facts.

This keeps the methodology auditable:

- The LLM explains what it extracted and where it found it.
- The framework explains how each extracted fact maps to a score.
- The final tier can be reviewed, challenged, or overridden at the factor level.

## Proposed Workflow

1. User pastes audit issue description.
2. LLM decomposes the issue into a structured issue anatomy.
3. LLM identifies missing or weak information needed for reliable scoring.
4. Tool asks targeted follow-up questions or pulls approved contextual data.
5. LLM maps issue facts to AISV scoring factors with evidence citations.
6. Deterministic scoring engine calculates provisional AISV score and suggested tier.
7. Tool generates rationale, confidence, substantiation gaps, and historical comparators.
8. Auditor accepts, adjusts, or adds context.
9. Senior management reviews factor-level reasoning rather than debating only the tier label.
10. Final tier, vector, rationale, overrides, and factor changes are persisted for calibration.

## Structured Extraction Schema

Detailed contract: [[AISV - Structured Extraction Schema]]  
Machine-readable schema: [[schemas/aisv-extraction-schema-v0.1.json]]

The LLM should extract the following fields when available.

### Issue Anatomy

- **Issue title**
- **Condition:** What was found?
- **Criteria:** What requirement, policy, control, standard, or expected condition was not met?
- **Cause:** Why did the condition occur?
- **Consequence:** What happened or could happen?
- **Population:** What population was tested or affected?
- **Exceptions:** What exceptions were identified?
- **Exception rate:** Number and percentage, if available.
- **Testing performed:** What work was done to support the issue?
- **Affected process/system/business area**
- **Affected stakeholders**
- **Management response**
- **Action plan**
- **Target remediation date**

### Evidence Inventory

- **Evidence types:** Sample testing, population analysis, inquiry, observation, documentation review, system data, external reports, incident data, financial data, regulatory references.
- **Evidence strength:** Weak, moderate, strong, confirmed.
- **Evidence coverage:** Sample-only, partial population, full population, repeated tests, corroborated sources.
- **Evidence gaps:** What important information is missing?
- **Contradictory evidence:** What facts reduce severity or challenge the conclusion?

### Risk Mechanics

- **Risk event:** What bad event could happen?
- **Impact pathway:** How does the condition lead to the risk event?
- **Triggering conditions:** What must be true for the risk to materialize?
- **Exposure frequency:** How often could the risk event occur?
- **Exposure window:** How long has the condition existed or how long could it persist?
- **Loss or harm magnitude:** What is the plausible impact range?
- **Known realized impact:** Has harm already occurred?

### Control Environment

- **Control objective**
- **Control type:** Preventive, detective, corrective, directive, manual, automated.
- **Control design assessment**
- **Control operating assessment**
- **Compensating controls**
- **Monitoring or detection mechanisms**
- **Detectability**
- **Recoverability**
- **Remediation complexity**

### Context

- **Business criticality**
- **Enterprise relevance**
- **Regulatory/legal sensitivity**
- **Customer/client impact**
- **Financial exposure**
- **Operational resilience impact**
- **Data/technology impact**
- **Fraud or misuse exposure**
- **Strategic/reputational relevance**
- **Risk appetite/tolerance**

### Comparability

- **Similar historical issues**
- **Similar current issues**
- **Relevant frameworks**
- **Why this issue is similar**
- **Why this issue is different**
- **Prior tier distribution**

## Missing Information Prompts

The tool should produce targeted prompts when the issue text does not support reliable scoring.

Examples:

- "What population was tested, and how many exceptions were identified?"
- "Is the issue isolated to one business area or present across multiple teams/systems?"
- "What control objective was not met?"
- "Are there compensating controls that would prevent or detect the issue?"
- "Has any financial loss, customer impact, regulatory breach, or operational disruption already occurred?"
- "How long has this condition existed?"
- "What must happen for this condition to create actual harm?"
- "What remediation timeline is expected or required?"
- "Are there prior issues that management would consider similar?"

## LLM Output Requirements

For each extracted fact, the LLM should provide:

- Extracted value
- Source text or supporting excerpt
- Confidence in extraction
- Whether the fact is directly stated or inferred
- Whether the fact supports, reduces, or is neutral to severity
- Which AISV factors the fact may affect

The LLM should clearly separate:

- Directly stated facts
- Reasonable inferences
- Missing information
- Assumptions
- Contradictory or mitigating facts

## Scoring Handoff

The LLM should hand structured facts to the AISV scoring layer. The scoring layer should then calculate:

- IM - Impact Magnitude
- LE - Likelihood / Exposure
- PV - Pervasiveness / Scope
- CW - Control Weakness Severity
- BC - Business Criticality / Risk Appetite
- CD - Compensating Controls / Detectability
- RU - Remediation Urgency
- EC - Evidence Confidence
- Impact domain tags

The LLM may suggest factor values, but deterministic scoring rules should make the final calculation.

## Product Guardrails

- Do not allow the LLM to silently invent missing context.
- Do not allow low evidence confidence to automatically lower severity.
- Do not produce a final tier without showing factor-level rationale.
- Do not hide uncertainty.
- Do not treat historical issues as binding precedent.
- Do not let the output become a black box.

## Desired User Experience

The user should be able to paste an issue and receive:

1. A structured issue decomposition.
2. A list of missing information that would improve tier reliability.
3. A provisional AISV score and suggested tier.
4. A confidence label.
5. A vector string.
6. A plain-language rationale.
7. Historical comparators, if available.
8. A list of factor-level disagreements or uncertainty points.
9. A management-review-ready explanation.

## Key Principle

The LLM turns messy audit prose into structured, reviewable inputs.

The AISV framework turns structured inputs into an auditable severity recommendation.
