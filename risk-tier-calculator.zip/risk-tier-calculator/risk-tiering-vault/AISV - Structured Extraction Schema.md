# AISV - Structured Extraction Schema

**Created:** 2026-06-20 11:21 -04:00  
**Status:** Draft v0.1  
**Related:** [[AISV - Input Decomposition Pipeline]], [[Audit Issue Severity Vector - Draft Methodology]]

## Purpose

This note defines the structured data contract between messy internal audit issue text and the AISV scoring engine.

The schema is designed so an LLM can decompose an audit issue into explicit, reviewable facts while preserving:

- Source traceability
- Extraction confidence
- Directly stated facts vs. inferred facts
- Missing information
- Contradictory or mitigating information
- Factor-level scoring inputs

Machine-readable schemas:

- [[schemas/aisv-extraction-schema-v0.1.json]]
- [[schemas/aisv-extraction-schema-v0.2.json]]

Code-level v0.2 model:

- `aisv_llm_extractor.AISVExtraction`

The v0.2 LLM path uses the Pydantic model directly with LangChain structured output. The JSON Schema sidecar remains available for external tooling, documentation, and validation outside the Python runtime.

## Core Contract

The LLM should return one structured object:

```text
AISVExtraction
```

That object has ten major sections:

1. **extraction_metadata**
2. **source_document**
3. **issue_summary**
4. **issue_anatomy**
5. **evidence_inventory**
6. **risk_mechanics**
7. **control_environment**
8. **context**
9. **comparability**
10. **scoring_inputs**

The scoring engine should not need to parse raw prose. It should consume `scoring_inputs`, supported by the other structured sections.

## Universal Fact Object

Most extracted fields should use a standard fact object:

```json
{
  "value": "Extracted or normalized value",
  "status": "stated",
  "confidence": "high",
  "provenance": [
    {
      "section": "issue_text",
      "quote": "Short supporting quote or excerpt",
      "location": "Paragraph 2 / bullet 4"
    }
  ],
  "notes": "Optional explanation"
}
```

### status

| Value | Meaning |
|---|---|
| stated | Directly stated in the issue text. |
| inferred | Reasonably inferred from stated facts. |
| missing | Needed but not present. |
| unknown | Not enough information to determine. |
| not_applicable | Field does not apply to this issue. |
| conflicting | Source text contains competing or inconsistent signals. |

### confidence

| Value | Meaning |
|---|---|
| none | No support. |
| low | Weak or ambiguous support. |
| moderate | Some support, but uncertainty remains. |
| high | Strong support from issue text or evidence. |
| confirmed | Highly conclusive, corroborated, population-level, or realized evidence. |

## Section Details

### 1. extraction_metadata

Purpose: Track extraction status and governance.

Fields:

- **schema_version:** Contract version, currently `AISV_EXTRACT_0.1`.
- **extraction_id:** Unique ID for this extraction.
- **source_document_id:** ID of the issue, report, workpaper, or paste event.
- **extracted_at:** Timestamp.
- **extractor:** `llm`, `manual`, or `hybrid`.
- **extraction_status:** `draft`, `needs_context`, `scoring_ready`, or `rejected`.
- **human_review_required:** Whether a human must review before scoring.
- **assumptions:** Assumptions the LLM made and why.

### 2. source_document

Purpose: Preserve where the input came from and how it was organized.

Fields:

- **document_title**
- **source_type:** draft issue, final issue, historical issue, working paper, or other.
- **sections:** Raw or normalized sections such as background, issue, evidence, root cause, criteria, action plan.
- **redaction_notes**

### 3. issue_summary

Purpose: Give a normalized issue-level overview.

Fields:

- **issue_title**
- **concise_summary**
- **audit_area**
- **business_unit**
- **process**
- **system_or_application**
- **issue_type_tags**
- **impact_domain_tags**

Impact domain tags should use controlled values where possible:

- FIN - Financial
- REG - Regulatory / Legal
- OPS - Operational
- CUS - Customer / Client / Conduct
- REP - Reputation
- STR - Strategic
- DATA - Data confidentiality, integrity, or availability
- TECH - Technology / Infrastructure
- FRAUD - Fraud / Misuse
- RES - Resilience / Continuity
- THIRD - Third-party / Vendor
- SAFETY - Safety / Human impact

### 4. issue_anatomy

Purpose: Break the issue into classic audit components.

Fields:

- **condition:** What was found?
- **criteria:** What should have happened? What policy, standard, control, regulation, or expectation applies?
- **cause:** Why did the condition occur?
- **consequence:** What happened or could happen?
- **control_objective:** What objective was the control/process meant to achieve?
- **root_cause_category:** People, process, technology, governance, data, third party, training, resourcing, oversight, or unclear.
- **affected_population:** Population definition, population size, sample size, exception count, exception rate.
- **testing_performed:** What testing supports the issue?
- **management_response:** Management's stated response or disagreement.
- **action_plan:** Proposed remediation, owner, and due date.

### 5. evidence_inventory

Purpose: Make evidence depth visible before scoring.

Fields:

- **evidence_items:** Each evidence item gets an ID, type, description, coverage, strength, and supported AISV factors.
- **evidence_gaps:** Missing evidence that would materially improve scoring.
- **contradictory_evidence:** Facts that reduce severity or challenge the issue conclusion.
- **evidence_confidence_overall:** Overall confidence label.

Evidence type values:

- sample_testing
- population_analysis
- inquiry
- observation
- documentation_review
- system_data
- external_report
- incident_data
- financial_data
- regulatory_reference
- prior_issue
- other

### 6. risk_mechanics

Purpose: Explain how the issue turns into harm.

Fields:

- **risk_event:** The bad event or exposure.
- **impact_pathway:** The chain from condition to harm.
- **triggering_conditions:** What must happen for harm to materialize?
- **exposure_frequency:** How often the risk event could occur.
- **exposure_window:** How long the condition has existed or could persist.
- **realized_impact:** Whether harm has already occurred.
- **scenario_description:** Plain-language risk scenario.
- **likelihood_drivers:** Facts that increase or reduce likelihood/exposure.
- **magnitude_drivers:** Facts that increase or reduce impact.

This section is especially important for business-process issues where the condition may be narrower than an enterprise technology issue but still capable of severe downstream impact.

### 7. control_environment

Purpose: Capture whether the issue is mitigated or amplified by the control environment.

Fields:

- **control_type_tags:** preventive, detective, corrective, directive, manual, automated.
- **design_effectiveness**
- **operating_effectiveness**
- **compensating_controls**
- **monitoring_or_detection**
- **detectability**
- **recoverability**
- **remediation_complexity**
- **remediation_dependency**

### 8. context

Purpose: Add organizational context that may not be obvious from issue text alone.

Fields:

- **business_criticality**
- **enterprise_relevance**
- **regulatory_or_legal_sensitivity**
- **customer_or_client_impact**
- **financial_exposure**
- **operational_resilience_impact**
- **data_or_technology_impact**
- **fraud_or_misuse_exposure**
- **strategic_or_reputational_relevance**
- **risk_appetite_or_tolerance**
- **affected_stakeholders**
- **known_management_priorities**

These fields may require additional user input or approved context sources.

### 9. comparability

Purpose: Support senior management calibration across teams and prior issues.

Fields:

- **similar_historical_issues**
- **similar_current_issues**
- **relevant_frameworks**
- **similarity_basis**
- **key_differences**
- **prior_tier_distribution**
- **calibration_notes**

Historical comparators should be advisory, not binding.

### 10. scoring_inputs

Purpose: Hand structured factor assessments to the deterministic AISV scoring layer.

Fields:

- **factor_assessments**
- **impact_domain_tags**
- **missing_information_questions**
- **scoring_readiness**
- **readiness_blockers**

Each factor assessment should include:

```json
{
  "factor": "IM",
  "proposed_value": 3,
  "confidence": "moderate",
  "directness": "inferred",
  "rationale": "The issue could create meaningful regulatory and operational consequences.",
  "supporting_facts": ["fact_001", "fact_006"],
  "reducing_facts": ["fact_009"],
  "disputed_facts": [],
  "missing_information": ["gap_002"]
}
```

AISV factors:

- **IM:** Impact Magnitude
- **LE:** Likelihood / Exposure
- **PV:** Pervasiveness / Scope
- **CW:** Control Weakness Severity
- **BC:** Business Criticality / Risk Appetite
- **CD:** Compensating Controls / Detectability
- **RU:** Remediation Urgency
- **EC:** Evidence Confidence

## Readiness Levels

The extraction should classify scoring readiness:

| Value | Meaning |
|---|---|
| insufficient | Too much is missing to suggest a tier responsibly. |
| provisional | Can suggest a provisional tier, but major uncertainty remains. |
| scoring_ready | Enough evidence and context exist for a defensible suggested tier. |
| management_review_ready | Ready for senior management review with rationale and gaps visible. |

## Missing Information Question Object

Missing information should be structured, not free-text only:

```json
{
  "id": "gap_002",
  "question": "What population was tested, and how many exceptions were identified?",
  "reason_needed": "Needed to score pervasiveness, likelihood/exposure, and evidence confidence.",
  "affected_factors": ["PV", "LE", "EC"],
  "priority": "high",
  "answer_type": "number_or_text"
}
```

Priority values:

- critical
- high
- medium
- low

## Validation Rules

Initial validation rules:

- Every proposed AISV factor value must have at least one rationale.
- Any factor with `proposed_value` above 2 should cite supporting facts or identify that the value is inferred.
- If `EC` is low or none, scoring readiness should not be `management_review_ready`.
- If `PV` is unknown, the tool should ask a scope/population question.
- If `CD` is unknown, the tool should ask about compensating controls or detection.
- If final tier differs from suggested tier, override rationale must reference changed factors or additional context.
- The LLM must not silently invent missing population size, exception rate, loss amount, or regulatory consequence.

## Example Output Skeleton

```json
{
  "schema_version": "AISV_EXTRACT_0.1",
  "issue_summary": {
    "issue_title": {
      "value": "Incomplete review of privileged access",
      "status": "stated",
      "confidence": "high",
      "provenance": []
    }
  },
  "scoring_inputs": {
    "scoring_readiness": "provisional",
    "factor_assessments": [
      {
        "factor": "PV",
        "proposed_value": 3,
        "confidence": "moderate",
        "directness": "inferred",
        "rationale": "Issue appears to affect multiple applications, but the full population is not stated.",
        "supporting_facts": ["fact_004"],
        "reducing_facts": [],
        "disputed_facts": [],
        "missing_information": ["gap_001"]
      }
    ],
    "missing_information_questions": [
      {
        "id": "gap_001",
        "question": "How many applications or systems are in scope?",
        "reason_needed": "Needed to distinguish a local issue from a multi-system issue.",
        "affected_factors": ["PV", "BC"],
        "priority": "high",
        "answer_type": "number_or_text"
      }
    ]
  }
}
```

## Design Intent

This schema should make the LLM behave less like a judge and more like an audit analyst:

- Read the issue.
- Extract the facts.
- Cite the support.
- Separate what is known from what is inferred.
- Identify what is missing.
- Prepare the inputs for a reviewable scoring process.

The scoring engine can then calculate a recommendation without losing the audit trail.
