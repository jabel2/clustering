# AISV - CLI Tester

**Created:** 2026-06-20 23:57 -04:00  
**Status:** v0.2 CLI prototype with LangChain AzureChatOpenAI extraction path  
**Related:** [[AISV - Structured Extraction Schema]], [[AISV - Input Decomposition Pipeline]], [[Audit Issue Severity Vector - Draft Methodology]]

## Script

Workspace entry point:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\aisv_cli_tester.py
```

Supporting files:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\aisv_heuristic_extractor.py
C:\Users\Abel\Desktop\risk-tier-calculator\aisv_llm_extractor.py
C:\Users\Abel\Desktop\risk-tier-calculator\aisv_scoring.py
```

## Purpose

The CLI tester lets a user paste an internal audit issue description and receive a provisional AISV-style result.

The current version supports two extraction modes:

- `llm` as the default v0.2 path using LangChain `AzureChatOpenAI`.
- `heuristic` as the offline/test fallback using transparent keyword heuristics.

The CLI:

- Prints readable output to the terminal.
- Saves full JSON output to the vault.
- Writes logs to a local log file.

## File Responsibilities

### `aisv_cli_tester.py`

Handles the command-line experience:

- Logging setup
- Multiline audit issue prompt
- Extractor selection
- Calling extraction
- Calling scoring
- Printing readable results
- Saving JSON output

### `aisv_llm_extractor.py`

Handles the v0.2 LLM extraction layer:

- Imports `AzureChatOpenAI` from `langchain_openai`.
- Defines the AISV v0.2 Pydantic model hierarchy, with `AISVExtraction` as the root object.
- Reads Azure OpenAI configuration from environment variables.
- Uses LangChain `with_structured_output(AISVExtraction)` so the Pydantic model is the active LLM response contract.
- Provides `load_v0_2_json_schema()` for the JSON Schema sidecar.
- Produces structured extraction output for the deterministic scoring layer.

### `aisv_heuristic_extractor.py`

Handles the offline fallback extraction layer:

- Section parsing
- Heuristic fact extraction
- Issue anatomy extraction
- Evidence inventory
- Risk mechanics
- Control environment
- Context extraction
- Missing information questions

This remains useful for local testing and regression checks.

### `aisv_scoring.py`

Handles deterministic AISV scoring:

- Uses LLM-provided factor assessments when available.
- Falls back to heuristic factor assessments when needed.
- Calculates weighted AISV score.
- Maps score to suggested tier.
- Calculates evidence confidence and scoring readiness.
- Builds AISV vector string.

## How To Run

From the workspace root, default LLM mode:

```powershell
python .\aisv_cli_tester.py
```

Offline heuristic mode:

```powershell
python .\aisv_cli_tester.py --extractor heuristic
```

LLM mode with fallback:

```powershell
python .\aisv_cli_tester.py --allow-heuristic-fallback
```

Then paste the audit issue description and type:

```text
END
```

on its own line to submit.

## Azure OpenAI / LangChain Setup

Install dependency:

```powershell
pip install -r requirements.txt
```

Expected environment variables:

For Azure OpenAI:

```text
AISV_LLM_PROVIDER=azure
AZURE_OPENAI_API_KEY
AZURE_OPENAI_ENDPOINT
AZURE_OPENAI_API_VERSION
AZURE_OPENAI_DEPLOYMENT_NAME
```

The code also accepts:

```text
AZURE_OPENAI_DEPLOYMENT
AZURE_OPENAI_CHAT_DEPLOYMENT
OPENAI_API_VERSION
```

For OpenRouter:

```text
AISV_LLM_PROVIDER=openrouter
OPENROUTER_API_KEY
OPENROUTER_MODEL
OPENROUTER_BASE_URL
```

`OPENROUTER_MODEL` defaults to `openai/gpt-4o` and `OPENROUTER_BASE_URL` defaults to `https://openrouter.ai/api/v1`.

## Schema Implementations

Primary code contract:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\aisv_llm_extractor.py
```

JSON Schema sidecar:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\risk-tiering-vault\schemas\aisv-extraction-schema-v0.2.json
```

## Runtime Outputs

Full JSON test runs are saved to:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\risk-tiering-vault\test-runs
```

Logs are written to:

```text
C:\Users\Abel\Desktop\risk-tier-calculator\logs\aisv_cli_tester.log
```

## Current Output

The script prints:

- Suggested tier
- AISV score
- Evidence confidence
- Scoring readiness
- Extractor used
- AISV vector
- Tier review flags
- Extracted issue anatomy
- Factor assessments
- Missing information questions
- Readiness blockers
- Important caveat

## Verification

Completed on 2026-06-20 23:57 -04:00:

- `python -m py_compile aisv_cli_tester.py` passed.
- Sample CLI run completed successfully.
- Sample output produced a provisional Tier 2 result, AISV score, vector, factor assessments, missing-info questions, and saved JSON result.

Completed on 2026-06-21 12:02 -04:00:

- Split the prototype into three files: CLI/ingestion, heuristic extraction, and deterministic scoring.
- `python -m py_compile aisv_cli_tester.py aisv_heuristic_extractor.py aisv_scoring.py` passed.
- Sample CLI run completed successfully after refactor.

Completed on 2026-06-22 14:01 -04:00:

- Updated the prototype so AISV v0.2 is the default path.
- Added `aisv_llm_extractor.py` using LangChain `AzureChatOpenAI`.
- Added `requirements.txt` with `langchain-openai`.
- Updated `aisv_scoring.py` so it uses LLM-provided factor assessments when present.
- Updated vector output from `AISV:0.1` to `AISV:0.2`.
- Kept `--extractor heuristic` as the offline/test mode.
- `python -m py_compile aisv_cli_tester.py aisv_heuristic_extractor.py aisv_llm_extractor.py aisv_scoring.py` passed.
- Offline heuristic sample run completed successfully.

Completed on 2026-06-22 20:52 -04:00:

- Converted the AISV v0.2 extraction contract into Pydantic models in `aisv_llm_extractor.py`.
- Updated the LLM path to use `AISVExtraction` as the structured-output schema.
- Added [[schemas/aisv-extraction-schema-v0.2.json]] as the JSON Schema sidecar implementation.
- Added `pydantic>=2` to `requirements.txt`.
- Made the CLI import the LLM extractor lazily so `--extractor heuristic` still works before installing LLM dependencies.
- Verified JSON sidecar parsing, Python compile, CLI `--help`, and offline heuristic run.

Completed on 2026-06-22 21:00 -04:00:

- Clarified the LLM extractor as Pydantic-first.
- Updated `aisv_llm_extractor.py` so LangChain calls `with_structured_output(AISVExtraction)` without passing the JSON sidecar as the active schema.
- Kept [[schemas/aisv-extraction-schema-v0.2.json]] as documentation/tooling support only.

Completed on 2026-06-22 22:26 -04:00:

- Removed raw model-response printing.
- Removed hardcoded LLM credential material and moved provider setup to environment variables.
- Added provider selection for Azure OpenAI and OpenRouter.
- Set LLM extraction metadata programmatically instead of relying on model-generated values.
- Preserved evidence confidence separately from scoring readiness.
- Added generic tier floor/review flags so severe factor patterns can elevate a score-based Tier 2 to suggested Tier 1.
- Updated CLI output to show score-based tier when different from suggested tier.
- Verified compile, heuristic mode, saved LLM-result replay, and evidence-confidence preservation.

## Future Split Candidates

The project now has a fourth file because the LLM extractor is a distinct integration boundary. Future candidates for additional separate files:

- `aisv_output.py` if console/JSON/report formatting grows.
- `aisv_schema_helpers.py` if fact/provenance constructors become shared by LLM extraction and heuristic extraction.
- `aisv_config.py` if weights, thresholds, and keyword lists need to be externally configurable.
