# Problem Framing - Audit Issue Tiering

**Session started:** 2026-06-14 22:27 -04:00  
**Status:** Initial problem framing canvas complete  
**Method:** MITRE-style Problem Framing Canvas

## Working Agreement

- Use this note as the running memory for the problem framing event.
- Update it after each substantive exchange so the reasoning can be reviewed later.
- Separate problem framing from solution design.
- Keep solution ideas in the parking lot until the problem statement and HMW question are stable.

## Problem Context

The user is an internal auditor responsible for planning, fieldwork, reporting, and action plan follow-up. During the reporting stage, auditors must assign a tier to audit issues to represent severity or importance.

The current tiering process uses IIA/internal audit guidance and an internal matrix, but the user experiences the tiering choice as subjective. An auditor may select a tier based on the issue and supporting information, then the tier may change through conversations with stakeholders and senior audit management, often moving to a lower tier. This creates delays, repeated debate, inconsistent treatment across auditors and reviewers, and reduced confidence in whether similar issues receive similar severity ratings.

## Solution Hypothesis Parking Lot

- Use an external or internal deterministic framework to evaluate tiering.
- Compare prior audit issues against that framework.
- Use an LLM to extract relevant facts from issue writeups.
- Feed extracted facts into a more deterministic tiering model.
- Produce a suggested tier, rationale, and additional context.
- Research whether existing internal audit, enterprise risk, cybersecurity, safety, regulatory, or operational risk frameworks can be adapted for business-process issue tiering.

## Canvas Draft

### Phase 1: Look Inward

#### What is the problem? (Symptoms)

Internal auditors must assign a severity tier to audit issues during reporting, but the tiering decision is highly subjective. Even when an auditor applies existing IIA/internal guidance, the selected tier often changes through stakeholder and senior management review, usually downward. This creates delays, repeated debate, inconsistent outcomes, and reduced confidence that similar issues are being treated similarly.

#### Why has not it been solved?

Confirmed and refined:

- It is hard: severity depends on context, auditor judgment, and organizational impact.
- Guidance exists, but it is not deterministic enough to force consistent decisions.
- The tiering rationale is not sufficiently auditable or repeatable.
- Final tiering is shaped mostly by management and sometimes by stakeholder negotiation.
- Tier negotiation creates reporting delays and back-and-forth before the audit report can move forward.
- There may be no feedback loop that compares prior issues and prior tiering decisions to improve consistency.
- There is meaningful fear of rigidity: auditors and reviewers may resist a deterministic model because they believe auditor judgment better reflects the testing performed, the evidence gathered, and the actual meaning of the result.
- Low priority is not a good explanation. Tiering uncertainty can push reporting deadlines, so the problem is operationally important.

#### How might we be part of the problem? (Assumptions and biases)

Confirmed and refined:

- The department assumes auditor experience produces better tiering because experienced auditors have seen more issues and can understand context, importance, and organizational relevance.
- The department trusts auditor judgment, but the reasoning trail may not always be strong enough for others to test or repeat.
- Reviewers may respond to uncertainty by asking for additional work to further prove the issue, which can delay reporting.
- Auditors anchor on the first proposed tier because it reflects their professional judgment, experience, and interpretation of the framework.
- Later tier discussions often become negotiation between subjective views rather than comparison against a shared, deterministic framework.
- Stakeholder comfort influences the process. Stakeholders have pressure to lower tiering because a lower tier looks better and may allow remediation to be pushed further out.
- Fear of false precision is a major impediment. A structured model will not be correct 100 percent of the time, and auditors need to see how it reached its answer, why it reached that answer, and how the conclusion aligns with historical decisions.
- The department does not lack examples. Prior audit issues and tiers exist in a persistent database.
- However, historical examples alone may not solve the problem because prior issue records may omit context that auditors believe is essential to understanding the correct tier.
- Several dynamics reinforce each other: subjective initial tiering, subjective challenge, stakeholder pressure, additional work to prove the result, and reporting delay.

### Phase 2: Look Outward

#### Who experiences the problem?

Confirmed and refined:

- Staff auditors feel the most direct pain. They perform fieldwork, identify issues, apply their judgment, write the report language, discuss with stakeholders, and try to put context on paper. When senior management challenges the tier late in the process, staff auditors may have to do additional work and rework the issue.
- Experienced auditors may feel this more strongly than newer auditors because they are the ones supplying the professional judgment behind the proposed tier. Newer auditors generally rely on the experienced auditors within the team before the issue reaches senior management.
- Senior audit management also experiences pain, but differently. They must compare findings across many audit teams and business domains in a department of roughly 200 people. They are trying to level the playing field across teams so that issues with the same tier represent comparable organizational importance.
- Business stakeholders feel less of the immediate process pain because much of the debate happens inside audit before the issue is brought to them.
- The organization may still be affected if lowered or inconsistent tiering causes important issues to be deprioritized.

#### When and where the problem appears

- Draft issue writing, when the audit team first proposes a tier.
- Internal report review, when senior audit management reviews the issue and challenges whether the tier is substantiated.
- Before stakeholder validation, because audit may not be ready to present the issue until the internal tier debate is resolved.
- Final report issuance, because unresolved tiering can block the report from moving forward.
- Action plan timing, because lower-tier findings may allow business stakeholders to defer remediation.

#### Consequences

Confirmed and refined:

- Longer reporting cycle time.
- Repeated negotiation and rework between audit teams and senior management.
- Additional audit work when senior management believes the tier is not sufficiently substantiated.
- Delays in issuing the report and getting the issue in front of stakeholders.
- Lower auditor morale because auditors feel their experience and professional judgment are not fully taken into account.
- Auditors may feel overruled when their proposed tier is reduced.
- Weaker findings if tiering is reduced without a shared, evidence-based calibration process.
- Business stakeholders may deprioritize fixes when issues are lowered to less urgent tiers.
- Inconsistent severity decisions across auditors, audit teams, business domains, or time periods.
- Reduced confidence in audit issue prioritization.
- Potential under-prioritization of important risks.
- Weaker ability to compare current issues to historical issues.

#### Lived experience varies

- Experienced auditors may experience the problem as a challenge to their professional judgment.
- Newer auditors may experience the problem more indirectly because they lean on experienced auditors inside the team.
- Enterprise-level audit teams may naturally produce findings with broader organizational reach because their subject matter affects the whole company.
- Business-level audit teams may identify issues tied to local implementation, mistranslation, or business-process use of enterprise tools.
- Senior management has to compare enterprise-level and business-specific issues, which can create friction about what "riskiness" should mean across domains.

#### Who else has this problem? Who does not?

Current understanding:

- Other corporate internal audit departments likely struggle with similar issue severity and tiering consistency problems, although this still needs to be validated.
- Some peer audit functions may have more advanced or deterministic frameworks, but no confirmed benchmark has been identified yet.
- Regulators may have less of this problem, or at least a different version of it, because their authority and criteria may make severity decisions less negotiable.
- Adjacent risk functions such as compliance, enterprise risk, cybersecurity, operational risk, model risk, credit risk, safety, or legal may face similar rating problems, but it is unclear whether they experience the same degree of evidence debate and reporting delay.

Groups that seem to have the problem less:

- Enterprise-level cybersecurity and enterprise technology teams often have findings that are easier to defend as higher risk because their subject matter affects foundational systems or processes used widely across the firm.
- Cybersecurity and technology risk teams may benefit from stronger external scoring and classification frameworks, such as CVE scoring, MITRE-style frameworks, and broader industry language about organizational risk.
- Issues with wide organizational reach tend to be agreed upon faster than issues with deep but narrower business-process impact.

Groups that seem to have the problem more:

- Business-specific audit teams.
- Teams focused on process, operational, financial, or business-context risks rather than technology configuration or enterprise tooling.
- Findings where impact is conditional or scenario-based, such as "if this happens, something could go badly," rather than a directly observable misconfiguration or broadly applicable control weakness.

Important distinction:

- Wide-reaching impact is easier to compare and defend because many stakeholders can see the enterprise-level relevance.
- Deep business-specific impact can still be severe, but it may be harder to compare against enterprise-wide technology or cybersecurity findings.
- Senior management may use broad enterprise examples as comparators when challenging deeper, narrower findings, even though the risk mechanics are different.

#### Who has been left out? Who benefits?

Current understanding:

- No major stakeholder group appears to be completely left out of the tiering conversation.
- The conversation happens at different gates:
  - Staff auditors initially use their judgment to propose a tier.
  - Senior audit management reviews and may change the tier before anything persists outside the audit department.
  - Business process owners, risk owners, and stakeholders later receive the issue and can provide context or negotiate the tier.
  - The audit committee receives the final reporting, but typically does not provide input into the tier decision.
- The issue is less about exclusion and more about when different parties enter the process, what authority they have, and whether changes are supported by a consistent rationale.

Who benefits when tiering remains subjective or negotiable:

- Many participants benefit somewhat from the flexibility of subjective tiering because they can reason from their own judgment and negotiate with people rather than first overcoming a structured framework.
- Staff auditors can propose higher-risk tiers that reflect their view of the fieldwork and may signal that their team found something important.
- Audit teams may benefit from the ability to defend the importance of their work without first being constrained by a tool or scoring model.
- Senior management retains discretion to calibrate across teams.
- Business stakeholders can negotiate tiers downward by adding context about why the issue may be less risky than it appears.

Who benefits if tiering becomes more consistent and defensible:

- Senior management likely benefits most because they can reason across multiple audit teams using more comparable and defensible information.
- Open-minded auditors may benefit because a structured tool could help them propose a tier more quickly and provide a clearer rationale.
- The audit department may benefit from faster review, fewer repeated debates, and stronger consistency across teams and time periods.
- The organization may benefit if risk prioritization becomes more reliable and less dependent on negotiation dynamics.

Who may lose or feel they lose:

- Staff auditors who strongly value professional judgment may feel they are losing flexibility, influence, or ownership over the proposed tier.
- Auditors may feel they now have to argue against a tool first, then senior management second.
- Stakeholders may lose some ability to negotiate tiers downward if a structured framework produces a defensible rationale that is harder to counter without specific evidence.
- Senior management may lose some discretionary room if the framework makes deviations more visible and requires stronger documentation.

### Phase 3: Reframe

#### Accepted Restatement

Internal auditors struggle to assign, defend, and calibrate audit issue tiers consistently because the current process relies heavily on professional judgment and broad guidance without a sufficiently transparent, repeatable rationale model. Staff auditors use fieldwork context and experience to propose tiers, while senior audit management must compare those proposed tiers across many teams, domains, and issue types. Because business-process risks are often contextual or conditional, they are harder to compare against enterprise technology or cybersecurity issues that have broader reach and more mature external frameworks. This leads to subjective negotiation, additional evidence-gathering, delayed reporting, lower auditor morale, and potential under-prioritization of important risks when tiers are reduced.

#### Accepted HMW

How might we make audit issue tiering more transparent, consistent, defensible, and evidence-based as we aim to reduce subjective negotiation and reporting delays while helping senior management compare findings across audit teams?

## Open Questions

- What specific tiering standards, matrices, or definitions are currently used?
- What evidence is supposed to determine pervasiveness, impact, likelihood, or severity?
- What reasons are typically given when a tier is lowered?
- Are tier changes documented with enough rationale to learn from prior decisions?
- What would make a deterministic or semi-deterministic model trustworthy enough that auditors would not feel it overrides legitimate professional judgment?
- What contextual facts do auditors use when tiering that may not currently appear in the issue writeup or database fields?
- What level of model explanation would be sufficient for audit users to trust a recommended tier?
- How should a tiering framework compare enterprise-wide issues against business-specific implementation issues?
- Which facts distinguish a broad enterprise issue from a local business-process issue that is still severe?
- What external frameworks handle conditional business impact better than current audit tiering guidance?
- What makes CVE/MITRE-style cybersecurity scoring feel more defensible, and can any of those design principles transfer to business/process audit findings?
- Who has final authority over tiering, and who can challenge that decision?
- What downstream consequences differ by tier?

## Decisions and Confirmations

- Initial problem framing is directionally accurate. The user confirmed that the draft captured the problem and affected stakeholders without meaningful oversimplification.
- Reframed problem statement is accepted as written.
- Accepted HMW combines two aims: reduce subjective negotiation and reporting delays, and help senior management compare findings across teams.

## Related Research

- [[Research - Tiering Framework Landscape]]
- [[Audit Issue Severity Vector - Draft Methodology]]
- [[AISV - Input Decomposition Pipeline]]
- [[AISV - Structured Extraction Schema]]
- [[AISV - CLI Tester]]
- [[AISV - LLM Test Analysis 2026-06-22]]

## Turn Log

### 2026-06-14 22:27 -04:00

- User selected the "Best guess" facilitation mode.
- User described the problem of subjective audit issue tiering during reporting.
- Assistant drafted initial problem framing, early reframe, and early HMW.
- User requested that the Obsidian vault be used to capture the session after each turn for longer-term review.
- This note was created as the running session artifact.

### 2026-06-14 22:29 -04:00

- User confirmed the initial framing accurately describes the problem and affected stakeholders.
- No major omissions or oversimplifications were identified in the first draft.

### 2026-06-14 22:32 -04:00

- User clarified why the problem has not been solved.
- The issue is not low priority; unresolved tiering can delay audit reporting deadlines.
- Key barriers include context-dependent judgment, non-deterministic guidance, limited auditability of the rationale, management influence, stakeholder negotiation, lack of feedback loops, and fear that a rigid model would produce worse conclusions than auditor judgment.

### 2026-06-14 22:39 -04:00

- User clarified how the audit team may be part of the problem.
- The department values auditor experience and judgment, but that expertise may not become a repeatable rationale others can test.
- Initial auditor tiering can anchor later conversations, turning review into subjective negotiation.
- Stakeholder pressure can push tiers downward because lower tiers look better and may extend remediation timelines.
- Fear of false precision is a central barrier: auditors need transparency into how any structured model reaches a recommendation and how it aligns with historical decisions.
- Historical examples exist in a persistent database, but they may lack the contextual details auditors consider essential.

### 2026-06-14 22:47 -04:00

- User described who experiences the problem and where it appears.
- Staff auditors feel the most direct pain through rework, delayed reporting, and reduced morale when their tiering judgment is challenged or overruled.
- Senior audit management also feels pain because they must calibrate issue severity across many teams and domains.
- The problem appears during draft issue writing, internal report review, before stakeholder validation, and final report issuance.
- Key consequences include additional audit work, report delays, negotiation, lower morale, weaker findings, and potential business deprioritization of remediation.
- Lived experience differs by auditor experience level and by audit area, especially enterprise-level tooling audits versus business-specific process or implementation audits.

### 2026-06-14 22:55 -04:00

- User described who else may have this problem and who may experience it less.
- Other corporate internal audit departments likely face similar tiering subjectivity, though this needs validation.
- Cybersecurity and enterprise technology audit areas seem easier to defend because they affect foundational systems and can rely on stronger external frameworks such as CVE scoring or MITRE-style risk language.
- Business-specific, process, operational, and financial-risk findings are harder to tier consistently because their impact is more contextual or conditional.
- Wide-reaching issues tend to be agreed upon more quickly than deep, narrower business-process issues.
- A later research task should investigate external frameworks that could help make business-risk tiering more structured and defensible.

### 2026-06-14 23:08 -04:00

- User clarified that no major stakeholder group appears fully left out of the tiering conversation; stakeholders enter at different process gates.
- Staff auditors propose the initial tier, senior audit management reviews and may change it, business stakeholders later provide context or negotiate, and the audit committee receives final reporting.
- Subjective or negotiable tiering benefits multiple parties because it preserves flexibility, influence, discretion, and the ability to argue directly with people rather than first overcoming a structured model.
- Senior management likely benefits most from a solved state because consistent, defensible tiering would support cross-team calibration.
- Open-minded auditors may also benefit if the tool helps them propose tiers more quickly and defend their rationale.
- Some auditors may feel they lose flexibility or influence if a deterministic framework appears to override professional judgment.

### 2026-06-14 23:11 -04:00

- User accepted the reframed problem statement as written.
- Session is ready to move from problem restatement into drafting the How Might We question.

### 2026-06-14 23:14 -04:00

- User selected a combined HMW direction based on options 1 and 4.
- The accepted HMW should emphasize transparent, consistent, defensible, evidence-based tiering while also supporting senior management comparison across audit teams.
- Initial problem-framing canvas is complete.

### 2026-06-14 23:20 -04:00

- User requested the next natural move: research existing frameworks that may inform a deterministic or semi-deterministic audit issue tiering approach.
- Initial research scope includes IIA guidance, MITRE and technology-focused frameworks, cyber scoring systems, general risk management, and adjacent approaches the user may not already know.
- Created [[Research - Tiering Framework Landscape]] as a living research note.

### 2026-06-14 23:25 -04:00

- User agreed that no off-the-shelf framework appears likely to solve the problem directly.
- User approved exploring a hybrid methodology that melds audit-style frameworks with technology-style scoring frameworks.
- User liked the name "Audit Issue Severity Vector" and the initial way forward.
- Created [[Audit Issue Severity Vector - Draft Methodology]] as a first coherent scoring methodology draft.

### 2026-06-14 23:42 -04:00

- User reviewed the first AISV draft and found it directionally useful but too simplistic.
- User noted that many of the high-level framework elements are already in place today.
- The desired product needs a more detailed and depth-oriented methodology, not merely a simple weighted factor matrix.
- Updated [[Audit Issue Severity Vector - Draft Methodology]] to mark v0.1 as insufficient and define required depth for v0.2.

### 2026-06-20 11:16 -04:00

- User clarified the expected tool input: an internal audit issue description containing background, issue text, evidence, conclusion, and root cause, likely in bulletized or paragraph form.
- User expects the tool to use an LLM to decompose the issue into the eventual AISV framework, identify where more user information is needed, optionally add context, and support effective scoring.
- Created [[AISV - Input Decomposition Pipeline]] to define the LLM extraction layer, missing-information prompts, context enrichment, and deterministic scoring handoff.

### 2026-06-20 11:21 -04:00

- User asked to define the actual structured extraction schema as the data contract between audit issue text and the scoring engine.
- Created [[AISV - Structured Extraction Schema]] as the human-readable contract.
- Created [[schemas/aisv-extraction-schema-v0.1.json]] as a machine-readable JSON Schema.
- Validated that the JSON schema parses successfully.

### 2026-06-20 23:57 -04:00

- User asked for a Python CLI script to test the AISV structure by prompting for an audit issue and showing the structured result.
- Created `aisv_cli_tester.py` at the workspace root.
- The script prompts for multiline audit issue input, decomposes the issue with transparent heuristics, applies provisional AISV scoring, prints a readable result, saves full JSON to `risk-tiering-vault/test-runs`, and writes logs to `logs/aisv_cli_tester.log`.
- Created [[AISV - CLI Tester]] with run instructions and verification notes.
- Verified the script with `python -m py_compile` and a sample CLI run.

### 2026-06-21 12:02 -04:00

- User requested that the prototype be split into files by functionality.
- Refactored the CLI tester into three files:
  - `aisv_cli_tester.py` for CLI ingestion, logging, saving, and display.
  - `aisv_heuristic_extractor.py` for the current heuristic extraction layer, which can later be replaced by an LLM call.
  - `aisv_scoring.py` for deterministic AISV scoring, readiness, suggested tier, and vector output.
- Updated [[AISV - CLI Tester]] with file responsibilities and future split candidates.
- Verified the refactor with `python -m py_compile` and a sample CLI run.

### 2026-06-22 14:01 -04:00

- User challenged why the code still reflected the v0.1 heuristic vector rather than the deeper v0.2 methodology.
- User clarified that the input decomposition should be done with an LLM and should conform to LangChain `AzureChatOpenAI` objects.
- Added `aisv_llm_extractor.py` as the v0.2 LLM extraction layer using `langchain_openai.AzureChatOpenAI` and LangChain structured output.
- Updated the CLI so default mode is `--extractor llm`, with `--extractor heuristic` available for offline testing and `--allow-heuristic-fallback` available for fallback.
- Updated `aisv_scoring.py` so deterministic scoring uses LLM-provided factor assessments when available instead of always rebuilding heuristic keyword scores.
- Updated AISV vector output to `AISV:0.2`.
- Added `requirements.txt` with `langchain-openai`.
- Updated [[AISV - CLI Tester]] with v0.2 run instructions and Azure OpenAI environment setup.
- Verified compile checks and offline heuristic run. LLM mode was not executed because it requires the user's Azure OpenAI credentials and network access.

### 2026-06-22 20:52 -04:00

- User requested that the v0.2 schema be converted to a Pydantic model in the LLM extractor while also keeping a base JSON sidecar implementation.
- Converted `aisv_llm_extractor.py` to define the AISV v0.2 Pydantic model hierarchy with `AISVExtraction` as the root model.
- Updated LangChain structured output to use `AISVExtraction` as the structured-output model.
- Added `risk-tiering-vault/schemas/aisv-extraction-schema-v0.2.json` as the JSON Schema sidecar.
- Added `pydantic>=2` to `requirements.txt`.
- Updated `aisv_cli_tester.py` to import the LLM extractor lazily so offline heuristic mode remains usable without LLM dependencies installed.
- Verified v0.2 JSON sidecar parsing, Python compile, CLI `--help`, and offline heuristic mode.

### 2026-06-22 21:00 -04:00

- User clarified that the LLM extractor should use the Pydantic model directly instead of the JSON sidecar to force the response shape.
- Updated `aisv_llm_extractor.py` to call `with_structured_output(AISVExtraction)` and added a comment that the JSON Schema sidecar is for documentation/tooling only.
- Updated [[AISV - CLI Tester]] to reflect the Pydantic-first structured output path.

### 2026-06-22 22:17 -04:00

- User ran the wired LLM extractor against a sample unauthorized cloud migration issue and shared the terminal output.
- Created [[AISV - LLM Test Analysis 2026-06-22]] to capture observations.
- The LLM extraction succeeded and generated a structured Pydantic result.
- The deterministic scoring layer used the LLM-provided factor assessments and produced Tier 2 with AISV score 75.0.
- Key issues identified: raw model response printed to CLI, LLM-generated metadata should be programmatic, evidence confidence is being overwritten by scoring readiness logic, factor rationales need better alignment, missing-info and evidence mappings are too broad, tier gates/review flags are missing, and Python 3.14 emits a LangChain/Pydantic warning.

### 2026-06-22 22:26 -04:00

- User agreed the sample issue seemed very high risk and likely Tier 1.
- User requested general tightening rather than issue-specific tuning before testing another issue.
- Removed raw model-response printing and hardcoded LLM credential material.
- Added environment-driven provider setup for Azure OpenAI and OpenRouter.
- Set LLM extraction metadata programmatically.
- Strengthened the LLM prompt with factor-specific scoring instructions and tighter evidence/missing-information mapping.
- Updated scoring to preserve LLM evidence confidence separately from scoring readiness.
- Added generic tier floor/review flags for severe impact/scope, data/regulatory control failure patterns, high-score clusters, and high exposure with weak detection.
- Updated CLI output to show score-based tier when different from the final suggested tier.
- Replayed the saved LLM result through the updated scoring layer; the result became suggested Tier 1 with score-based Tier 2 and multiple generic tier review flags.
