"""Pipeline: load data → clean missing values → build feature matrix for clustering."""

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, RobustScaler


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_data(file_path: str | Path) -> pd.DataFrame:
    """Load data from a CSV or JSON file into a DataFrame."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    elif suffix == ".json":
        return _load_json(path)
    else:
        raise ValueError(f"Unsupported file format: {suffix}. Use CSV or JSON.")


def _load_json(path: Path) -> pd.DataFrame:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return pd.DataFrame(data)
    elif isinstance(data, dict):
        if "data" in data and isinstance(data["data"], list):
            return pd.DataFrame(data["data"])
        return pd.DataFrame([data])
    else:
        raise ValueError("JSON must contain an array or object")


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------

def clean_data(
    df: pd.DataFrame,
    id_column: str | None = None,
    exclude_columns: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.Series | None]:
    """Clean data: extract ID column, fill missing values, coerce types.

    Returns (cleaned_df, id_series_or_None).
    """
    df = df.copy()
    exclude = set(exclude_columns or [])

    ids = None
    if id_column and id_column in df.columns:
        ids = df[id_column].copy()
        exclude.add(id_column)

    df = df[[c for c in df.columns if c not in exclude]]
    df = _fill_missing(df)
    df = _coerce_types(df)
    return df, ids


def _fill_missing(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.columns:
        if df[col].isna().sum() == 0:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            df[col] = df[col].fillna(df[col].median())
        else:
            mode = df[col].mode()
            df[col] = df[col].fillna(mode.iloc[0] if len(mode) > 0 else "Unknown")
    return df


def _coerce_types(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.columns:
        if df[col].dtype == object:
            # Try numeric conversion if >90% of values parse successfully
            try:
                numeric = pd.to_numeric(df[col], errors="coerce")
                if numeric.notna().sum() / len(numeric) > 0.9:
                    df[col] = numeric.fillna(numeric.median())
                    continue
            except (ValueError, TypeError):
                pass

            # Convert boolean-like columns (true/false, yes/no, 1/0)
            unique_vals = df[col].dropna().unique()
            if len(unique_vals) == 2:
                lower_vals = {str(v).lower() for v in unique_vals}
                if lower_vals <= {"true", "false", "yes", "no", "1", "0", "y", "n"}:
                    df[col] = df[col].map(
                        lambda x: str(x).lower() in ("true", "yes", "1", "y")
                    ).astype(int)
    return df


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

@dataclass
class FeatureConfig:
    """Which columns are categorical vs numerical (empty = auto-detect)."""
    categorical_columns: list[str] = field(default_factory=list)
    numerical_columns: list[str] = field(default_factory=list)
    high_cardinality_threshold: int = 20


@dataclass
class FeatureResult:
    """Feature matrix and metadata produced by engineer_features()."""
    features: np.ndarray
    feature_names: list[str]
    categorical_columns: list[str]
    numerical_columns: list[str]
    encoders: dict


def engineer_features(df: pd.DataFrame, config: FeatureConfig | None = None) -> FeatureResult:
    """Transform a cleaned DataFrame into a numerical feature matrix.

    Categorical columns → one-hot encoded.
    Numerical columns   → RobustScaler (IQR-based, outlier-resistant).
    If config is None or columns are unspecified, types are auto-detected.
    """
    config = config or FeatureConfig()
    cat_cols, num_cols = _detect_column_types(df, config)

    cat_features, cat_names, cat_encoder = _encode_categorical(
        df, cat_cols, config.high_cardinality_threshold
    )
    num_features, num_names, num_scaler = _scale_numerical(df, num_cols)

    parts = [f for f in [cat_features, num_features] if f is not None]
    names = cat_names + num_names

    if not parts:
        raise ValueError("No features to process. Check your column configuration.")

    return FeatureResult(
        features=np.hstack(parts),
        feature_names=names,
        categorical_columns=cat_cols,
        numerical_columns=num_cols,
        encoders={"categorical": cat_encoder, "numerical": num_scaler},
    )


def _detect_column_types(df: pd.DataFrame, config: FeatureConfig) -> tuple[list[str], list[str]]:
    if config.categorical_columns and config.numerical_columns:
        return config.categorical_columns, config.numerical_columns

    categorical = list(config.categorical_columns)
    numerical = list(config.numerical_columns)
    specified = set(categorical) | set(numerical)

    for col in df.columns:
        if col in specified:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            # Treat low-cardinality numeric columns as categorical
            if df[col].nunique() / len(df) < 0.05 and df[col].nunique() < 10:
                categorical.append(col)
            else:
                numerical.append(col)
        else:
            categorical.append(col)

    return categorical, numerical


def _encode_categorical(
    df: pd.DataFrame, columns: list[str], high_cardinality_threshold: int
) -> tuple[np.ndarray | None, list[str], OneHotEncoder | None]:
    columns = [c for c in columns if c in df.columns]
    if not columns:
        return None, [], None

    df_cat = df[columns].copy()
    for col in columns:
        if df_cat[col].nunique() > high_cardinality_threshold:
            top = df_cat[col].value_counts().head(high_cardinality_threshold - 1).index
            df_cat[col] = df_cat[col].apply(lambda x: x if x in top else "_OTHER_")

    df_cat = df_cat.astype(str)
    encoder = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
    encoded = encoder.fit_transform(df_cat)

    names = [f"{col}_{cat}" for i, col in enumerate(columns) for cat in encoder.categories_[i]]
    return encoded, names, encoder


def _scale_numerical(
    df: pd.DataFrame, columns: list[str]
) -> tuple[np.ndarray | None, list[str], RobustScaler | None]:
    columns = [c for c in columns if c in df.columns]
    if not columns:
        return None, [], None

    scaler = RobustScaler()
    scaled = scaler.fit_transform(df[columns].values)
    return scaled, columns, scaler
