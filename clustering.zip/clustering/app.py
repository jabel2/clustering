#!/usr/bin/env python
"""Outlier Detector — clustering-based anomaly detection with LLM explanations.

Usage:
  python app.py analyze  <file>  [options]   # cluster and find outliers
  python app.py explain  <file>  [options]   # same + LLM narrative explanation
  python app.py recommend <file> [options]   # ask LLM for best settings
"""

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from pipeline import load_data, clean_data, engineer_features, FeatureConfig
from detect import HDBSCANClusterer, OutlierScorer, ClusterProfiler
from explain import ContextBuilder, ExplanationAgent
from recommend import DatasetAnalyzer, SettingsRecommender

app = typer.Typer(
    name="outlier-detector",
    help="Clustering-based outlier detection with LLM explanations.",
    add_completion=False,
)
console = Console()


# ---------------------------------------------------------------------------
# Shared pipeline helper
# ---------------------------------------------------------------------------

def _run_pipeline(
    file_path: Path,
    id_column: Optional[str],
    categorical: Optional[str],
    numerical: Optional[str],
    min_cluster_size: int,
    auto_cluster_size: bool,
    auto_method: str,
    outlier_threshold: float,
):
    """Run the full data → features → cluster → score → profile pipeline.

    Both `analyze` and `explain` use this to avoid code duplication.
    Returns: (df, cleaned_df, ids, feature_result, cluster_result, outlier_info, profiler, profile_result)
    """
    # Load
    df = load_data(file_path)
    console.print(f"  Loaded {len(df)} records with {len(df.columns)} columns")

    # Clean
    exclude = [id_column] if id_column else []
    cleaned_df, ids = clean_data(df, id_column=id_column, exclude_columns=exclude)
    console.print(f"  Cleaned data: {len(cleaned_df.columns)} feature columns")

    # Features
    cat_cols = [c.strip() for c in categorical.split(",")] if categorical else []
    num_cols = [c.strip() for c in numerical.split(",")] if numerical else []
    feature_result = engineer_features(
        cleaned_df,
        FeatureConfig(categorical_columns=cat_cols, numerical_columns=num_cols),
    )
    console.print(f"  Engineered {len(feature_result.feature_names)} features")

    # Auto-tune cluster size if requested
    console.print("\n[bold blue]Clustering...[/bold blue]")
    if auto_cluster_size:
        console.print(f"  Auto-detecting min_cluster_size (method: {auto_method})...")
        min_cluster_size, details = HDBSCANClusterer.auto_min_cluster_size(
            feature_result.features, method=auto_method
        )
        console.print(f"  Selected min_cluster_size: {min_cluster_size}")
        _display_auto_size_details(details)

    # Cluster
    cluster_result = HDBSCANClusterer(min_cluster_size=min_cluster_size).fit(feature_result.features)
    console.print(f"  Found {cluster_result.n_clusters} clusters, {cluster_result.n_noise} noise points")

    # Score outliers
    outlier_info = OutlierScorer(outlier_threshold=outlier_threshold).score(cluster_result, ids)

    # Profile clusters
    profiler = ClusterProfiler(
        categorical_columns=feature_result.categorical_columns,
        numerical_columns=feature_result.numerical_columns,
    )
    profile_result = profiler.profile(cleaned_df, cluster_result)

    return df, cleaned_df, ids, feature_result, cluster_result, outlier_info, profiler, profile_result


def _display_auto_size_details(details: dict):
    """Show the top 3 auto-tuning candidates in the terminal."""
    if "scores" not in details or not details["scores"]:
        return
    top3 = sorted(
        details["scores"].items(),
        key=lambda x: x[1].get("adjusted_score", x[1].get("dbcv", 0)),
        reverse=True,
    )[:3]
    for size, info in top3:
        if "effective_outlier_pct" in info:
            console.print(
                f"    size={size}: score={info['adjusted_score']:.3f}, "
                f"clusters={info['n_clusters']}, outliers={info['effective_outlier_pct']:.1f}%"
            )
        elif "adjusted_score" in info:
            console.print(
                f"    size={size}: score={info['adjusted_score']:.3f} (DBCV={info['dbcv']:.3f}), "
                f"clusters={info['n_clusters']}, noise={info['noise_pct']:.1f}%"
            )
        else:
            console.print(
                f"    size={size}: DBCV={info['dbcv']:.3f}, "
                f"clusters={info['n_clusters']}, noise={info['noise_pct']:.1f}%"
            )


# ---------------------------------------------------------------------------
# analyze command
# ---------------------------------------------------------------------------

@app.command()
def analyze(
    file_path: Path = typer.Argument(..., help="CSV or JSON data file"),
    id_column: Optional[str] = typer.Option(None, "--id-column", "-i", help="Column to use as row identifier"),
    categorical: Optional[str] = typer.Option(None, "--categorical", "-c", help="Comma-separated categorical columns"),
    numerical: Optional[str] = typer.Option(None, "--numerical", "-n", help="Comma-separated numerical columns"),
    min_cluster_size: int = typer.Option(5, "--min-cluster-size", "-m", help="Min cluster size for HDBSCAN"),
    auto_cluster_size: bool = typer.Option(False, "--auto-cluster-size", "-a", help="Auto-detect min_cluster_size"),
    auto_method: str = typer.Option("dbcv", "--auto-method", help="Auto method: dbcv, balanced, heuristic"),
    outlier_threshold: float = typer.Option(0.8, "--outlier-threshold", "-t", help="GLOSH score cutoff (0–1)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Save results to JSON file"),
):
    """Cluster a dataset and display outliers. No LLM required."""
    console.print(f"\n[bold blue]Loading data from {file_path}...[/bold blue]")

    try:
        df, cleaned_df, ids, feature_result, cluster_result, outlier_info, profiler, profile_result = (
            _run_pipeline(file_path, id_column, categorical, numerical,
                          min_cluster_size, auto_cluster_size, auto_method, outlier_threshold)
        )
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    _display_results(outlier_info, profile_result, cleaned_df, profiler, cluster_result, ids)

    if output:
        _save_analysis_json(output, outlier_info, profile_result, cleaned_df, profiler, ids)
        console.print(f"\n[green]Results saved to {output}[/green]")


# ---------------------------------------------------------------------------
# explain command
# ---------------------------------------------------------------------------

@app.command()
def explain(
    file_path: Path = typer.Argument(..., help="CSV or JSON data file"),
    id_column: Optional[str] = typer.Option(None, "--id-column", "-i"),
    categorical: Optional[str] = typer.Option(None, "--categorical", "-c"),
    numerical: Optional[str] = typer.Option(None, "--numerical", "-n"),
    context: str = typer.Option("", "--context", help="Dataset description (e.g. 'AD group: Finance-Admins')"),
    min_cluster_size: int = typer.Option(5, "--min-cluster-size", "-m"),
    auto_cluster_size: bool = typer.Option(False, "--auto-cluster-size", "-a"),
    auto_method: str = typer.Option("dbcv", "--auto-method"),
    outlier_threshold: float = typer.Option(0.8, "--outlier-threshold", "-t"),
    max_outliers_llm: int = typer.Option(25, "--max-outliers-llm", help="Max outliers to send to LLM"),
    include_recommendations: bool = typer.Option(False, "--recommend", "-r", help="Include LLM settings recommendations"),
    output_format: str = typer.Option(
        "json,terminal,markdown,csv", "--output-format", "-f",
        help="Output formats (comma-separated: json,terminal,markdown,csv)"
    ),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Base output path (extensions added automatically)"),
):
    """Cluster a dataset, identify outliers, and explain them with an LLM."""
    console.print(f"\n[bold blue]Loading data from {file_path}...[/bold blue]")

    try:
        df, cleaned_df, ids, feature_result, cluster_result, outlier_info, profiler, profile_result = (
            _run_pipeline(file_path, id_column, categorical, numerical,
                          min_cluster_size, auto_cluster_size, auto_method, outlier_threshold)
        )
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    if outlier_info.outlier_count == 0:
        console.print("\n[green]No outliers detected![/green]")
        raise typer.Exit(0)

    # Build deviations and LLM context
    outlier_df = profiler.get_outlier_data(cleaned_df, outlier_info) if hasattr(profiler, 'get_outlier_data') else \
        OutlierScorer().get_outlier_data(cleaned_df, outlier_info)

    # Use a fresh OutlierScorer just for get_outlier_data
    scorer = OutlierScorer(outlier_threshold=outlier_threshold)
    outlier_df = scorer.get_outlier_data(cleaned_df, outlier_info)
    deviation_df = profiler.compute_deviation_scores(cleaned_df, outlier_info.indices, cluster_result)

    console.print("\n[bold blue]Generating LLM explanation...[/bold blue]")
    if outlier_info.outlier_count > max_outliers_llm:
        console.print(
            f"  [yellow]Note: {outlier_info.outlier_count} outliers found, "
            f"sending top {max_outliers_llm} to LLM[/yellow]"
        )

    context_builder = ContextBuilder(
        dataset_description=context,
        id_column=id_column,
        max_outliers=max_outliers_llm,
    )
    explanation_context = context_builder.build(cleaned_df, profile_result, outlier_df, deviation_df, outlier_info.ids)

    # Verify Azure credentials are configured
    agent = ExplanationAgent()
    if not agent.check_connection():
        console.print("[red]Azure OpenAI credentials not configured.[/red]")
        console.print("Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY environment variables.")
        raise typer.Exit(1)

    try:
        result = agent.explain(explanation_context)
    except ConnectionError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    # Optional: get settings recommendations
    recommendation_result = None
    if include_recommendations:
        console.print("\n[bold blue]Getting LLM recommendations...[/bold blue]")
        try:
            profile = DatasetAnalyzer().analyze(df)
            recommendation_result = SettingsRecommender().recommend(
                profile=profile, domain_context=context, file_path=str(file_path)
            )
            console.print("  Recommendations generated")
        except Exception as e:
            console.print(f"  [yellow]Warning: Could not get recommendations: {e}[/yellow]")

    # Output
    formats = {f.strip().lower() for f in output_format.split(",")}
    base_path = output or Path(file_path.stem + "_analysis")

    if "terminal" in formats:
        console.print("\n")
        console.print(Panel(Markdown(result.explanation), title="[bold]Outlier Explanation[/bold]", border_style="green"))

    if "json" in formats:
        json_path = Path(str(base_path) + ".json")
        _save_explanation_json(json_path, outlier_info, profile_result, result, cleaned_df, scorer, ids)
        console.print(f"\n[green]JSON saved to {json_path}[/green]")

    if "markdown" in formats:
        md_path = Path(str(base_path) + ".md")
        _save_explanation_markdown(md_path, context, outlier_info, profile_result, result, recommendation_result)
        console.print(f"[green]Markdown saved to {md_path}[/green]")

    if "csv" in formats:
        csv_path = Path(str(base_path) + ".csv")
        _save_annotated_csv(csv_path, df, outlier_info, result)
        console.print(f"[green]Annotated CSV saved to {csv_path}[/green]")


# ---------------------------------------------------------------------------
# recommend command
# ---------------------------------------------------------------------------

@app.command()
def recommend(
    file_path: Path = typer.Argument(..., help="CSV or JSON data file"),
    context: str = typer.Option("", "--context", help="Domain context (e.g. 'Active Directory Finance group')"),
):
    """Analyze a dataset and have the LLM recommend optimal detection settings."""
    console.print(f"\n[bold blue]Analyzing dataset structure...[/bold blue]")

    try:
        df = load_data(file_path)
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"  Loaded {len(df)} records with {len(df.columns)} columns")

    # Profile the dataset
    profile = DatasetAnalyzer().analyze(df)

    console.print("\n[bold]Dataset Profile:[/bold]")
    for col in profile.columns:
        type_str = f"[cyan]{col.dtype}[/cyan]"
        null_str = f" [yellow]({col.null_pct:.1f}% null)[/yellow]" if col.null_pct > 0 else ""
        console.print(f"  - {col.name}: {type_str}, {col.unique_count} unique{null_str}")

    if profile.id_column_candidates:
        console.print(f"\n  [green]Likely ID columns:[/green] {', '.join(profile.id_column_candidates)}")

    # Get LLM recommendations
    console.print(f"\n[bold blue]Consulting LLM for recommendations...[/bold blue]")
    recommender = SettingsRecommender()

    if not recommender.check_connection():
        console.print("[red]Azure OpenAI credentials not configured.[/red]")
        console.print("Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY environment variables.")
        raise typer.Exit(1)

    try:
        result = recommender.recommend(profile=profile, domain_context=context, file_path=str(file_path))
    except ConnectionError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    settings = result.settings
    console.print("\n[bold green]LLM Recommendations:[/bold green]")

    if settings.id_column:
        console.print(f"  [bold]ID Column:[/bold] {settings.id_column}")
    if settings.categorical_columns:
        console.print(f"  [bold]Categorical:[/bold] {', '.join(settings.categorical_columns)}")
    if settings.numerical_columns:
        console.print(f"  [bold]Numerical:[/bold] {', '.join(settings.numerical_columns)}")
    if settings.exclude_columns:
        console.print(f"  [bold]Exclude:[/bold] {', '.join(settings.exclude_columns)}")
    if settings.expected_outlier_pct:
        console.print(f"  [bold]Expected Outliers:[/bold] ~{settings.expected_outlier_pct}%")
    console.print(f"  [bold]Auto Method:[/bold] {settings.auto_method}")
    if settings.column_weights:
        console.print(f"  [bold]Column Weights:[/bold] {', '.join(f'{k}: {v}x' for k, v in settings.column_weights.items())}")
    if settings.outlier_signals:
        console.print("\n  [bold]Outlier Signals to Watch:[/bold]")
        for signal in settings.outlier_signals:
            console.print(f"    - {signal}")
    if settings.reasoning:
        console.print(f"\n  [bold]Reasoning:[/bold] {settings.reasoning}")

    console.print("\n" + "=" * 60)
    console.print("[bold]Suggested CLI Commands:[/bold]")
    console.print("=" * 60)
    console.print("\n[cyan]# Basic analysis:[/cyan]")
    console.print(result.cli_command)
    console.print("\n[cyan]# With LLM explanation:[/cyan]")
    explain_cmd = result.cli_command.replace("app.py analyze", "app.py explain")
    if context:
        explain_cmd += f' \\\n  --context "{context}"'
    console.print(explain_cmd)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _display_results(outlier_info, profile_result, df, profiler, cluster_result, ids):
    """Print a summary table and top-outliers table to the terminal."""
    console.print("\n[bold green]Analysis Complete[/bold green]")
    console.print(f"  Total records: {outlier_info.total_count}")
    console.print(f"  Outliers found: {outlier_info.outlier_count} ({outlier_info.outlier_percentage:.1f}%)")

    # Cluster summary table
    table = Table(title="\nCluster Summary")
    table.add_column("Cluster", style="cyan")
    table.add_column("Size", justify="right")
    table.add_column("Percentage", justify="right")
    for c in profile_result.clusters:
        label = "Noise" if c.label == -1 else str(c.label)
        table.add_row(label, str(c.size), f"{c.percentage:.1f}%")
    console.print(table)

    # Outliers table
    if outlier_info.outlier_count > 0:
        scorer = OutlierScorer()
        outlier_df = scorer.get_outlier_data(df, outlier_info)
        table = Table(title="\nTop Outliers")
        table.add_column("ID/Index", style="cyan")
        table.add_column("Score", justify="right")
        feature_cols = [c for c in outlier_df.columns if not c.startswith("_")][:4]
        for col in feature_cols:
            table.add_column(col)
        for i, (_, row) in enumerate(outlier_df.iterrows()):
            identifier = str(outlier_info.ids.iloc[i]) if outlier_info.ids is not None else str(i)
            score = f"{row['_outlier_score']:.2f}"
            values = [str(row[c])[:20] for c in feature_cols]
            table.add_row(identifier, score, *values)
        console.print(table)


def _save_analysis_json(output_path, outlier_info, profile_result, df, profiler, ids):
    scorer = OutlierScorer()
    outlier_df = scorer.get_outlier_data(df, outlier_info)
    result = {
        "summary": {
            "total_records": outlier_info.total_count,
            "outlier_count": outlier_info.outlier_count,
            "outlier_percentage": outlier_info.outlier_percentage,
            "n_clusters": profile_result.n_clusters,
        },
        "clusters": [
            {
                "label": c.label, "size": c.size, "percentage": c.percentage,
                "profile": {col.name: {"type": col.dtype, "mode": col.mode, "distribution": col.distribution} for col in c.columns},
            }
            for c in profile_result.clusters
        ],
        "outliers": [
            {
                "id": str(outlier_info.ids.iloc[i]) if outlier_info.ids is not None else i,
                "score": float(row["_outlier_score"]),
                "values": {k: str(v) for k, v in row.items() if not k.startswith("_")},
            }
            for i, (_, row) in enumerate(outlier_df.iterrows())
        ],
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, default=str)


def _save_explanation_json(output_path, outlier_info, profile_result, explanation_result, df, scorer, ids):
    outlier_df = scorer.get_outlier_data(df, outlier_info)
    result = {
        "summary": {
            "total_records": outlier_info.total_count,
            "outlier_count": outlier_info.outlier_count,
            "outlier_percentage": outlier_info.outlier_percentage,
            "n_clusters": profile_result.n_clusters,
        },
        "outliers": [
            {
                "id": str(outlier_info.ids.iloc[i]) if outlier_info.ids is not None else i,
                "score": float(row["_outlier_score"]),
                "values": {k: str(v) for k, v in row.items() if not k.startswith("_")},
            }
            for i, (_, row) in enumerate(outlier_df.iterrows())
        ],
        "explanation": {"model": explanation_result.model, "content": explanation_result.explanation},
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, default=str)


def _save_explanation_markdown(output_path, context, outlier_info, profile_result, explanation_result, recommendation_result=None):
    lines = [
        "# Outlier Analysis Report",
        "",
        f"**Dataset**: {context}" if context else "",
        f"**Total Records**: {outlier_info.total_count}",
        f"**Outliers Found**: {outlier_info.outlier_count} ({outlier_info.outlier_percentage:.1f}%)",
        f"**Clusters**: {profile_result.n_clusters}",
        "",
    ]

    if recommendation_result and recommendation_result.settings:
        s = recommendation_result.settings
        lines += ["## LLM Recommendations", ""]
        if s.expected_outlier_pct:
            lines.append(f"**Expected Outlier Rate**: ~{s.expected_outlier_pct}%")
        if s.column_weights:
            lines.append(f"**Important Columns**: {', '.join(f'{k} ({v}x)' for k, v in s.column_weights.items())}")
        if s.outlier_signals:
            lines += ["", "### Outlier Signals to Watch", ""] + [f"- {sig}" for sig in s.outlier_signals]
        if s.reasoning:
            lines += ["", "### Analysis Reasoning", "", s.reasoning]
        lines += ["", "---", ""]

    lines += ["## Cluster Summary", "", "| Cluster | Size | Percentage |", "|---------|------|------------|"]
    for c in profile_result.clusters:
        label = "Noise" if c.label == -1 else str(c.label)
        lines.append(f"| {label} | {c.size} | {c.percentage:.1f}% |")

    lines += ["", "## Cluster Profiles", ""]
    for cluster in profile_result.clusters:
        header = f"Noise/Outliers ({cluster.size} records)" if cluster.label == -1 \
            else f"Cluster {cluster.label} ({cluster.size} records, {cluster.percentage:.1f}%)"
        lines.append(f"### {header}")
        lines.append("")
        for col in cluster.columns:
            if col.dtype == "categorical":
                if col.mode_percentage >= 50:
                    lines.append(f"- **{col.name}**: {col.mode} ({col.mode_percentage:.0f}%)")
                else:
                    top = ", ".join(f"{k} ({v:.0f}%)" for k, v in list(col.distribution.items())[:3])
                    lines.append(f"- **{col.name}**: {top}")
            else:
                d = col.distribution
                lines.append(f"- **{col.name}**: median {d['median']}, range [{d['min']} - {d['max']}]")
        lines.append("")

    lines += [
        "## LLM Explanation", "",
        f"*Model: {explanation_result.model}*", "",
        explanation_result.explanation,
    ]

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def _save_annotated_csv(output_path, original_df, outlier_info, explanation_result):
    df = original_df.copy()
    df["_is_outlier"] = False
    df["_outlier_score"] = 0.0
    df["_why_outlier"] = ""
    df["_unusual_attributes"] = ""
    df["_risk_level"] = ""
    df["_recommended_action"] = ""

    for i, idx in enumerate(outlier_info.indices):
        df.loc[idx, "_is_outlier"] = True
        df.loc[idx, "_outlier_score"] = float(outlier_info.scores[i])

    if explanation_result.structured_analysis:
        lookup = {a.id: a for a in explanation_result.structured_analysis}
        for i, idx in enumerate(outlier_info.indices):
            oid = str(outlier_info.ids.iloc[i]) if outlier_info.ids is not None and i < len(outlier_info.ids) else str(idx)
            a = lookup.get(oid)
            if a:
                df.loc[idx, "_why_outlier"] = a.why_outlier
                df.loc[idx, "_unusual_attributes"] = a.unusual_attributes
                df.loc[idx, "_risk_level"] = a.risk_level
                df.loc[idx, "_recommended_action"] = a.recommended_action

    df.to_csv(output_path, index=False, encoding="utf-8")


if __name__ == "__main__":
    app()
