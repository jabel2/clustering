"""Recommend: profile dataset structure → ask LLM for optimal settings."""

import json
import re
from dataclasses import dataclass, field

import pandas as pd
from langchain_core.messages import HumanMessage, SystemMessage

from llm import get_llm, DEPLOYMENT, check_connection as _llm_ok


# ---------------------------------------------------------------------------
# Dataset profiling
# ---------------------------------------------------------------------------

@dataclass
class ColumnInfo:
    """Summary of a single column: type, cardinality, nulls, samples."""
    name: str
    dtype: str          # "categorical", "numerical", "boolean", or "text"
    unique_count: int
    null_count: int
    null_pct: float
    sample_values: list[str]
    min_val: float | None = None
    max_val: float | None = None
    mean_val: float | None = None
    median_val: float | None = None
    std_val: float | None = None
    top_values: dict[str, float] = field(default_factory=dict)  # value → percentage


@dataclass
class DatasetProfile:
    """Complete structural profile of a dataset."""
    n_rows: int
    n_columns: int
    columns: list[ColumnInfo]
    sample_rows: list[dict]
    id_column_candidates: list[str]


class DatasetAnalyzer:
    """Analyze a DataFrame's structure to help the LLM make recommendations."""

    def __init__(self, max_sample_values: int = 5, max_sample_rows: int = 3, max_top_values: int = 5):
        self.max_sample_values = max_sample_values
        self.max_sample_rows = max_sample_rows
        self.max_top_values = max_top_values

    def analyze(self, df: pd.DataFrame) -> DatasetProfile:
        """Return a DatasetProfile describing the DataFrame's structure."""
        columns = [self._analyze_column(df, col) for col in df.columns]
        sample_rows = [
            {k: str(v) for k, v in row.items()}
            for _, row in df.head(self.max_sample_rows).iterrows()
        ]
        return DatasetProfile(
            n_rows=len(df),
            n_columns=len(df.columns),
            columns=columns,
            sample_rows=sample_rows,
            id_column_candidates=self._find_id_candidates(df, columns),
        )

    def _analyze_column(self, df: pd.DataFrame, col: str) -> ColumnInfo:
        series = df[col]
        non_null = series.dropna()
        unique_count = series.nunique()
        null_count = int(series.isna().sum())
        null_pct = (null_count / len(df)) * 100 if len(df) > 0 else 0
        dtype = self._infer_dtype(series, unique_count, len(df))
        sample_values = [str(v) for v in non_null.head(self.max_sample_values).tolist()]

        info = ColumnInfo(
            name=col, dtype=dtype, unique_count=unique_count,
            null_count=null_count, null_pct=null_pct, sample_values=sample_values,
        )

        if dtype == "numerical":
            info.min_val = float(non_null.min()) if len(non_null) > 0 else None
            info.max_val = float(non_null.max()) if len(non_null) > 0 else None
            info.mean_val = float(non_null.mean()) if len(non_null) > 0 else None
            info.median_val = float(non_null.median()) if len(non_null) > 0 else None
            info.std_val = float(non_null.std()) if len(non_null) > 0 else None
        elif dtype == "categorical":
            vc = series.value_counts(normalize=True).head(self.max_top_values)
            info.top_values = {str(k): round(v * 100, 1) for k, v in vc.items()}

        return info

    @staticmethod
    def _infer_dtype(series: pd.Series, unique_count: int, n_rows: int) -> str:
        non_null = series.dropna()
        unique_vals = set(non_null.unique())

        if unique_vals <= {0, 1, True, False, "0", "1", "true", "false", "True", "False"}:
            return "boolean"
        if pd.api.types.is_numeric_dtype(series):
            return "numerical"
        # Long free-text columns (high cardinality + long average string)
        if unique_count > 0.5 * n_rows and non_null.astype(str).str.len().mean() > 50:
            return "text"
        return "categorical"

    @staticmethod
    def _find_id_candidates(df: pd.DataFrame, columns: list[ColumnInfo]) -> list[str]:
        candidates = []
        for col in columns:
            uniqueness = col.unique_count / len(df) if len(df) > 0 else 0
            name_lower = col.name.lower()
            has_id_name = any(t in name_lower for t in ["id", "key", "uuid", "guid", "identifier", "code"])
            if uniqueness > 0.9 or (has_id_name and uniqueness > 0.5):
                candidates.append(col.name)
        return candidates

    @staticmethod
    def to_prompt_text(profile: DatasetProfile) -> str:
        """Format the profile as readable text for an LLM prompt."""
        lines = [f"Dataset: {profile.n_rows} rows, {profile.n_columns} columns", "", "## Columns"]

        for col in profile.columns:
            line = f"- **{col.name}** ({col.dtype})"
            if col.null_pct > 0:
                line += f" [{col.null_pct:.1f}% null]"
            line += f" - {col.unique_count} unique values"
            lines.append(line)

            if col.dtype == "numerical" and col.mean_val is not None:
                lines.append(f"  Range: [{col.min_val:.2f}, {col.max_val:.2f}], Mean: {col.mean_val:.2f}, Std: {col.std_val:.2f}")
            elif col.dtype == "categorical" and col.top_values:
                top = ", ".join(f"'{k}': {v}%" for k, v in list(col.top_values.items())[:3])
                lines.append(f"  Top values: {top}")
            elif col.sample_values:
                samples = ", ".join(f"'{v}'" for v in col.sample_values[:3])
                lines.append(f"  Examples: {samples}")

        if profile.id_column_candidates:
            lines += ["", f"Likely ID columns: {', '.join(profile.id_column_candidates)}"]

        if profile.sample_rows:
            lines += ["", "## Sample Rows"]
            for i, row in enumerate(profile.sample_rows, 1):
                row_str = ", ".join(f"{k}={v}" for k, v in list(row.items())[:6])
                if len(row) > 6:
                    row_str += ", ..."
                lines.append(f"{i}. {row_str}")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# LLM settings recommender
# ---------------------------------------------------------------------------

@dataclass
class RecommendedSettings:
    """Settings recommended by the LLM for a specific dataset."""
    id_column: str | None = None
    categorical_columns: list[str] = field(default_factory=list)
    numerical_columns: list[str] = field(default_factory=list)
    exclude_columns: list[str] = field(default_factory=list)
    expected_outlier_pct: float | None = None
    auto_method: str = "heuristic"
    min_cluster_size: int | None = None
    column_weights: dict[str, float] = field(default_factory=dict)
    outlier_signals: list[str] = field(default_factory=list)
    reasoning: str = ""


@dataclass
class RecommendationResult:
    """Full result from the recommendation LLM call."""
    settings: RecommendedSettings
    raw_response: str
    model: str
    cli_command: str


class SettingsRecommender:
    """Ask Azure OpenAI to recommend outlier detection settings for a dataset.

    Connection settings are read from llm.py (or the corresponding environment variables).
    """

    def __init__(self, temperature: float = 0.1):
        self._llm = get_llm(temperature=temperature, max_tokens=2000)

    def recommend(
        self,
        profile: DatasetProfile,
        domain_context: str = "",
        file_path: str = "",
    ) -> RecommendationResult:
        """Get LLM-recommended settings for the given DatasetProfile."""
        prompt = self._build_prompt(profile, domain_context)
        try:
            response = self._llm.invoke([
                SystemMessage(content=(
                    "You are a data science expert specializing in anomaly detection and clustering. "
                    "Help users configure outlier detection tools by analyzing their datasets. "
                    "Be specific and practical."
                )),
                HumanMessage(content=prompt),
            ])

            raw = response.content
            settings = self._parse_settings(raw, profile)
            return RecommendationResult(
                settings=settings,
                raw_response=raw,
                model=DEPLOYMENT,
                cli_command=self._build_cli_command(settings, file_path),
            )

        except Exception as e:
            msg = str(e)
            if any(k in msg.lower() for k in ("connection", "refused", "unauthorized", "authentication", "401", "403")):
                raise ConnectionError(
                    "Cannot connect to Azure OpenAI. "
                    "Check that AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY are set correctly."
                ) from e
            raise

    def check_connection(self) -> bool:
        """Return True if Azure credentials appear to be configured."""
        return _llm_ok()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_text(text: str) -> str:
        """Replace Unicode characters that cause encoding errors on Windows consoles."""
        if not text:
            return text
        replacements = {
            '\u2011': '-', '\u2013': '-', '\u2014': '--',
            '\u2018': "'", '\u2019': "'", '\u201c': '"', '\u201d': '"',
            '\u2026': '...', '\u00a0': ' ', '\u202f': ' ', '\u2009': ' ',
            '\u200b': '', '\u2010': '-', '\u2012': '-', '\u2015': '--',
        }
        for char, rep in replacements.items():
            text = text.replace(char, rep)
        result = []
        for char in text:
            try:
                char.encode('cp1252')
                result.append(char)
            except UnicodeEncodeError:
                result.append('?')
        return ''.join(result)

    @staticmethod
    def _build_prompt(profile: DatasetProfile, domain_context: str) -> str:
        profile_text = DatasetAnalyzer.to_prompt_text(profile)
        prompt = f"""I'm configuring an outlier detection tool that uses HDBSCAN clustering. Please analyze this dataset and recommend settings.

## Dataset Profile
{profile_text}

"""
        if domain_context:
            prompt += f"## Domain Context\n{domain_context}\n\n"

        prompt += """## What I Need

Please provide recommendations in this exact JSON format:

```json
{
  "id_column": "column_name or null",
  "categorical_columns": ["col1", "col2"],
  "numerical_columns": ["col3", "col4"],
  "exclude_columns": ["cols to skip"],
  "expected_outlier_pct": 1.5,
  "auto_method": "heuristic|balanced|dbcv",
  "min_cluster_size": null,
  "column_weights": {"important_col": 2.0},
  "outlier_signals": ["Signal 1", "Signal 2"],
  "reasoning": "Brief explanation"
}
```

Guidelines:
1. **id_column** — unique row identifier (exclude from clustering)
2. **categorical_columns** — one-hot encode these (departments, titles, locations)
3. **numerical_columns** — scale these numerically (counts, amounts)
4. **exclude_columns** — skip IDs, names, free text, timestamps
5. **expected_outlier_pct** — typical datasets: 1–5%
6. **auto_method** — "heuristic" for most cases, "balanced" for 5–15% outlier rate, "dbcv" for best cluster quality
7. **column_weights** — more important columns get weight > 1.0
8. **outlier_signals** — domain-specific patterns that indicate anomalies

Provide your analysis then the JSON block.
"""
        return prompt

    def _parse_settings(self, response: str, profile: DatasetProfile) -> RecommendedSettings:
        settings = RecommendedSettings()
        try:
            match = re.search(r"```json\s*([\s\S]*?)\s*```", response)
            if not match:
                match = re.search(r"```\s*(\{[\s\S]*?\})\s*```", response)
            if match:
                data = json.loads(match.group(1).strip())
                settings.id_column = data.get("id_column")
                settings.categorical_columns = data.get("categorical_columns", [])
                settings.numerical_columns = data.get("numerical_columns", [])
                settings.exclude_columns = data.get("exclude_columns", [])
                settings.expected_outlier_pct = data.get("expected_outlier_pct")
                settings.auto_method = data.get("auto_method", "heuristic")
                settings.min_cluster_size = data.get("min_cluster_size")
                settings.column_weights = data.get("column_weights", {})
                settings.outlier_signals = [self._sanitize_text(s) for s in data.get("outlier_signals", [])]
                settings.reasoning = self._sanitize_text(data.get("reasoning", ""))
        except (json.JSONDecodeError, KeyError, TypeError):
            settings.reasoning = "Could not parse structured response. See raw output."
            if profile.id_column_candidates:
                settings.id_column = profile.id_column_candidates[0]
        return settings

    @staticmethod
    def _build_cli_command(settings: RecommendedSettings, file_path: str) -> str:
        from pathlib import Path
        parts = ["python app.py analyze"]
        if file_path:
            # Show a clean relative path
            try:
                rel = Path(file_path).relative_to(Path.cwd())
                parts.append(str(rel).replace("\\", "/"))
            except ValueError:
                parts.append(file_path.replace("\\", "/"))
        if settings.id_column:
            parts.append(f"--id-column {settings.id_column}")
        if settings.categorical_columns:
            parts.append(f'--categorical "{",".join(settings.categorical_columns)}"')
        if settings.numerical_columns:
            parts.append(f'--numerical "{",".join(settings.numerical_columns)}"')
        parts.append("--auto-cluster-size")
        parts.append(f"--auto-method {settings.auto_method}")
        return " \\\n  ".join(parts)
