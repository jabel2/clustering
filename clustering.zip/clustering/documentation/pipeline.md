# pipeline.py — Data Loading, Cleaning, and Feature Engineering

## What This File Does

`pipeline.py` is the first stage of every analysis. It takes a raw data file and transforms it into a numerical matrix that the clustering algorithm can work with.

Three steps happen in sequence:

```
Raw file (CSV or JSON)
    │
    ▼ load_data()
DataFrame (raw, unchanged)
    │
    ▼ clean_data()
DataFrame (missing values filled, types coerced, ID column extracted)
    │
    ▼ engineer_features()
FeatureResult (numpy array ready for clustering + metadata)
```

---

## Functions and Classes

### `load_data(file_path)`

Reads a CSV or JSON file into a pandas DataFrame.

```python
df = load_data("employees.csv")
df = load_data("data.json")
```

**Supported JSON layouts:**
- Array of objects: `[{"name": "Alice", ...}, {"name": "Bob", ...}]`
- Object with a `"data"` key: `{"data": [...], "metadata": {...}}`
- Single object: `{"name": "Alice", ...}` → becomes a one-row DataFrame

Raises `FileNotFoundError` if the file doesn't exist, `ValueError` if the extension is not `.csv` or `.json`.

---

### `clean_data(df, id_column=None, exclude_columns=None)`

Prepares raw data for feature engineering.

```python
cleaned_df, ids = clean_data(df, id_column="employee_id")
```

Returns a tuple:
- `cleaned_df` — the DataFrame without the ID column, with missing values filled
- `ids` — a pandas Series of the ID column values (or `None` if no ID column specified)

**What it does:**

1. **Extracts the ID column** — removes it from the working data so it doesn't influence clustering; saves it for labeling outliers in the output.

2. **Fills missing values:**
   - Numeric columns → filled with the **median** (not mean — medians are not pulled toward extreme values)
   - Text/categorical columns → filled with the **mode** (most common value), or `"Unknown"` if the column is entirely null

3. **Coerces types** — passes the data through `_coerce_types()`:
   - Object columns that look numeric (>90% of values parse as numbers) get converted to float
   - Boolean-like columns (`"true"/"false"`, `"yes"/"no"`, `"y"/"n"`, `"1"/"0"`) get converted to integer 0/1

---

### `engineer_features(df, config=None)`

Converts the cleaned DataFrame into a numerical feature matrix.

```python
feature_result = engineer_features(cleaned_df)

# Or with explicit column types:
config = FeatureConfig(
    categorical_columns=["department", "job_title", "location"],
    numerical_columns=["tenure_days", "access_level"],
)
feature_result = engineer_features(cleaned_df, config)
```

Returns a `FeatureResult` (see below).

**What it does:**

1. **Auto-detects column types** if not specified:
   - Numeric columns with fewer than 10 unique values AND less than 5% unique ratio → treated as categorical (e.g., an `access_level` column with values 1–5)
   - All other numeric columns → numerical
   - Object/text columns → categorical

2. **Encodes categorical columns** with one-hot encoding. A `department` column with values `Finance`, `HR`, `IT` becomes three binary columns: `department_Finance`, `department_HR`, `department_IT`.
   - Columns with more than 20 unique values (configurable) have the rarest categories grouped into `_OTHER_` to prevent an explosion of feature columns.

3. **Scales numerical columns** with `RobustScaler`. Each column is transformed so its median becomes 0 and its interquartile range (IQR) becomes 1. This is specifically chosen because standard deviation-based scaling gets distorted by outliers.

4. **Stacks** categorical and numerical features side-by-side into a single numpy array.

---

### `FeatureConfig` dataclass

Controls how `engineer_features()` classifies columns.

| Field | Default | Meaning |
|-------|---------|---------|
| `categorical_columns` | `[]` | Force these columns to be one-hot encoded |
| `numerical_columns` | `[]` | Force these columns to be RobustScaler scaled |
| `high_cardinality_threshold` | `20` | Max unique values before rare ones are grouped as `_OTHER_` |

If both lists are empty (the default), all column types are auto-detected.

---

### `FeatureResult` dataclass

The output of `engineer_features()`. Carries both the data and metadata about what was done.

| Field | Type | Contents |
|-------|------|---------|
| `features` | `np.ndarray` | The complete feature matrix — shape `(n_rows, n_features)` |
| `feature_names` | `list[str]` | Name for every column in the matrix (e.g., `department_Finance`, `tenure_days`) |
| `categorical_columns` | `list[str]` | Original column names that were one-hot encoded |
| `numerical_columns` | `list[str]` | Original column names that were scaled |
| `encoders` | `dict` | The fitted `OneHotEncoder` and `RobustScaler` objects |

The `ClusterProfiler` in `detect.py` needs `categorical_columns` and `numerical_columns` to describe clusters in human-readable terms using the original column names.

---

## Design Decisions

**Why median for missing values, not mean?**
The dataset likely contains outliers (that's the whole point). The mean gets pulled toward extreme values, which would then distort the imputation for normal records. The median is unaffected.

**Why group high-cardinality categories as `_OTHER_`?**
One-hot encoding a column with 500 unique values creates 500 binary features. That makes the feature space very sparse and degrades HDBSCAN's distance calculations. Keeping the top 19 values and grouping the rest preserves the important patterns without dimension explosion.

**Why RobustScaler specifically?**
`StandardScaler` divides by standard deviation. If a column has a few extreme outliers, they inflate the standard deviation and compress all the normal variation into a narrow band. `RobustScaler` uses IQR instead — extreme values don't affect it.

---

## Example: What the feature matrix looks like

Given this cleaned data:

| department | job_title | tenure_days |
|-----------|-----------|------------|
| Finance | Analyst | 365 |
| Finance | Controller | 1200 |
| IT | Developer | 720 |
| *Outlier* | *Consultant* | *9500* |

After `engineer_features()`, the matrix (before scaling for readability) would look like:

| dept_Finance | dept_IT | title_Analyst | title_Controller | title_Developer | title_Consultant | tenure_days |
|---|---|---|---|---|---|---|
| 1 | 0 | 1 | 0 | 0 | 0 | -0.4 |
| 1 | 0 | 0 | 1 | 0 | 0 | 0.1 |
| 0 | 1 | 0 | 0 | 1 | 0 | -0.2 |
| 0 | 0 | 0 | 0 | 0 | 1 | **4.8** |

The outlier's extreme tenure shows clearly in the scaled column, and their unusual job title creates its own column. HDBSCAN will see this as a very isolated point.
