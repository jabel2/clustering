# app.py — CLI Commands and Output Formatting

## What This File Does

`app.py` is the entry point. It defines the three CLI commands, orchestrates the other modules, and handles all output formatting.

Run any command with `--help` to see its options:
```bash
python app.py --help
python app.py analyze --help
python app.py explain --help
python app.py recommend --help
```

---

## The Shared Pipeline Helper: `_run_pipeline()`

Both `analyze` and `explain` need to do the same work: load data, clean it, build features, cluster, score outliers, and profile clusters. Rather than duplicating this logic, both commands call a single shared function:

```python
df, cleaned_df, ids, feature_result, cluster_result, outlier_info, profiler, profile_result = (
    _run_pipeline(file_path, id_column, categorical, numerical,
                  min_cluster_size, auto_cluster_size, auto_method, outlier_threshold)
)
```

After `_run_pipeline()` returns, `analyze` formats and saves the results. `explain` takes the same results and additionally calls the LLM.

---

## Command: `analyze`

**What it does:** Runs the full data → cluster → score pipeline and displays results. No Ollama required.

```bash
python app.py analyze <file_path> [options]
```

### Options

| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--id-column` | `-i` | None | Column to use as row identifier (excluded from clustering, used for labeling) |
| `--categorical` | `-c` | None | Comma-separated column names to force-encode as categorical |
| `--numerical` | `-n` | None | Comma-separated column names to force-scale as numerical |
| `--min-cluster-size` | `-m` | `5` | Minimum cluster size for HDBSCAN. Ignored if `--auto-cluster-size` is set. |
| `--auto-cluster-size` | `-a` | off | Automatically find the best `min_cluster_size` |
| `--auto-method` | | `dbcv` | Strategy for auto-tuning: `dbcv`, `balanced`, or `heuristic` |
| `--outlier-threshold` | `-t` | `0.8` | GLOSH score cutoff. Records at or above this are flagged as outliers. |
| `--output` | `-o` | None | Path to save results as JSON |

### Output

Prints to terminal:
- **Cluster summary table** — label, size, percentage for every cluster
- **Top outliers table** — ID, score, and first 4 feature column values for each outlier

Optionally saves a JSON file with the full cluster profiles and outlier list.

### Examples

```bash
# Basic analysis, auto-detect column types
python app.py analyze employees.csv --id-column employee_id

# With explicit column types and auto cluster sizing
python app.py analyze employees.csv \
  --id-column employee_id \
  --categorical "department,job_title,location" \
  --numerical "tenure_days,access_level" \
  --auto-cluster-size

# Lower threshold to flag more borderline outliers
python app.py analyze employees.csv --outlier-threshold 0.6

# Save results to JSON
python app.py analyze employees.csv --output results.json
```

---

## Command: `explain`

**What it does:** Runs the same pipeline as `analyze`, then sends the results to Azure OpenAI for natural-language explanation. Saves output in multiple formats.

```bash
python app.py explain <file_path> [options]
```

### Options (in addition to all analyze options)

| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--context` | | `""` | Description of the dataset. More context = better LLM explanations. |
| `--max-outliers-llm` | | `25` | Maximum outliers to send to the LLM. Prevents token overflow for large datasets. |
| `--recommend` | `-r` | off | Also ask the LLM for settings recommendations and include in the report |
| `--output-format` | `-f` | `json,terminal,markdown,csv` | Output formats (comma-separated) |
| `--output` | `-o` | `<filename>_analysis` | Base path for output files (extensions added automatically) |

### Output Formats

| Format | File | Contents |
|--------|------|---------|
| `terminal` | (none) | Formatted panel with the LLM's explanation printed to the console |
| `json` | `<base>.json` | Summary, outlier list with values, full explanation text |
| `markdown` | `<base>.md` | Human-readable report with cluster profiles, LLM explanation, optional recommendations |
| `csv` | `<base>.csv` | Original dataset with 6 appended columns (see below) |

**Annotated CSV columns:**

| Column | Type | Description |
|--------|------|-------------|
| `_is_outlier` | bool | `True` if this record is an outlier |
| `_outlier_score` | float | GLOSH score (0–1) |
| `_why_outlier` | str | LLM's brief explanation |
| `_unusual_attributes` | str | Comma-separated list of unusual attributes |
| `_risk_level` | str | `Low`, `Medium`, or `High` |
| `_recommended_action` | str | `Review`, `Flag for removal`, or `Likely legitimate` |

### Examples

```bash
# Full analysis with LLM explanation, default output formats
python app.py explain employees.csv \
  --id-column employee_id \
  --auto-cluster-size \
  --context "HR dataset: all full-time employees"

# Only save annotated CSV (skip terminal/json/markdown)
python app.py explain employees.csv \
  --id-column employee_id \
  --output-format csv \
  --output hr_outliers

# Include recommendations in the report
python app.py explain employees.csv \
  --recommend \
  --context "Finance team AD group"

# Limit to top 10 outliers sent to LLM (useful for very large datasets)
python app.py explain employees.csv \
  --max-outliers-llm 10 \
  --output-format "terminal,csv"
```

---

## Command: `recommend`

**What it does:** Analyzes the dataset's structure and asks Azure OpenAI to recommend the best settings.

```bash
python app.py recommend <file_path> [options]
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `--context` | `""` | Domain description to help the LLM understand what the data represents |

### Output

Prints to terminal:
- **Dataset profile** — column names, types, unique counts, null rates
- **Likely ID columns** — auto-detected identifier columns
- **LLM recommendations** — each recommended setting with the LLM's reasoning
- **Outlier signals** — domain-specific patterns to watch for
- **Suggested CLI commands** — ready-to-run `analyze` and `explain` commands

### Example

```bash
python app.py recommend finance_group.csv --context "Active Directory Finance-Admins group"
```

Sample output:
```
Dataset Profile:
  - user_id: categorical, 342 unique
  - department: categorical, 6 unique
  - job_title: categorical, 24 unique
  - tenure_days: numerical, 288 unique
  - access_level: numerical, 5 unique

Likely ID columns: user_id

LLM Recommendations:
  ID Column: user_id
  Categorical: department, job_title, location, account_type
  Numerical: tenure_days, access_level
  Expected Outliers: ~2.5%
  Auto Method: heuristic

Suggested CLI Commands:
python app.py analyze finance_group.csv \
  --id-column user_id \
  --categorical "department,job_title,location,account_type" \
  --numerical "tenure_days,access_level" \
  --auto-cluster-size \
  --auto-method heuristic
```

---

## Output Helper Functions

These private functions handle formatting and saving results. They're called by the CLI commands above.

| Function | Called by | Purpose |
|----------|-----------|---------|
| `_run_pipeline()` | `analyze`, `explain` | Shared: load → clean → features → cluster → score → profile |
| `_display_auto_size_details()` | `_run_pipeline` | Show top 3 auto-tune candidates in terminal |
| `_display_results()` | `analyze` | Print cluster summary and top-outliers tables |
| `_save_analysis_json()` | `analyze --output` | Save cluster profiles and outlier list as JSON |
| `_save_explanation_json()` | `explain --output-format json` | Save summary, outliers, and explanation as JSON |
| `_save_explanation_markdown()` | `explain --output-format markdown` | Generate full Markdown report |
| `_save_annotated_csv()` | `explain --output-format csv` | Add analysis columns to original CSV |

---

## JSON Output Structure

### `analyze --output results.json`

```json
{
  "summary": {
    "total_records": 500,
    "outlier_count": 12,
    "outlier_percentage": 2.4,
    "n_clusters": 3
  },
  "clusters": [
    {
      "label": 0,
      "size": 423,
      "percentage": 84.6,
      "profile": {
        "department": {
          "type": "categorical",
          "mode": "Finance",
          "distribution": {"Finance": 91.0, "HR": 5.2, "IT": 3.8}
        },
        "tenure_days": {
          "type": "numerical",
          "mode": 1095.0,
          "distribution": {"mean": 1187.3, "median": 1095.0, "std": 312.4, "min": 180.0, "max": 4200.0}
        }
      }
    }
  ],
  "outliers": [
    {
      "id": "EMP_4821",
      "score": 0.94,
      "values": {"department": "Marketing", "job_title": "Cloud Architect", "tenure_days": "12500"}
    }
  ]
}
```

### `explain --output-format json`

Same as above, with the `clusters` section replaced by:
```json
{
  "explanation": {
    "model": "gpt-oss:20b",
    "content": "## Analysis\n\n### EMP_4821\nThis record is highly anomalous..."
  }
}
```

---

## Dependencies

```python
import typer          # CLI framework: argument parsing, commands, help text
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table    # Terminal formatting for tables and panels

from pipeline import load_data, clean_data, engineer_features, FeatureConfig
from detect import HDBSCANClusterer, OutlierScorer, ClusterProfiler
from explain import ContextBuilder, ExplanationAgent
from recommend import DatasetAnalyzer, SettingsRecommender
```
