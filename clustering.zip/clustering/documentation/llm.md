# llm.py — Azure OpenAI Settings

## What This File Does

`llm.py` is the single place to configure Azure OpenAI for the entire app. Every module that needs a language model imports `get_llm()` from here — so updating your endpoint, API key, or deployment only requires editing one file.

---

## Settings

The four constants at the top of the file control the connection:

| Constant | Environment variable | Default | Description |
|----------|---------------------|---------|-------------|
| `DEPLOYMENT` | `AZURE_DEPLOYMENT` | `"gpt-4o"` | The Azure OpenAI deployment name |
| `ENDPOINT` | `AZURE_OPENAI_ENDPOINT` | `""` | Your Azure resource endpoint URL |
| `API_KEY` | `AZURE_OPENAI_API_KEY` | `""` | Your API key |
| `API_VERSION` | `OPENAI_API_VERSION` | `"2024-02-01"` | The API version string |

**Option 1 — Edit the file directly:**
```python
# llm.py
DEPLOYMENT  = "my-gpt4o-deployment"
ENDPOINT    = "https://my-resource.openai.azure.com/"
API_KEY     = "abc123..."
API_VERSION = "2024-02-01"
```

**Option 2 — Use environment variables (recommended for shared or production environments):**
```bash
export AZURE_DEPLOYMENT="my-gpt4o-deployment"
export AZURE_OPENAI_ENDPOINT="https://my-resource.openai.azure.com/"
export AZURE_OPENAI_API_KEY="abc123..."
export OPENAI_API_VERSION="2024-02-01"
```

If an environment variable is set, it takes priority over the hardcoded constant.

---

## Functions

### `get_llm(temperature, max_tokens) → AzureChatOpenAI`

Returns a configured `AzureChatOpenAI` instance using the settings above.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `temperature` | `0.1` | Sampling randomness (0 = deterministic, 1 = creative) |
| `max_tokens` | `4000` | Maximum response length |

`temperature` and `max_tokens` vary by use case — `explain.py` uses 4000 tokens, `recommend.py` uses 2000 — so they remain per-call parameters rather than global settings.

### `check_connection() → bool`

Returns `True` if both `ENDPOINT` and `API_KEY` are non-empty. Used by `ExplanationAgent` and `SettingsRecommender` before making a call.

```python
from llm import check_connection

if not check_connection():
    print("Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY")
```

---

## Who Imports From Here

| File | What it imports | How it uses it |
|------|----------------|----------------|
| `explain.py` | `get_llm`, `DEPLOYMENT`, `check_connection` | `ExplanationAgent` creates its LLM via `get_llm()` |
| `recommend.py` | `get_llm`, `DEPLOYMENT`, `check_connection` | `SettingsRecommender` creates its LLM via `get_llm()` |

---

## Getting Your Azure OpenAI Credentials

1. Go to the [Azure Portal](https://portal.azure.com) → Azure OpenAI → your resource
2. **Endpoint**: Keys and Endpoint → Endpoint URL
3. **API Key**: Keys and Endpoint → KEY 1 or KEY 2
4. **Deployment name**: Azure OpenAI Studio → Deployments → your deployment name
5. **API version**: Use `2024-02-01` (the default) unless you need a newer feature
