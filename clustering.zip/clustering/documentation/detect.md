# detect.py — Clustering, Outlier Scoring, and Cluster Profiling

## What This File Does

`detect.py` is the core of the system. It takes the numerical feature matrix from `pipeline.py` and:

1. Runs HDBSCAN to group similar records into clusters
2. Scores every record for how anomalous it is (GLOSH score)
3. Identifies which records are outliers
4. Profiles each cluster so results are human-readable

```
Feature matrix (from pipeline.py)
    │
    ▼ HDBSCANClusterer.fit()
ClusterResult: labels, probabilities, outlier scores
    │
    ▼ OutlierScorer.score()
OutlierInfo: which rows are outliers, sorted by score
    │
    ▼ ClusterProfiler.profile()
ProfileResult: what each cluster looks like in original values
    │
    ▼ ClusterProfiler.compute_deviation_scores()  [explain command only]
DataFrame: how each outlier deviates from the majority
```

---

## Classes and Methods

### `HDBSCANClusterer`

A thin wrapper around the `hdbscan` library that returns a structured `ClusterResult`.

**Constructor parameters:**

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `min_cluster_size` | `5` | The smallest group that counts as a real cluster. The most important parameter — see tuning section below. |
| `min_samples` | `None` | Controls how conservative clustering is. If `None`, uses `min_cluster_size`. Lower = more liberal (more points assigned to clusters). |
| `metric` | `"euclidean"` | Distance function. Euclidean works well for normalized numerical + one-hot data. |
| `cluster_selection_method` | `"eom"` | `"eom"` (Excess of Mass) allows clusters of different sizes. `"leaf"` produces more uniform clusters. |

**`.fit(features)` method:**

```python
clusterer = HDBSCANClusterer(min_cluster_size=10)
result = clusterer.fit(feature_matrix)
```

Returns a `ClusterResult` with:
- `labels` — integer cluster label for each row. Label `-1` means "noise" (HDBSCAN couldn't fit it into any cluster).
- `probabilities` — how confidently each point belongs to its cluster (0–1)
- `outlier_scores` — GLOSH score for each point (0 = very normal, 1 = very anomalous)
- `n_clusters` — number of real clusters found (not counting noise)
- `n_noise` — number of noise points

---

### `HDBSCANClusterer.auto_min_cluster_size()` (static method)

Automatically searches for the best `min_cluster_size` value.

```python
best_size, details = HDBSCANClusterer.auto_min_cluster_size(
    feature_matrix, method="dbcv"
)
```

Searches values from 3 to `min(50, √n_samples)` and evaluates each one.

**The three methods:**

#### `"dbcv"` (default)
Uses the DBCV (Density-Based Clustering Validation) score — a measure of cluster quality that considers how compact clusters are and how well-separated they are from each other.

Raw DBCV is adjusted with penalties to avoid degenerate solutions:
- **Penalty if < 1% effective outliers** — a solution that puts everyone into clusters has no detection value
- **Penalty if one cluster has > 95% of data** — the algorithm absorbed outliers into the main cluster
- **Penalty if fewer than 2 clusters** — meaningless single-cluster solutions

```
adjusted_score = raw_dbcv
                 × (1 - penalty_for_no_outliers)
                 × (1 - penalty_for_dominant_cluster)
                 × (0.5 if only 1 cluster)
```

#### `"balanced"`
Finds the `min_cluster_size` that produces an outlier rate closest to the midpoint of the 5–15% target range. Useful when you know roughly what fraction of your data should be anomalous.

#### `"heuristic"`
Simply computes `log2(n_samples)`. No grid search — instant result. Good for quick exploration or very large datasets.

---

### `OutlierScorer`

Combines GLOSH scores and cluster noise labels to produce a ranked list of outliers.

```python
scorer = OutlierScorer(outlier_threshold=0.8)
outlier_info = scorer.score(cluster_result, ids=employee_ids)
```

**A record is flagged as an outlier if either:**
- Its GLOSH score ≥ `outlier_threshold` (default 0.8), **OR**
- HDBSCAN assigned it label `-1` (noise)

Using both criteria catches two types of anomalies:
- Records HDBSCAN explicitly couldn't cluster (noise) — definitively unusual
- Records that technically got assigned to a cluster but whose neighborhood is very sparse — borderline unusual

Results are sorted by score descending, so the most anomalous records appear first.

**`.get_outlier_data(df, outlier_info)`**

Extracts the original data rows for all outliers and appends a `_outlier_score` column.

```python
outlier_df = scorer.get_outlier_data(cleaned_df, outlier_info)
# outlier_df has the same columns as cleaned_df plus _outlier_score
```

---

### `ClusterProfiler`

Describes each cluster using the **original column values** (before encoding) so results are human-readable.

```python
profiler = ClusterProfiler(
    categorical_columns=feature_result.categorical_columns,
    numerical_columns=feature_result.numerical_columns,
)
profile_result = profiler.profile(cleaned_df, cluster_result)
```

For each cluster and each column, it produces a `ColumnProfile`:

- **Categorical columns**: mode (most common value), mode percentage, top-5 value distribution
- **Numerical columns**: mean, median, std, min, max

**`.compute_deviation_scores(df, outlier_indices, cluster_result)`**

For the `explain` command, this computes how each outlier differs from the majority cluster (the largest non-noise cluster).

```python
deviation_df = profiler.compute_deviation_scores(
    cleaned_df, outlier_info.indices, cluster_result
)
```

Returns a DataFrame with two columns:
- `index` — the row index of the outlier
- `deviations` — a dict describing what's different:
  - For categorical: `{col: {outlier_value, majority_value, frequency_in_majority}}`
  - For numerical: `{col: {outlier_value, majority_median, z_score}}` — only included if `|z_score| > 2`

These deviations become the most useful part of the LLM prompt — they tell the model exactly *what* to explain rather than making it infer from raw numbers.

---

## Data Classes

### `ClusterResult`
Output of `HDBSCANClusterer.fit()`.

| Field | Type | Description |
|-------|------|-------------|
| `labels` | `np.ndarray` | Cluster label per row (-1 = noise) |
| `probabilities` | `np.ndarray` | Cluster membership confidence (0–1) |
| `outlier_scores` | `np.ndarray` | GLOSH anomaly score (0–1) |
| `n_clusters` | `int` | Number of real clusters |
| `n_noise` | `int` | Number of noise points |

### `OutlierInfo`
Output of `OutlierScorer.score()`.

| Field | Type | Description |
|-------|------|-------------|
| `indices` | `np.ndarray` | Row indices of outliers, sorted by score desc |
| `scores` | `np.ndarray` | GLOSH score for each outlier |
| `ids` | `pd.Series` or `None` | ID values for each outlier (if ID column given) |
| `total_count` | `int` | Total records in dataset |
| `outlier_count` | `int` | Number of outliers found |
| `outlier_percentage` | `float` | Percentage of records that are outliers |

### `ColumnProfile`
Summary of one column within one cluster.

| Field | Type | Description |
|-------|------|-------------|
| `name` | `str` | Column name |
| `dtype` | `str` | `"categorical"` or `"numerical"` |
| `mode` | `Any` | Most common value (categorical) or median (numerical) |
| `mode_percentage` | `float` | % of rows with the mode value (categorical only) |
| `distribution` | `dict` | Top values with percentages (categorical) or stats dict (numerical) |

### `ClusterProfile`
Summary of one cluster.

| Field | Type | Description |
|-------|------|-------------|
| `label` | `int` | HDBSCAN cluster label (-1 for noise) |
| `size` | `int` | Number of records |
| `percentage` | `float` | % of total dataset |
| `columns` | `list[ColumnProfile]` | Profile for each column |

### `ProfileResult`
Container for all cluster profiles.

| Field | Type | Description |
|-------|------|-------------|
| `clusters` | `list[ClusterProfile]` | One entry per cluster (including noise) |
| `overall_size` | `int` | Total dataset size |
| `n_clusters` | `int` | Number of real clusters |

---

## Understanding HDBSCAN and GLOSH

### HDBSCAN in plain terms

Think of the data as stars in a galaxy. Dense regions (lots of stars close together) form clusters. Isolated stars — or stars on the edge of sparse regions — become noise.

HDBSCAN works by:
1. Computing how dense the neighborhood is around every point
2. Building a "reachability" hierarchy: how much do you have to "zoom out" (lower your density threshold) before two points join the same cluster?
3. Cutting the hierarchy at a level that produces stable, meaningful clusters

**`min_cluster_size`** controls the minimum star count to qualify as a galaxy. Smaller values → more clusters, more sensitivity to small groups. Larger values → fewer, more robust clusters.

### GLOSH score in plain terms

After the hierarchy is built, GLOSH asks: "Compared to the densest region this point ever appeared near, how isolated is it now in its current cluster?"

A score of 1.0 means the point never really belonged anywhere. A score of 0.0 means it's deep inside a dense cluster.

### Why use both GLOSH score AND noise label?

- A point with GLOSH ≥ 0.8 is statistically anomalous even if HDBSCAN assigned it a cluster (it's on the fringe of one)
- A noise point (label = -1) is explicitly unclustered, even if its GLOSH score is moderate
- The union of both criteria catches more true outliers with fewer misses
