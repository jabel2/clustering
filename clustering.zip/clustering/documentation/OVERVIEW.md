# Outlier Detector — System Overview

## What This Tool Does

The Outlier Detector takes any tabular dataset (CSV or JSON), uses a clustering algorithm to find records that don't fit the normal patterns, and then uses a local AI model to explain in plain English *why* those records are unusual.

**Typical use cases:**
- Finding anomalous accounts in an Active Directory group
- Detecting unusual employees in HR or payroll data
- Flagging misconfigured or misplaced records in any organizational dataset

---

## The Three Commands

| Command | What it does | Needs AI? |
|---------|-------------|-----------|
| `analyze` | Clusters the data and shows which records are outliers | No |
| `explain` | Same as analyze, then asks the AI to explain each outlier | Yes (Azure OpenAI) |
| `recommend` | Shows the AI your dataset and asks what settings to use | Yes (Azure OpenAI) |

**Quick start:**
```bash
# Step 1 — let the AI recommend settings for your data
python app.py recommend my_data.csv --context "HR employee records"

# Step 2 — run the full analysis with those settings
python app.py explain my_data.csv \
  --id-column employee_id \
  --auto-cluster-size \
  --context "HR employee records"
```

---

## How It Works — The Pipeline

Every analysis follows the same four stages. The `analyze` command runs stages 1–3. The `explain` command runs all four.

```
┌─────────────────────────────────────────────────────────────────┐
│  Stage 1: Prepare the Data                  (pipeline.py)        │
│                                                                   │
│  Raw file  ──►  load  ──►  clean  ──►  feature matrix            │
│  (CSV/JSON)    missing    one-hot &    (numbers only —            │
│                values     scaling      ready for math)            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 2: Cluster and Find Outliers         (detect.py)          │
│                                                                   │
│  Feature matrix  ──►  HDBSCAN  ──►  outlier scores  ──►  ranked  │
│                       clusters      (GLOSH 0–1)          list    │
│                                                                   │
│  Also profiles each cluster so you can read the results.         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 3: Display Results                   (app.py)             │
│                                                                   │
│  ─ Terminal tables (always)                                       │
│  ─ JSON file  (analyze --output, or explain --output-format json) │
└─────────────────────────────────────────────────────────────────┘
                              │
                (explain command only)
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 4: LLM Explanation                   (explain.py)         │
│                                                                   │
│  Outlier data  ──►  build prompt  ──►  Azure  ──►  explanation  │
│  + deviations       (structured)      OpenAI      + JSON block  │
│                                                                   │
│  Output formats: terminal panel, .json, .md, annotated .csv      │
└─────────────────────────────────────────────────────────────────┘
```

---

## File Structure

```
clustering/
├── app.py          ← Start here. CLI commands (analyze / explain / recommend)
├── pipeline.py     ← Stage 1: Load, clean, build features
├── detect.py       ← Stage 2: Cluster, score outliers, profile clusters
├── explain.py      ← Stage 4: Build LLM prompt, call Azure OpenAI, parse response
├── recommend.py    ← Standalone: Profile dataset, ask LLM for settings
├── llm.py          ← LLM settings: endpoint, API key, deployment (edit here)
├── requirements.txt
└── test/
    └── generate_test_data.py  ← Generate synthetic test data
```

Each file has exactly one job. You can read and understand any one of them independently.

---

## The Core Algorithm: HDBSCAN + GLOSH

**Why not K-means or a simple threshold?**

K-means requires you to specify how many clusters exist. Thresholds require you to know what "normal" looks like in advance. HDBSCAN requires neither — it discovers clusters automatically from the density of the data.

**How HDBSCAN works (simplified):**

1. Look at every point and measure how densely surrounded it is by neighbors.
2. Points in dense neighborhoods form clusters. Points in sparse neighborhoods become "noise."
3. Build a hierarchy of how clusters merge as you relax the density requirement.

**The GLOSH score:**

After clustering, every point gets a GLOSH (Global-Local Outlier Score from Hierarchies) score between 0 and 1:
- **Score near 0** — point comfortably belongs to a dense cluster
- **Score near 1** — point is in a very sparse region, unlike anything else

The tool flags a record as an outlier if its GLOSH score ≥ the threshold (default 0.8) **or** if HDBSCAN labeled it as noise (label = -1).

---

## Feature Engineering: Making Data Math-Ready

Clustering algorithms work on numbers. Most real datasets have text columns (like "department: Finance"). The tool converts everything:

| Column type | How it's converted | Example |
|------------|-------------------|---------|
| Categorical (text) | One-hot encoding | `department=Finance` → `department_Finance=1, department_HR=0, ...` |
| Numerical | RobustScaler (IQR-based) | `tenure_days=1825` → `0.34` |
| Boolean-like | Mapped to 0/1 | `is_admin=True` → `1` |

**Why RobustScaler instead of StandardScaler?**
StandardScaler uses mean and standard deviation, which are pulled toward extreme values. RobustScaler uses the median and interquartile range — outliers don't distort the scaling of normal data, which matters a lot when the whole point is to find outliers.

---

## Auto-Tuning: Choosing `min_cluster_size`

The single most important HDBSCAN parameter is `min_cluster_size` — the minimum number of points that can form a real cluster. The `--auto-cluster-size` flag searches for the best value automatically using one of three strategies:

| Method | Strategy | Best for |
|--------|---------|---------|
| `dbcv` (default) | Score cluster quality with DBCV validity metric; penalize solutions with no outliers or one dominant cluster | Most datasets |
| `balanced` | Find the size that gives a 5–15% outlier rate | When you know roughly what fraction of records are anomalous |
| `heuristic` | Use `log2(n_samples)` — fast, no search | Large datasets where speed matters |

---

## Output Formats (explain command)

| Format | What you get |
|--------|-------------|
| `terminal` | Formatted panel with the LLM's narrative explanation |
| `json` | Machine-readable: summary, outlier list, full explanation text |
| `markdown` | Human-readable report: cluster profiles + LLM explanation |
| `csv` | Original data with 6 new columns: `_is_outlier`, `_outlier_score`, `_why_outlier`, `_unusual_attributes`, `_risk_level`, `_recommended_action` |

Default is all four: `--output-format "json,terminal,markdown,csv"`

---

## Requirements

### Python packages
```
typer            — CLI argument parsing
pandas           — data loading and manipulation
numpy            — numerical arrays
scikit-learn     — RobustScaler and OneHotEncoder
hdbscan          — HDBSCAN clustering
langchain-openai — AzureChatOpenAI client
rich             — terminal formatting (tables, colors)
```

### Azure OpenAI (for explain and recommend)

Edit `llm.py` with your credentials, or set these environment variables:

```bash
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_API_KEY="your-api-key"
export OPENAI_API_VERSION="2024-02-01"   # optional, this is the default
export AZURE_DEPLOYMENT="gpt-4o"         # optional, this is the default
```

---

## Key Concepts Summary

| Term | Plain meaning |
|------|--------------|
| Cluster | A group of records that are similar to each other |
| Noise point | A record HDBSCAN couldn't fit into any cluster |
| GLOSH score | How anomalous a record is (0 = normal, 1 = very anomalous) |
| Outlier threshold | The GLOSH score above which we call something an outlier (default: 0.8) |
| min_cluster_size | How small a group can be and still count as a real cluster |
| One-hot encoding | Converting a text category into a set of 0/1 columns |
| RobustScaler | Normalizing numbers so they're comparable, without being distorted by outliers |
| Deviation | How different an outlier's value is from the majority cluster's typical value |

---

## Detailed File Documentation

- [app.py](app.md) — CLI commands and output formatting
- [pipeline.py](pipeline.md) — Data loading, cleaning, feature engineering
- [detect.py](detect.md) — HDBSCAN clustering, outlier scoring, cluster profiling
- [explain.py](explain.md) — LLM prompt building and Azure OpenAI integration
- [recommend.py](recommend.md) — Dataset profiling and LLM settings recommendations
- [llm.py](llm.md) — Azure OpenAI settings (edit here to change credentials or deployment)
