# recommend.py — Dataset Profiling and LLM Settings Recommendations

## What This File Does

`recommend.py` solves the "how do I configure this tool for my data?" problem. It examines your dataset's structure, presents a profile to an LLM, and gets back concrete recommended settings — including a ready-to-run CLI command.

This is the right starting point when working with a new dataset for the first time.

```
Raw DataFrame
    │
    ▼ DatasetAnalyzer.analyze()
DatasetProfile: types, stats, samples, ID candidates
    │
    ▼ SettingsRecommender.recommend()
LLM call: "here's the dataset profile, what settings should I use?"
    │
    ▼ _parse_settings()
RecommendationResult: structured settings + suggested CLI command
```

---

## Classes and Methods

### `DatasetAnalyzer`

Examines a DataFrame and produces a `DatasetProfile` describing its structure.

```python
analyzer = DatasetAnalyzer()
profile = analyzer.analyze(df)
```

For each column, `DatasetAnalyzer` determines:
- The semantic **type** (boolean, numerical, categorical, or text)
- **Cardinality** (how many unique values)
- **Null rate**
- **Sample values** (first 5 non-null)
- **Distribution stats** (for numerical: min/max/mean/median/std)
- **Top values with percentages** (for categorical: top 5)

It also identifies **ID column candidates** — columns likely to be unique identifiers that should be excluded from clustering.

**Type inference logic:**

| Condition | Inferred type |
|-----------|--------------|
| All unique values are in `{0, 1, True, False, "0", "1", "true", "false"}` | `boolean` |
| `pandas` reports it as numeric | `numerical` |
| Unique count > 50% of rows AND average string length > 50 chars | `text` (free-form, not useful for clustering) |
| Everything else | `categorical` |

**ID column detection criteria** (either condition qualifies):
- More than 90% unique values (high uniqueness = likely an identifier)
- Column name contains `id`, `key`, `uuid`, `guid`, `identifier`, or `code`, AND more than 50% unique values

**`DatasetAnalyzer.to_prompt_text(profile)`** (static method)

Converts a `DatasetProfile` into readable text for the LLM prompt.

```
Dataset: 1000 rows, 9 columns

## Columns
- **employee_id** (categorical) - 1000 unique values
  Examples: 'EMP001', 'EMP002', 'EMP003'
- **department** (categorical) - 6 unique values
  Top values: 'Finance': 34.2%, 'IT': 28.1%, 'HR': 18.4%
- **tenure_days** (numerical) - 847 unique values
  Range: [30.00, 12500.00], Mean: 1245.30, Std: 892.40

Likely ID columns: employee_id
```

---

### `SettingsRecommender`

Sends the dataset profile to Azure OpenAI and gets back recommended settings. Connection settings come from [llm.py](llm.md) — no credentials are passed here.

```python
recommender = SettingsRecommender()
result = recommender.recommend(
    profile=profile,
    domain_context="Active Directory group for Finance team VPN access",
    file_path="finance_ad_group.csv",
)
```

**Constructor parameters:**

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `temperature` | `0.1` | Low temperature for consistent, practical recommendations |

The Azure endpoint, API key, deployment name, and API version are all read from `llm.py`. To change which model or endpoint is used, edit `llm.py` (or set the corresponding environment variables).

**The LLM is asked to recommend:**

| Setting | What it's for |
|---------|--------------|
| `id_column` | Which column uniquely identifies rows (exclude from clustering) |
| `categorical_columns` | Which columns should be one-hot encoded |
| `numerical_columns` | Which columns should be numerically scaled |
| `exclude_columns` | Which columns to ignore entirely (names, timestamps, free text) |
| `expected_outlier_pct` | What fraction of records you'd expect to be anomalous |
| `auto_method` | Which auto-tuning strategy to use (`heuristic`, `balanced`, or `dbcv`) |
| `column_weights` | Which columns are most important for detecting anomalies |
| `outlier_signals` | Domain-specific patterns that would indicate an anomaly |
| `reasoning` | The LLM's explanation of its choices |

**`.check_connection()`** — returns `True` if Azure credentials (`ENDPOINT` and `API_KEY`) are configured in `llm.py`.

---

## Data Classes

### `ColumnInfo`
Information about one column in the dataset.

| Field | Type | Description |
|-------|------|-------------|
| `name` | `str` | Column name |
| `dtype` | `str` | `"boolean"`, `"numerical"`, `"categorical"`, or `"text"` |
| `unique_count` | `int` | Number of distinct values |
| `null_count` | `int` | Number of missing values |
| `null_pct` | `float` | Percentage missing |
| `sample_values` | `list[str]` | First 5 non-null values |
| `min_val` / `max_val` / `mean_val` / `median_val` / `std_val` | `float` or `None` | Numerical stats (numerical columns only) |
| `top_values` | `dict[str, float]` | Top values and their percentages (categorical only) |

### `DatasetProfile`
Complete structural description of a dataset.

| Field | Type | Description |
|-------|------|-------------|
| `n_rows` | `int` | Total record count |
| `n_columns` | `int` | Total column count |
| `columns` | `list[ColumnInfo]` | Per-column info |
| `sample_rows` | `list[dict]` | First 3 rows as string dicts |
| `id_column_candidates` | `list[str]` | Column names likely to be IDs |

### `RecommendedSettings`
The structured settings recommended by the LLM.

| Field | Default | Description |
|-------|---------|-------------|
| `id_column` | `None` | Recommended ID column |
| `categorical_columns` | `[]` | Columns to one-hot encode |
| `numerical_columns` | `[]` | Columns to scale |
| `exclude_columns` | `[]` | Columns to skip entirely |
| `expected_outlier_pct` | `None` | Expected % of anomalies (1–5% typical) |
| `auto_method` | `"heuristic"` | Auto-tuning strategy |
| `min_cluster_size` | `None` | Explicit size (if LLM recommends skipping auto-tune) |
| `column_weights` | `{}` | Weight multipliers for important columns |
| `outlier_signals` | `[]` | Domain-specific anomaly indicators |
| `reasoning` | `""` | LLM's explanation of recommendations |

### `RecommendationResult`
Full output from a recommendation call.

| Field | Type | Description |
|-------|------|-------------|
| `settings` | `RecommendedSettings` | Parsed recommended settings |
| `raw_response` | `str` | Complete LLM response text |
| `model` | `str` | Model that generated the response |
| `cli_command` | `str` | Ready-to-run `python app.py analyze ...` command |

---

## The JSON Parsing

The LLM is instructed to include a ` ```json {...} ``` ` block in its response. The parser:

1. Tries ` ```json ... ``` ` first
2. Falls back to ` ``` {...} ``` ` (generic code block with object)
3. If both fail, returns default `RecommendedSettings` with `reasoning = "Could not parse structured response"` and uses the first ID candidate from the profile as `id_column`

---

## Windows Text Sanitization

The `_sanitize_text()` method replaces Unicode characters that cause `UnicodeEncodeError` on Windows consoles (which default to cp1252 encoding). This affects LLM-generated text that may contain curly quotes, em dashes, or other typographic characters.

Characters replaced:

| Character | Replacement |
|-----------|-------------|
| Non-breaking hyphen `‑` | `-` |
| En dash `–` | `-` |
| Em dash `—` | `--` |
| Left/right single quotes `'` `'` | `'` |
| Left/right double quotes `"` `"` | `"` |
| Ellipsis `…` | `...` |
| Non-breaking spaces | regular space |
| Zero-width space | (removed) |

Any remaining non-cp1252 character is replaced with `?`.

---

## Example: Recommended Output

For an Active Directory dataset, the LLM might return:

```json
{
  "id_column": "user_id",
  "categorical_columns": ["department", "job_title", "location", "account_type"],
  "numerical_columns": ["tenure_days", "access_level", "manager_level"],
  "exclude_columns": ["display_name", "email"],
  "expected_outlier_pct": 2.5,
  "auto_method": "heuristic",
  "column_weights": {"account_type": 2.0, "access_level": 1.5},
  "outlier_signals": [
    "Service accounts in human user groups",
    "Very high access level for a non-manager role",
    "Account created recently but with long tenure_days",
    "Admin-level access without matching job title"
  ],
  "reasoning": "This AD group has consistent department patterns. Accounts with unusual job titles relative to the group norm or atypical access levels are the most likely anomalies."
}
```

Which becomes the CLI command:
```bash
python app.py analyze my_data.csv \
  --id-column user_id \
  --categorical "department,job_title,location,account_type" \
  --numerical "tenure_days,access_level,manager_level" \
  --auto-cluster-size \
  --auto-method heuristic
```

---

## Workflow: Using recommend Before explain

The `recommend` command is designed to be your starting point with a new dataset:

```bash
# 1. Get recommendations
python app.py recommend my_data.csv --context "Finance team AD group"

# 2. Review the suggested command, adjust if needed, then run:
python app.py explain my_data.csv \
  --id-column user_id \
  --categorical "department,job_title,location" \
  --numerical "tenure_days,access_level" \
  --auto-cluster-size \
  --context "Finance team AD group"
```
