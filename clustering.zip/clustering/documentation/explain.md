# explain.py — LLM Prompt Building and Azure OpenAI Integration

## What This File Does

`explain.py` handles everything related to the AI explanation step. It takes the clustering results and outlier deviations produced by `detect.py`, assembles them into a structured prompt, sends that prompt to Azure OpenAI via LangChain, and parses the response.

```
Clustering results + deviations
    │
    ▼ ContextBuilder.build()
ExplanationContext: structured prompt text + metadata
    │
    ▼ ExplanationAgent.explain()
Raw LLM response (free text + JSON block)
    │
    ▼ ExplanationAgent._parse_json_block()
ExplanationResult: full text explanation + list of OutlierAnalysis objects
```

---

## Classes and Methods

### `ContextBuilder`

Assembles everything the LLM needs to know into a single structured prompt.

```python
builder = ContextBuilder(
    dataset_description="AD group: Finance-Admins",
    id_column="user_id",
    max_outliers=25,  # don't send more than this to avoid token overflow
)
context = builder.build(
    original_df=cleaned_df,
    profile_result=profile_result,
    outlier_df=outlier_df,
    deviation_df=deviation_df,
    ids=outlier_info.ids,
)
```

**Constructor parameters:**

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `dataset_description` | `""` | What the dataset is about — included at the top of the prompt so the LLM understands the domain |
| `id_column` | `None` | Name of the ID column, used for referencing outliers in the output |
| `max_outliers` | `25` | Cap on how many outliers to include in the prompt. Sorted by score so the most anomalous are always included. |

**`.build()` returns an `ExplanationContext` with:**

| Field | What it contains |
|-------|-----------------|
| `dataset_context` | Total record count, cluster count, dataset description |
| `cluster_summary` | For each cluster: column distributions or stat ranges |
| `outliers` | List of `OutlierContext` objects (one per outlier) |
| `prompt` | The complete text sent to the LLM |

---

### The Prompt Structure

The prompt sent to the LLM has four sections:

```
## Dataset Context
Dataset: AD group: Finance-Admins
Total records: 500
Clusters found: 3

## Cluster Profiles
**Cluster 0 (423 records, 84.6%)**
  - department: Finance: 91%, HR: 5%, IT: 4%
  - tenure_days: median=1095, range=[180, 4200]

**Cluster 1 (54 records, 10.8%)**
  - department: IT: 78%, Finance: 22%
  - tenure_days: median=720, range=[90, 2100]

## Outliers to Explain
### EMP_4821 (outlier score: 0.94)
Attributes:
  - department: Marketing
  - job_title: Cloud Architect
  - tenure_days: 12500
  - access_level: 5
Key deviations from the majority:
  - department: has 'Marketing' (majority has 'Finance', only 1.2% share this value)
  - tenure_days: value 12500 (majority median: 1095, z-score: 8.3)

## Your Task
For each outlier, provide:
1. A clear explanation of why this record doesn't fit the majority...
[instructions for JSON output block]
```

The LLM is instructed to provide both:
1. Free-text narrative for human readers
2. A structured ````json [...]` ` ` block for machine parsing

---

### `ExplanationAgent`

Manages the Azure OpenAI connection and sends the prompt. Connection settings come from [llm.py](llm.md) — no credentials are passed here.

```python
agent = ExplanationAgent(
    temperature=0.1,
    max_tokens=4000,
)
```

**Constructor parameters:**

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `temperature` | `0.1` | Sampling randomness. Very low = more focused and deterministic. |
| `max_tokens` | `4000` | Maximum response length. Increase if explanations get cut off. |

The Azure endpoint, API key, deployment name, and API version are all read from `llm.py`. To change which model or endpoint is used, edit `llm.py` (or set the corresponding environment variables).

**`.explain(context)`**

Sends the prompt to Azure OpenAI as a chat message with a system prompt that frames the LLM as a data analyst. Returns an `ExplanationResult`.

The system prompt is:
> "You are a data analyst specializing in anomaly detection. Explain why certain records are outliers in clear, actionable terms. Be concise and focus on the most significant findings."

**`.check_connection()`**

Returns `True` if the Azure credentials in `llm.py` appear to be configured (i.e., both `ENDPOINT` and `API_KEY` are non-empty). Call this before `.explain()` to give the user a clear error message rather than an exception.

```python
if not agent.check_connection():
    print("Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY in llm.py or as environment variables.")
```

---

## Data Classes

### `OutlierContext`
Data about one outlier, ready to be formatted into the prompt.

| Field | Type | Description |
|-------|------|-------------|
| `identifier` | `str` | The ID value, or `"Record N"` if no ID column |
| `outlier_score` | `float` | GLOSH score (0–1) |
| `values` | `dict[str, str]` | All column values for this record |
| `deviations` | `dict[str, dict]` | Pre-computed deviations from the majority cluster |

### `ExplanationContext`
Everything needed for an LLM call.

| Field | Type | Description |
|-------|------|-------------|
| `dataset_context` | `str` | Dataset description and cluster count |
| `cluster_summary` | `str` | Per-cluster column distributions |
| `outliers` | `list[OutlierContext]` | Individual outlier data |
| `prompt` | `str` | The complete assembled prompt |

### `OutlierAnalysis`
Structured result for one outlier, parsed from the LLM's JSON block.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | The outlier identifier |
| `why_outlier` | `str` | LLM's brief explanation |
| `unusual_attributes` | `str` | Comma-separated list of unusual attributes |
| `risk_level` | `str` | `"Low"`, `"Medium"`, or `"High"` |
| `recommended_action` | `str` | `"Review"`, `"Flag for removal"`, or `"Likely legitimate"` |

### `ExplanationResult`
Full output from the LLM call.

| Field | Type | Description |
|-------|------|-------------|
| `explanation` | `str` | The complete LLM response text |
| `model` | `str` | Deployment name that produced this (from `llm.py`) |
| `prompt_tokens` | `int` or `None` | Tokens used for the prompt |
| `completion_tokens` | `int` or `None` | Tokens in the response |
| `structured_analysis` | `list[OutlierAnalysis]` | Parsed JSON block, empty if parsing fails |

---

## JSON Parsing: How the Structured Block is Extracted

The LLM is instructed to end its response with a JSON block. The parser uses a two-pass regex:

1. Look for ` ```json ... ``` ` (preferred — explicit JSON marker)
2. Fall back to ` ``` [...] ``` ` (any code block containing an array)

If both fail, `structured_analysis` is returned as an empty list. The free-text `explanation` is always available regardless of whether JSON parsing succeeds.

This "structured analysis" is what populates the `_why_outlier`, `_risk_level`, and `_recommended_action` columns in the annotated CSV output.

---

## Error Handling

| Situation | What happens |
|-----------|-------------|
| Credentials not set | `check_connection()` returns `False`; caller shows configuration instructions |
| LLM returns empty response | `explanation` is set to a message explaining the likely cause (prompt too long) |
| JSON block missing or malformed | `structured_analysis` is `[]`; free-text explanation is still usable |
| Connection or auth error | `ConnectionError` is raised with a user-friendly message |

---

## Tips for Better Explanations

**Use `--context`** — the more context the LLM has, the better:
```bash
python app.py explain data.csv --context "Active Directory group for Finance department VPN access"
```

**Reduce `--max-outliers-llm` if responses are truncated** — each outlier adds ~300–500 tokens to the prompt:
```bash
python app.py explain data.csv --max-outliers-llm 10
```

**To change the model or endpoint**, edit `llm.py`:
```python
DEPLOYMENT = "my-gpt4o-deployment"
ENDPOINT   = "https://my-resource.openai.azure.com/"
```
