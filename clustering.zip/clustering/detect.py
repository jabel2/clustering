"""Detect: HDBSCAN clustering → score outliers → profile clusters."""

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
import hdbscan


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------

@dataclass
class ClusterResult:
    """Output of fitting HDBSCAN to a feature matrix."""
    labels: np.ndarray        # Cluster label per row (-1 = noise/outlier)
    probabilities: np.ndarray # Cluster membership probability
    outlier_scores: np.ndarray # GLOSH score per row (0 = inlier, 1 = outlier)
    n_clusters: int
    n_noise: int


class HDBSCANClusterer:
    """Thin wrapper around hdbscan.HDBSCAN that returns a ClusterResult."""

    def __init__(
        self,
        min_cluster_size: int = 5,
        min_samples: int | None = None,
        metric: str = "euclidean",
        cluster_selection_method: str = "eom",
    ):
        self.min_cluster_size = min_cluster_size
        self.min_samples = min_samples
        self.metric = metric
        self.cluster_selection_method = cluster_selection_method

    def fit(self, features: np.ndarray) -> ClusterResult:
        """Fit HDBSCAN and return a ClusterResult."""
        model = hdbscan.HDBSCAN(
            min_cluster_size=self.min_cluster_size,
            min_samples=self.min_samples,
            metric=self.metric,
            cluster_selection_method=self.cluster_selection_method,
            gen_min_span_tree=True,
        )
        model.fit(features)

        labels = model.labels_
        unique = set(labels)
        return ClusterResult(
            labels=labels,
            probabilities=model.probabilities_,
            outlier_scores=model.outlier_scores_,
            n_clusters=len(unique) - (1 if -1 in unique else 0),
            n_noise=int((labels == -1).sum()),
        )

    @staticmethod
    def auto_min_cluster_size(
        features: np.ndarray,
        min_value: int = 3,
        max_value: int | None = None,
        method: str = "dbcv",
    ) -> tuple[int, dict]:
        """Search for the best min_cluster_size using one of three strategies.

        Methods:
          'dbcv'      — maximize DBCV validity score (penalizes degenerate solutions)
          'balanced'  — find size that gives 5–15% outlier rate
          'heuristic' — log2(n_samples), fast, no grid search
        """
        n = len(features)

        if method == "heuristic":
            optimal = max(min_value, int(np.log2(n)))
            return optimal, {"method": "heuristic", "formula": "log2(n_samples)"}

        if max_value is None:
            max_value = max(min_value + 1, min(50, int(np.sqrt(n))))

        candidates = list(range(min_value, max_value + 1))

        if method == "dbcv":
            best_score, best_size, scores = -np.inf, min_value, {}
            for size in candidates:
                try:
                    m = hdbscan.HDBSCAN(min_cluster_size=size, gen_min_span_tree=True)
                    m.fit(features)

                    labels = m.labels_
                    raw_dbcv = m.relative_validity_
                    noise_pct = (labels == -1).sum() / n * 100
                    unique_labels = [l for l in set(labels) if l != -1]
                    n_clusters = len(unique_labels)
                    cluster_sizes = [(labels == l).sum() for l in unique_labels]

                    # "Effective outlier %" = noise + borderline tiny clusters
                    tiny_count = sum(s for s in cluster_sizes if s < size * 2)
                    eff_outlier_pct = ((labels == -1).sum() + tiny_count) / n * 100
                    max_cluster_pct = max(cluster_sizes) / n * 100 if cluster_sizes else 0

                    adj = raw_dbcv
                    if eff_outlier_pct < 1.0:          # penalty: almost no outliers
                        adj *= 1 - 0.5 * (1 - eff_outlier_pct / 1.0)
                    if max_cluster_pct > 95.0:          # penalty: one cluster absorbs everything
                        adj *= 1 - 0.3 * ((max_cluster_pct - 95.0) / 5.0)
                    if n_clusters < 2:                  # penalty: only one cluster
                        adj *= 0.5

                    scores[size] = {
                        "dbcv": float(raw_dbcv),
                        "adjusted_score": float(adj),
                        "n_clusters": n_clusters,
                        "noise_pct": float(noise_pct),
                        "effective_outlier_pct": float(eff_outlier_pct),
                        "max_cluster_pct": float(max_cluster_pct),
                    }
                    if adj > best_score:
                        best_score, best_size = adj, size
                except Exception:
                    continue
            return best_size, {"method": "dbcv", "scores": scores, "best_score": best_score}

        elif method == "balanced":
            best_size, best_diff, results = min_value, float("inf"), {}
            for size in candidates:
                try:
                    m = hdbscan.HDBSCAN(min_cluster_size=size)
                    m.fit(features)
                    noise_rate = (m.labels_ == -1).sum() / n
                    n_clusters = len(set(m.labels_)) - (1 if -1 in m.labels_ else 0)
                    results[size] = {"noise_pct": float(noise_rate * 100), "n_clusters": n_clusters}

                    target_mid = 0.10  # midpoint of 5–15%
                    if 0.05 <= noise_rate <= 0.15:
                        diff = abs(noise_rate - target_mid)
                    else:
                        diff = min(abs(noise_rate - 0.05), abs(noise_rate - 0.15))

                    if diff < best_diff and n_clusters >= 2:
                        best_diff, best_size = diff, size
                except Exception:
                    continue
            return best_size, {"method": "balanced", "target_range": "5-15%", "results": results}

        else:
            raise ValueError(f"Unknown method: {method}. Use 'dbcv', 'balanced', or 'heuristic'.")


# ---------------------------------------------------------------------------
# Outlier scoring
# ---------------------------------------------------------------------------

@dataclass
class OutlierInfo:
    """Which rows are outliers and how anomalous they are."""
    indices: np.ndarray       # Row indices of outliers (sorted by score desc)
    scores: np.ndarray        # GLOSH outlier score for each outlier
    ids: pd.Series | None     # ID values for outliers (if an ID column was given)
    total_count: int
    outlier_count: int
    outlier_percentage: float


class OutlierScorer:
    """Combine GLOSH scores and noise labels to identify outlier rows."""

    def __init__(self, outlier_threshold: float = 0.8, use_cluster_labels: bool = True):
        self.outlier_threshold = outlier_threshold
        self.use_cluster_labels = use_cluster_labels

    def score(self, cluster_result: ClusterResult, ids: pd.Series | None = None) -> OutlierInfo:
        """Return OutlierInfo for all outlier rows, sorted by score descending."""
        is_outlier = cluster_result.outlier_scores >= self.outlier_threshold
        if self.use_cluster_labels:
            is_outlier |= cluster_result.labels == -1

        indices = np.where(is_outlier)[0]
        scores = cluster_result.outlier_scores[indices]

        # Sort highest score first
        order = np.argsort(-scores)
        indices, scores = indices[order], scores[order]

        outlier_ids = ids.iloc[indices].reset_index(drop=True) if ids is not None else None
        total = len(cluster_result.labels)
        count = len(indices)

        return OutlierInfo(
            indices=indices,
            scores=scores,
            ids=outlier_ids,
            total_count=total,
            outlier_count=count,
            outlier_percentage=100 * count / total if total > 0 else 0,
        )

    def get_outlier_data(self, df: pd.DataFrame, outlier_info: OutlierInfo) -> pd.DataFrame:
        """Return a DataFrame of the outlier rows with their scores appended."""
        result = df.iloc[outlier_info.indices].copy()
        result["_outlier_score"] = outlier_info.scores
        return result.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Cluster profiling
# ---------------------------------------------------------------------------

@dataclass
class ColumnProfile:
    """Summary of one column within one cluster."""
    name: str
    dtype: str                 # "categorical" or "numerical"
    mode: Any                  # Most common value (categorical) or median (numerical)
    mode_percentage: float
    distribution: dict[str, float]


@dataclass
class ClusterProfile:
    """Summary of one cluster."""
    label: int
    size: int
    percentage: float
    columns: list[ColumnProfile]


@dataclass
class ProfileResult:
    """Summary of all clusters."""
    clusters: list[ClusterProfile]
    overall_size: int
    n_clusters: int


class ClusterProfiler:
    """Describe each cluster in human-readable terms using the original (pre-encoded) column values."""

    def __init__(
        self,
        categorical_columns: list[str],
        numerical_columns: list[str],
        top_n_categories: int = 5,
    ):
        self.categorical_columns = categorical_columns
        self.numerical_columns = numerical_columns
        self.top_n_categories = top_n_categories

    def profile(self, df: pd.DataFrame, cluster_result: ClusterResult) -> ProfileResult:
        """Build a ProfileResult describing every cluster."""
        clusters = []
        for label in sorted(set(cluster_result.labels)):
            mask = cluster_result.labels == label
            sub = df.iloc[mask]
            col_profiles = []

            for col in self.categorical_columns:
                if col in df.columns:
                    col_profiles.append(self._profile_categorical(sub[col], col))
            for col in self.numerical_columns:
                if col in df.columns:
                    col_profiles.append(self._profile_numerical(sub[col], col))

            clusters.append(ClusterProfile(
                label=label,
                size=len(sub),
                percentage=100 * len(sub) / len(df),
                columns=col_profiles,
            ))

        return ProfileResult(clusters=clusters, overall_size=len(df), n_clusters=cluster_result.n_clusters)

    def _profile_categorical(self, series: pd.Series, name: str) -> ColumnProfile:
        vc = series.value_counts(normalize=True)
        mode = vc.index[0] if len(vc) > 0 else None
        mode_pct = vc.iloc[0] * 100 if len(vc) > 0 else 0
        distribution = {str(k): round(v * 100, 1) for k, v in vc.head(self.top_n_categories).items()}
        return ColumnProfile(name=name, dtype="categorical", mode=mode, mode_percentage=round(mode_pct, 1), distribution=distribution)

    def _profile_numerical(self, series: pd.Series, name: str) -> ColumnProfile:
        distribution = {
            "mean": round(series.mean(), 2),
            "median": round(series.median(), 2),
            "std": round(series.std(), 2),
            "min": round(series.min(), 2),
            "max": round(series.max(), 2),
        }
        return ColumnProfile(name=name, dtype="numerical", mode=round(series.median(), 2), mode_percentage=0, distribution=distribution)

    def compute_deviation_scores(
        self,
        df: pd.DataFrame,
        outlier_indices: np.ndarray,
        cluster_result: ClusterResult,
    ) -> pd.DataFrame:
        """For each outlier, describe how it deviates from the majority cluster.

        Returns a DataFrame with columns: 'index', 'deviations'.
        Categorical deviations include the majority mode and how rare the outlier's value is.
        Numerical deviations include a z-score (only shown when > 2).
        """
        labels = cluster_result.labels
        valid = labels[labels != -1]
        if len(valid) == 0:
            majority_mask = np.ones(len(df), dtype=bool)
        else:
            majority_label = pd.Series(valid).mode().iloc[0]
            majority_mask = labels == majority_label

        majority = df.iloc[majority_mask]
        deviations = []

        for idx in outlier_indices:
            row = df.iloc[idx]
            row_dev = {}

            for col in self.categorical_columns:
                if col not in df.columns:
                    continue
                maj_mode = majority[col].mode()
                if len(maj_mode) == 0:
                    continue
                maj_mode = maj_mode.iloc[0]
                val = row[col]
                if val != maj_mode:
                    freq = (majority[col] == val).mean()
                    row_dev[col] = {
                        "outlier_value": val,
                        "majority_value": maj_mode,
                        "frequency_in_majority": round(freq * 100, 1),
                    }

            for col in self.numerical_columns:
                if col not in df.columns:
                    continue
                maj_median = majority[col].median()
                maj_std = majority[col].std()
                val = row[col]
                if maj_std > 0:
                    z = abs(val - maj_median) / maj_std
                    if z > 2:
                        row_dev[col] = {
                            "outlier_value": round(val, 2),
                            "majority_median": round(maj_median, 2),
                            "z_score": round(z, 2),
                        }

            deviations.append(row_dev)

        return pd.DataFrame({"index": outlier_indices, "deviations": deviations})
