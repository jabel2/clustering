"""LLM settings — the single place to configure Azure OpenAI for the whole app.

Edit the constants below, or set the corresponding environment variables.
Every module that needs a language model imports get_llm() from here.
"""

import os

from langchain_openai import AzureChatOpenAI

# ── Connection settings (edit here OR set as environment variables) ───────────
DEPLOYMENT  = os.environ.get("AZURE_DEPLOYMENT",      "gpt-4o")
ENDPOINT    = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
API_KEY     = os.environ.get("AZURE_OPENAI_API_KEY",  "")
API_VERSION = os.environ.get("OPENAI_API_VERSION",    "2024-02-01")
# ─────────────────────────────────────────────────────────────────────────────


def get_llm(temperature: float = 0.1, max_tokens: int = 4000) -> AzureChatOpenAI:
    """Return an AzureChatOpenAI instance using the settings above."""
    return AzureChatOpenAI(
        azure_deployment=DEPLOYMENT,
        azure_endpoint=ENDPOINT,
        api_key=API_KEY,
        api_version=API_VERSION,
        temperature=temperature,
        max_tokens=max_tokens,
    )


def check_connection() -> bool:
    """Return True if Azure credentials appear to be configured."""
    return bool(ENDPOINT and API_KEY)
