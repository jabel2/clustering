"""Explain: build LLM prompt → call Azure OpenAI via LangChain → parse structured JSON response."""

import json
import re
from dataclasses import dataclass, field

import pandas as pd
from langchain_core.messages import HumanMessage, SystemMessage

from detect import ProfileResult
from llm import get_llm, DEPLOYMENT, check_connection as _llm_ok


# ---------------------------------------------------------------------------
# Context building
# ---------------------------------------------------------------------------

@dataclass
class OutlierContext:
    """Data for a single outlier that will be sent to the LLM."""
    identifier: str
    outlier_score: float
    values: dict[str, str]
    deviations: dict[str, dict]


@dataclass
class ExplanationContext:
    """Everything the LLM needs: a prebuilt prompt plus structured data."""
    dataset_context: str
    cluster_summary: str
    outliers: list[OutlierContext]
    prompt: str


class ContextBuilder:
    """Assembles the LLM prompt from clustering results and outlier deviations."""

    def __init__(
        self,
        dataset_description: str = "",
        id_column: str | None = None,
        max_outliers: int = 25,
    ):
        self.dataset_description = dataset_description
        self.id_column = id_column
        self.max_outliers = max_outliers

    def build(
        self,
        original_df: pd.DataFrame,
        profile_result: ProfileResult,
        outlier_df: pd.DataFrame,
        deviation_df: pd.DataFrame,
        ids: pd.Series | None = None,
    ) -> ExplanationContext:
        dataset_context = self._dataset_context(original_df, profile_result)
        cluster_summary = self._cluster_summary(profile_result)
        outliers = self._outlier_contexts(outlier_df, deviation_df, ids)
        prompt = self._build_prompt(dataset_context, cluster_summary, outliers)
        return ExplanationContext(
            dataset_context=dataset_context,
            cluster_summary=cluster_summary,
            outliers=outliers,
            prompt=prompt,
        )

    def _dataset_context(self, df: pd.DataFrame, profile_result: ProfileResult) -> str:
        lines = []
        if self.dataset_description:
            lines.append(f"Dataset: {self.dataset_description}")
        lines.append(f"Total records: {len(df)}")
        lines.append(f"Clusters found: {profile_result.n_clusters}")
        return "\n".join(lines)

    def _cluster_summary(self, profile_result: ProfileResult) -> str:
        lines = []
        for cluster in profile_result.clusters:
            label = "Noise/Outliers" if cluster.label == -1 else f"Cluster {cluster.label}"
            lines.append(f"\n**{label} ({cluster.size} records, {cluster.percentage:.1f}%)**")
            for col in cluster.columns:
                if col.dtype == "categorical":
                    dist = ", ".join(f"{k}: {v}%" for k, v in list(col.distribution.items())[:3])
                    lines.append(f"  - {col.name}: {dist}")
                else:
                    d = col.distribution
                    lines.append(f"  - {col.name}: median={d['median']}, range=[{d['min']}, {d['max']}]")
        return "\n".join(lines)

    def _outlier_contexts(
        self, outlier_df: pd.DataFrame, deviation_df: pd.DataFrame, ids: pd.Series | None
    ) -> list[OutlierContext]:
        result = []
        for i, (_, row) in enumerate(outlier_df.iterrows()):
            identifier = str(ids.iloc[i]) if ids is not None and i < len(ids) else f"Record {i+1}"
            values = {k: str(v) for k, v in row.items() if not k.startswith("_")}
            deviations = {}
            if i < len(deviation_df) and "deviations" in deviation_df.iloc[i]:
                deviations = deviation_df.iloc[i]["deviations"]
            result.append(OutlierContext(
                identifier=identifier,
                outlier_score=float(row.get("_outlier_score", 0)),
                values=values,
                deviations=deviations,
            ))
        return result

    def _build_prompt(
        self, dataset_context: str, cluster_summary: str, outliers: list[OutlierContext]
    ) -> str:
        total = len(outliers)
        if total > self.max_outliers:
            outliers = sorted(outliers, key=lambda x: x.outlier_score, reverse=True)[:self.max_outliers]
            truncated_note = f"\n\n*Note: Showing top {self.max_outliers} outliers by score (out of {total} total).*\n"
        else:
            truncated_note = ""

        outlier_details = []
        for o in outliers:
            lines = [f"\n### {o.identifier} (outlier score: {o.outlier_score:.2f})", "Attributes:"]
            for k, v in list(o.values.items())[:10]:
                lines.append(f"  - {k}: {v}")
            if o.deviations:
                lines.append("Key deviations from the majority:")
                for col, dev in o.deviations.items():
                    if "majority_value" in dev:
                        lines.append(
                            f"  - {col}: has '{dev['outlier_value']}' "
                            f"(majority has '{dev['majority_value']}', "
                            f"only {dev['frequency_in_majority']}% share this value)"
                        )
                    elif "z_score" in dev:
                        lines.append(
                            f"  - {col}: value {dev['outlier_value']} "
                            f"(majority median: {dev['majority_median']}, z-score: {dev['z_score']})"
                        )
            outlier_details.append("\n".join(lines))

        return f"""You are analyzing a dataset to explain why certain records are outliers.

## Dataset Context
{dataset_context}

## Cluster Profiles
{cluster_summary}

## Outliers to Explain{truncated_note}
{"".join(outlier_details)}

## Your Task
For each outlier, provide:
1. A clear explanation of why this record doesn't fit with the majority
2. Which specific attributes make it unusual
3. A risk assessment (Low/Medium/High) for whether this record might be incorrectly included
4. A recommended action (Review, Flag for removal, Likely legitimate exception)

Be concise but specific. Focus on the most significant deviations.

IMPORTANT: After your analysis, you MUST include a JSON block with structured data for each outlier.
Format it exactly like this (with the ```json markers):

```json
[
  {{
    "id": "outlier_id",
    "why_outlier": "Brief explanation",
    "unusual_attributes": "attr1, attr2, attr3",
    "risk_level": "Low|Medium|High",
    "recommended_action": "Review|Flag for removal|Likely legitimate"
  }}
]
```
"""


# ---------------------------------------------------------------------------
# LLM agent
# ---------------------------------------------------------------------------

@dataclass
class OutlierAnalysis:
    """Structured LLM analysis for one outlier (parsed from the JSON block)."""
    id: str
    why_outlier: str
    unusual_attributes: str
    risk_level: str
    recommended_action: str


@dataclass
class ExplanationResult:
    """Full result from the LLM: free-text explanation + parsed structured analysis."""
    explanation: str
    model: str
    prompt_tokens: int | None
    completion_tokens: int | None
    structured_analysis: list[OutlierAnalysis] = field(default_factory=list)


class ExplanationAgent:
    """Send the explanation prompt to Azure OpenAI via LangChain and parse the response.

    Connection settings are read from llm.py (or the corresponding environment variables).
    """

    def __init__(self, temperature: float = 0.1, max_tokens: int = 4000):
        self._llm = get_llm(temperature=temperature, max_tokens=max_tokens)

    def explain(self, context: ExplanationContext) -> ExplanationResult:
        """Call Azure OpenAI with the explanation prompt and return the result."""
        try:
            response = self._llm.invoke([
                SystemMessage(content=(
                    "You are a data analyst specializing in anomaly detection. "
                    "Explain why certain records are outliers in clear, actionable terms. "
                    "Be concise and focus on the most significant findings."
                )),
                HumanMessage(content=context.prompt),
            ])

            explanation = response.content
            if not explanation or not explanation.strip():
                prompt_len = len(context.prompt)
                explanation = (
                    f"*LLM returned empty response. Prompt was {prompt_len} chars. "
                    "Try reducing --max-outliers-llm or using a model with a larger context window.*"
                )

            usage = response.usage_metadata or {}
            return ExplanationResult(
                explanation=explanation,
                model=DEPLOYMENT,
                prompt_tokens=usage.get("input_tokens"),
                completion_tokens=usage.get("output_tokens"),
                structured_analysis=self._parse_json_block(explanation),
            )

        except Exception as e:
            msg = str(e)
            if any(k in msg.lower() for k in ("connection", "refused", "unauthorized", "authentication", "401", "403")):
                raise ConnectionError(
                    "Cannot connect to Azure OpenAI. "
                    "Check that AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY are set correctly."
                ) from e
            raise

    def check_connection(self) -> bool:
        """Return True if Azure credentials appear to be configured."""
        return _llm_ok()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_json_block(text: str) -> list[OutlierAnalysis]:
        """Extract the ```json [...] ``` block from the LLM response."""
        try:
            match = re.search(r"```json\s*([\s\S]*?)\s*```", text)
            if not match:
                match = re.search(r"```\s*(\[[\s\S]*?\])\s*```", text)
            if not match:
                return []

            data = json.loads(match.group(1).strip())
            return [
                OutlierAnalysis(
                    id=str(item.get("id", "")),
                    why_outlier=str(item.get("why_outlier", "")),
                    unusual_attributes=str(item.get("unusual_attributes", "")),
                    risk_level=str(item.get("risk_level", "")),
                    recommended_action=str(item.get("recommended_action", "")),
                )
                for item in data
            ]
        except (json.JSONDecodeError, KeyError, TypeError):
            return []
